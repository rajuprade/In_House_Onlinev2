#ifndef _ANT_THREAD_H
#define _ANT_THREAD_H

#include"server.h"
#include"queue.h"

void *ant_thread(void *);

#endif
