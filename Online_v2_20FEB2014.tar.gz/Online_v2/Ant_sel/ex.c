#include<stdio.h>

int main()
{

  int i;
   
  for(i=0;i<4;i++)
  {
   printf("RAJu\n");
  }
return 0;
}
