#ifndef H_DAS_H
#define H_DAS_H

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <stdio.h>
#include<stdlib.h>
#include <string.h>

#define MSGSZ     128
#define KEY 201        // Message Queue ID

int msgID;

typedef struct msgbuf
{
   long    mtype;
   char    mtext[256*4];
} message_buf;

int create_msgq_();

int sndmsgq_(message_buf *msg);

//int wrt_scan_hdr_(char *filename,ScanInfoType *scan_hdr,int *ityp);

#endif //H_DAS_H
