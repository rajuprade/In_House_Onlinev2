// SSCLINK.H
// All Thread for 30 Antenna Servo system will be here. 

#ifndef SSCLINK_H
#define SSCLINK_H

#include<pthread.h>


#define C00_SERVO_IP "192.168.8.112"

void *C00_servo(void *);

pthread_mutex_t locks;

#endif
