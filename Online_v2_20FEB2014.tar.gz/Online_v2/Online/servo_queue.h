#ifndef _SERVOQUEUE_H
#define _SERVOQUEUE_H

#include"servo.h"
#include<stdio.h>
#include<string.h>
#include <stdlib.h>
#include"servo.h"
#define MAXQUE 256 

typedef struct
{
  int front, rear;
  int retrieve ;      
  int store ;         
  SRVANT_CMD srvcmd[MAXQUE]; // It indicates the Queue for Commands 
} SQueue;

typedef struct
{
  int f, r;
  int ret ;      
  int s;         
  servoresp srvresp[MAXQUE]; // It indicates the Queue for Commands 
} SRQueue;


extern SQueue C00srvq;
SQueue C00srvq;

/* C00 Antenna SERVO System Queues */

extern void C00srv_store(SRVANT_CMD );
extern SRVANT_CMD *C00srv_retrieve(int );

#endif
