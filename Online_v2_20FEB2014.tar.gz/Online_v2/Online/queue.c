#include"queue.h"

// SENtinel system queue 

void senq_store(ANT_CMD element )
{
  if (senQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(senQ.store==senQ.retrieve)
  {
    senQ.store = 0; senQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&senQ.command[senQ.store],MAXQUE);
    senQ.command[senQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",senQ.command[senQ.store].CMD.system_name);
    senQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * senq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &senQ.command[indx]); 
}

// Front end system queue 

void frontq_store(ANT_CMD element )
{
  if (frontQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(frontQ.store==frontQ.retrieve)
  {
    frontQ.store = 0; frontQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&frontQ.command[frontQ.store],MAXQUE);
    frontQ.command[frontQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",frontQ.command[frontQ.store].CMD.system_name);
    frontQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * frontq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &frontQ.command[indx]); 
}


// fiber system queue 

void fiberq_store(ANT_CMD element )
{
  if (fiberQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(fiberQ.store==fiberQ.retrieve)
  {
    fiberQ.store = 0; fiberQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&fiberQ.command[fiberQ.store],MAXQUE);
    fiberQ.command[fiberQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",fiberQ.command[fiberQ.store].CMD.system_name);
    fiberQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * fiberq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &fiberQ.command[indx]); 
}

// Back end system queue 

void backq_store(ANT_CMD element )
{
  if (backQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(backQ.store==backQ.retrieve)
  {
    backQ.store = 0; backQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&backQ.command[backQ.store],MAXQUE);
    backQ.command[backQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",backQ.command[backQ.store].CMD.system_name);
    backQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * backq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &backQ.command[indx]); 
}


// Self test system queue 

void selfq_store(ANT_CMD element )
{
  if (selfQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(selfQ.store==selfQ.retrieve)
  {
    selfQ.store = 0; selfQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&selfQ.command[selfQ.store],MAXQUE);
    selfQ.command[selfQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",selfQ.command[selfQ.store].CMD.system_name);
    selfQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * selfq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &selfQ.command[indx]); 
}

/***************** C01 system Queue functions here ******************************/

void c1_senq_store(ANT_CMD element )
{
  if (c1senQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(c1senQ.store==c1senQ.retrieve)
  {
    c1senQ.store = 0; c1senQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&c1senQ.command[c1senQ.store],MAXQUE);
    c1senQ.command[c1senQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",c1senQ.command[c1senQ.store].CMD.system_name);
    c1senQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * c1_senq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &c1senQ.command[indx]); 
}

// Front end system queue 

void c1_frontq_store(ANT_CMD element )
{
  if (c1frontQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(c1frontQ.store==c1frontQ.retrieve)
  {
    c1frontQ.store = 0; c1frontQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&c1frontQ.command[c1frontQ.store],MAXQUE);
    c1frontQ.command[c1frontQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",c1frontQ.command[c1frontQ.store].CMD.system_name);
    c1frontQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * c1_frontq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &c1frontQ.command[indx]); 
}


// fiber system queue 

void c1_fiberq_store(ANT_CMD element )
{
  if (c1fiberQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(c1fiberQ.store==c1fiberQ.retrieve)
  {
    c1fiberQ.store = 0; c1fiberQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&c1fiberQ.command[c1fiberQ.store],MAXQUE);
    c1fiberQ.command[c1fiberQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",c1fiberQ.command[c1fiberQ.store].CMD.system_name);
    c1fiberQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * c1_fiberq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &c1fiberQ.command[indx]); 
}

// Back end system queue 

void c1_backq_store(ANT_CMD element )
{
  if (c1backQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(c1backQ.store==c1backQ.retrieve)
  {
    c1backQ.store = 0; c1backQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&c1backQ.command[c1backQ.store],MAXQUE);
    c1backQ.command[c1backQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",c1backQ.command[c1backQ.store].CMD.system_name);
    c1backQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * c1_backq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &c1backQ.command[indx]); 
}


// Self test system queue 

void c1_selfq_store(ANT_CMD element )
{
  if (c1selfQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(c1selfQ.store==c1selfQ.retrieve)
  {
    c1selfQ.store = 0; c1selfQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&c1selfQ.command[c1selfQ.store],MAXQUE);
    c1selfQ.command[c1selfQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",c1selfQ.command[c1selfQ.store].CMD.system_name);
    c1selfQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * c1_selfq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &c1selfQ.command[indx]); 
}

/***************** C02 system Queue functions here ******************************/

void c2_senq_store(ANT_CMD element )
{
  if (c2senQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(c2senQ.store==c2senQ.retrieve)
  {
    c2senQ.store = 0; c2senQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&c2senQ.command[c2senQ.store],MAXQUE);
    c2senQ.command[c2senQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",c2senQ.command[c2senQ.store].CMD.system_name);
    c2senQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * c2_senq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &c2senQ.command[indx]); 
}

// Front end system queue 

void c2_frontq_store(ANT_CMD element )
{
  if (c2frontQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(c2frontQ.store==c2frontQ.retrieve)
  {
    c2frontQ.store = 0; c2frontQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&c2frontQ.command[c2frontQ.store],MAXQUE);
    c2frontQ.command[c2frontQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",c2frontQ.command[c2frontQ.store].CMD.system_name);
    c2frontQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * c2_frontq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &c2frontQ.command[indx]); 
}


// fiber system queue 

void c2_fiberq_store(ANT_CMD element )
{
  if (c2fiberQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(c2fiberQ.store==c2fiberQ.retrieve)
  {
    c2fiberQ.store = 0; c2fiberQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&c2fiberQ.command[c2fiberQ.store],MAXQUE);
    c2fiberQ.command[c2fiberQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",c2fiberQ.command[c2fiberQ.store].CMD.system_name);
    c2fiberQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * c2_fiberq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &c2fiberQ.command[indx]); 
}

// Back end system queue 

void c2_backq_store(ANT_CMD element )
{
  if (c2backQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(c2backQ.store==c2backQ.retrieve)
  {
    c2backQ.store = 0; c2backQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&c2backQ.command[c2backQ.store],MAXQUE);
    c2backQ.command[c2backQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",c2backQ.command[c2backQ.store].CMD.system_name);
    c2backQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * c2_backq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &c2backQ.command[indx]); 
}


// Self test system queue 

void c2_selfq_store(ANT_CMD element )
{
  if (c2selfQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(c2selfQ.store==c2selfQ.retrieve)
  {
    c2selfQ.store = 0; c2selfQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&c2selfQ.command[c2selfQ.store],MAXQUE);
    c2selfQ.command[c2selfQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",c2selfQ.command[c2selfQ.store].CMD.system_name);
    c2selfQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * c2_selfq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &c2selfQ.command[indx]); 
}

/***************** C03 system Queue functions here ******************************/

void c3_senq_store(ANT_CMD element )
{
  if (c3senQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(c3senQ.store==c3senQ.retrieve)
  {
    c3senQ.store = 0; c3senQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&c3senQ.command[c3senQ.store],MAXQUE);
    c3senQ.command[c3senQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",c3senQ.command[c3senQ.store].CMD.system_name);
    c3senQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * c3_senq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &c3senQ.command[indx]); 
}

// Front end system queue 

void c3_frontq_store(ANT_CMD element )
{
  if (c3frontQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(c3frontQ.store==c3frontQ.retrieve)
  {
    c3frontQ.store = 0; c3frontQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&c3frontQ.command[c3frontQ.store],MAXQUE);
    c3frontQ.command[c3frontQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",c3frontQ.command[c3frontQ.store].CMD.system_name);
    c3frontQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * c3_frontq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &c3frontQ.command[indx]); 
}


// fiber system queue 

void c3_fiberq_store(ANT_CMD element )
{
  if (c3fiberQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(c3fiberQ.store==c3fiberQ.retrieve)
  {
    c3fiberQ.store = 0; c3fiberQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&c3fiberQ.command[c3fiberQ.store],MAXQUE);
    c3fiberQ.command[c3fiberQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",c3fiberQ.command[c3fiberQ.store].CMD.system_name);
    c3fiberQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * c3_fiberq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &c3fiberQ.command[indx]); 
}

// Back end system queue 

void c3_backq_store(ANT_CMD element )
{
  if (c3backQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(c3backQ.store==c3backQ.retrieve)
  {
    c3backQ.store = 0; c3backQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&c3backQ.command[c3backQ.store],MAXQUE);
    c3backQ.command[c3backQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",c3backQ.command[c3backQ.store].CMD.system_name);
    c3backQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * c3_backq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &c3backQ.command[indx]); 
}


// Self test system queue 

void c3_selfq_store(ANT_CMD element )
{
  if (c3selfQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(c3selfQ.store==c3selfQ.retrieve)
  {
    c3selfQ.store = 0; c3selfQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&c3selfQ.command[c3selfQ.store],MAXQUE);
    c3selfQ.command[c3selfQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",c3selfQ.command[c3selfQ.store].CMD.system_name);
    c3selfQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * c3_selfq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &c3selfQ.command[indx]); 
}

/***************** C04 system Queue functions here ******************************/

void c4_senq_store(ANT_CMD element )
{
  if (c4senQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(c4senQ.store==c4senQ.retrieve)
  {
    c4senQ.store = 0; c4senQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&c4senQ.command[c4senQ.store],MAXQUE);
    c4senQ.command[c4senQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",c4senQ.command[c4senQ.store].CMD.system_name);
    c4senQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * c4_senq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &c4senQ.command[indx]); 
}

// Front end system queue 

void c4_frontq_store(ANT_CMD element )
{
  if (c4frontQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(c4frontQ.store==c4frontQ.retrieve)
  {
    c4frontQ.store = 0; c4frontQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&c4frontQ.command[c4frontQ.store],MAXQUE);
    c4frontQ.command[c4frontQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",c4frontQ.command[c4frontQ.store].CMD.system_name);
    c4frontQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * c4_frontq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &c4frontQ.command[indx]); 
}


// fiber system queue 

void c4_fiberq_store(ANT_CMD element )
{
  if (c4fiberQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(c4fiberQ.store==c4fiberQ.retrieve)
  {
    c4fiberQ.store = 0; c4fiberQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&c4fiberQ.command[c4fiberQ.store],MAXQUE);
    c4fiberQ.command[c4fiberQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",c4fiberQ.command[c4fiberQ.store].CMD.system_name);
    c4fiberQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * c4_fiberq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &c4fiberQ.command[indx]); 
}

// Back end system queue 

void c4_backq_store(ANT_CMD element )
{
  if (c4backQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(c4backQ.store==c4backQ.retrieve)
  {
    c4backQ.store = 0; c4backQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&c4backQ.command[c4backQ.store],MAXQUE);
    c4backQ.command[c4backQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",c4backQ.command[c4backQ.store].CMD.system_name);
    c4backQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * c4_backq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &c4backQ.command[indx]); 
}


// Self test system queue 

void c4_selfq_store(ANT_CMD element )
{
  if (c4selfQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(c4selfQ.store==c4selfQ.retrieve)
  {
    c4selfQ.store = 0; c4selfQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&c4selfQ.command[c4selfQ.store],MAXQUE);
    c4selfQ.command[c4selfQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",c4selfQ.command[c4selfQ.store].CMD.system_name);
    c4selfQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * c4_selfq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &c4selfQ.command[indx]); 
}

/***************** C05 system Queue functions here ******************************/

void c5_senq_store(ANT_CMD element )
{
  if (c5senQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(c5senQ.store==c5senQ.retrieve)
  {
    c5senQ.store = 0; c5senQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&c5senQ.command[c5senQ.store],MAXQUE);
    c5senQ.command[c5senQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",c5senQ.command[c5senQ.store].CMD.system_name);
    c5senQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * c5_senq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &c5senQ.command[indx]); 
}

// Front end system queue 

void c5_frontq_store(ANT_CMD element )
{
  if (c5frontQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(c5frontQ.store==c5frontQ.retrieve)
  {
    c5frontQ.store = 0; c5frontQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&c5frontQ.command[c5frontQ.store],MAXQUE);
    c5frontQ.command[c5frontQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",c5frontQ.command[c5frontQ.store].CMD.system_name);
    c5frontQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * c5_frontq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &c5frontQ.command[indx]); 
}


// fiber system queue 

void c5_fiberq_store(ANT_CMD element )
{
  if (c5fiberQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(c5fiberQ.store==c5fiberQ.retrieve)
  {
    c5fiberQ.store = 0; c5fiberQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&c5fiberQ.command[c5fiberQ.store],MAXQUE);
    c5fiberQ.command[c5fiberQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",c5fiberQ.command[c5fiberQ.store].CMD.system_name);
    c5fiberQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * c5_fiberq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &c5fiberQ.command[indx]); 
}

// Back end system queue 

void c5_backq_store(ANT_CMD element )
{
  if (c5backQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(c5backQ.store==c5backQ.retrieve)
  {
    c5backQ.store = 0; c5backQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&c5backQ.command[c5backQ.store],MAXQUE);
    c5backQ.command[c5backQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",c5backQ.command[c5backQ.store].CMD.system_name);
    c5backQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * c5_backq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &c5backQ.command[indx]); 
}


// Self test system queue 

void c5_selfq_store(ANT_CMD element )
{
  if (c5selfQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(c5selfQ.store==c5selfQ.retrieve)
  {
    c5selfQ.store = 0; c5selfQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&c5selfQ.command[c5selfQ.store],MAXQUE);
    c5selfQ.command[c5selfQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",c5selfQ.command[c5selfQ.store].CMD.system_name);
    c5selfQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * c5_selfq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &c5selfQ.command[indx]); 
}

/***************** C06 system Queue functions here ******************************/

void c6_senq_store(ANT_CMD element )
{
  if (c6senQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(c6senQ.store==c6senQ.retrieve)
  {
    c6senQ.store = 0; c6senQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&c6senQ.command[c6senQ.store],MAXQUE);
    c6senQ.command[c6senQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",c6senQ.command[c6senQ.store].CMD.system_name);
    c6senQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * c6_senq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &c6senQ.command[indx]); 
}

// Front end system queue 

void c6_frontq_store(ANT_CMD element )
{
  if (c6frontQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(c6frontQ.store==c6frontQ.retrieve)
  {
    c6frontQ.store = 0; c6frontQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&c6frontQ.command[c6frontQ.store],MAXQUE);
    c6frontQ.command[c6frontQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",c6frontQ.command[c6frontQ.store].CMD.system_name);
    c6frontQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * c6_frontq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &c6frontQ.command[indx]); 
}


// fiber system queue 

void c6_fiberq_store(ANT_CMD element )
{
  if (c6fiberQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(c6fiberQ.store==c6fiberQ.retrieve)
  {
    c6fiberQ.store = 0; c6fiberQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&c6fiberQ.command[c6fiberQ.store],MAXQUE);
    c6fiberQ.command[c6fiberQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",c6fiberQ.command[c6fiberQ.store].CMD.system_name);
    c6fiberQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * c6_fiberq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &c6fiberQ.command[indx]); 
}

// Back end system queue 

void c6_backq_store(ANT_CMD element )
{
  if (c6backQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(c6backQ.store==c6backQ.retrieve)
  {
    c6backQ.store = 0; c6backQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&c6backQ.command[c6backQ.store],MAXQUE);
    c6backQ.command[c6backQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",c6backQ.command[c6backQ.store].CMD.system_name);
    c6backQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * c6_backq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &c6backQ.command[indx]); 
}

// Self test system queue 

void c6_selfq_store(ANT_CMD element )
{
  if (c6selfQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(c6selfQ.store==c6selfQ.retrieve)
  {
    c6selfQ.store = 0; c6selfQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&c6selfQ.command[c6selfQ.store],MAXQUE);
    c6selfQ.command[c6selfQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",c6selfQ.command[c6selfQ.store].CMD.system_name);
    c6selfQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * c6_selfq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &c6selfQ.command[indx]); 
}

/***************** C08 system Queue functions here ******************************/

void c8_senq_store(ANT_CMD element )
{
  if (c8senQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(c8senQ.store==c8senQ.retrieve)
  {
    c8senQ.store = 0; c8senQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&c8senQ.command[c8senQ.store],MAXQUE);
    c8senQ.command[c8senQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",c8senQ.command[c8senQ.store].CMD.system_name);
    c8senQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * c8_senq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &c8senQ.command[indx]); 
}

// Front end system queue 

void c8_frontq_store(ANT_CMD element )
{
  if (c8frontQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(c8frontQ.store==c8frontQ.retrieve)
  {
    c8frontQ.store = 0; c8frontQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&c8frontQ.command[c8frontQ.store],MAXQUE);
    c8frontQ.command[c8frontQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",c8frontQ.command[c8frontQ.store].CMD.system_name);
    c8frontQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * c8_frontq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &c8frontQ.command[indx]); 
}


// fiber system queue 

void c8_fiberq_store(ANT_CMD element )
{
  if (c8fiberQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(c8fiberQ.store==c8fiberQ.retrieve)
  {
    c8fiberQ.store = 0; c8fiberQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&c8fiberQ.command[c8fiberQ.store],MAXQUE);
    c8fiberQ.command[c8fiberQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",c8fiberQ.command[c8fiberQ.store].CMD.system_name);
    c8fiberQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * c8_fiberq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &c8fiberQ.command[indx]); 
}

// Back end system queue 

void c8_backq_store(ANT_CMD element )
{
  if (c8backQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(c8backQ.store==c8backQ.retrieve)
  {
    c8backQ.store = 0; c8backQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&c8backQ.command[c8backQ.store],MAXQUE);
    c8backQ.command[c8backQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",c8backQ.command[c8backQ.store].CMD.system_name);
    c8backQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * c8_backq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &c8backQ.command[indx]); 
}


// Self test system queue 

void c8_selfq_store(ANT_CMD element )
{
  if (c8selfQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(c8selfQ.store==c8selfQ.retrieve)
  {
    c8selfQ.store = 0; c8selfQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&c8selfQ.command[c8selfQ.store],MAXQUE);
    c8selfQ.command[c8selfQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",c8selfQ.command[c8selfQ.store].CMD.system_name);
    c8selfQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * c8_selfq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &c8selfQ.command[indx]); 
}

/***************** C09 system Queue functions here ******************************/

void c9_senq_store(ANT_CMD element )
{
  if (c9senQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(c9senQ.store==c9senQ.retrieve)
  {
    c9senQ.store = 0; c9senQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&c9senQ.command[c9senQ.store],MAXQUE);
    c9senQ.command[c9senQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",c9senQ.command[c9senQ.store].CMD.system_name);
    c9senQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * c9_senq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &c9senQ.command[indx]); 
}

// Front end system queue 

void c9_frontq_store(ANT_CMD element )
{
  if (c9frontQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(c9frontQ.store==c9frontQ.retrieve)
  {
    c9frontQ.store = 0; c9frontQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&c9frontQ.command[c9frontQ.store],MAXQUE);
    c9frontQ.command[c9frontQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",c9frontQ.command[c9frontQ.store].CMD.system_name);
    c9frontQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * c9_frontq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &c9frontQ.command[indx]); 
}


// fiber system queue 

void c9_fiberq_store(ANT_CMD element )
{
  if (c9fiberQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(c9fiberQ.store==c9fiberQ.retrieve)
  {
    c9fiberQ.store = 0; c9fiberQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&c9fiberQ.command[c9fiberQ.store],MAXQUE);
    c9fiberQ.command[c9fiberQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",c9fiberQ.command[c9fiberQ.store].CMD.system_name);
    c9fiberQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * c9_fiberq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &c9fiberQ.command[indx]); 
}

// Back end system queue 

void c9_backq_store(ANT_CMD element )
{
  if (c9backQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(c9backQ.store==c9backQ.retrieve)
  {
    c9backQ.store = 0; c9backQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&c9backQ.command[c9backQ.store],MAXQUE);
    c9backQ.command[c9backQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",c9backQ.command[c9backQ.store].CMD.system_name);
    c9backQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * c9_backq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &c9backQ.command[indx]); 
}


// Self test system queue 

void c9_selfq_store(ANT_CMD element )
{
  if (c9selfQ.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(c9selfQ.store==c9selfQ.retrieve)
  {
    c9selfQ.store = 0; c9selfQ.retrieve = 0;
  }
     fprintf(stderr," ###### Element in Command Queue %s\n",element.CMD.system_name);
    bzero(&c9selfQ.command[c9selfQ.store],MAXQUE);
    c9selfQ.command[c9selfQ.store]=element; 
   fprintf(stderr," INSERTING in Command Queue %s\n",c9selfQ.command[c9selfQ.store].CMD.system_name);
    c9selfQ.store++;  // point to next available storage position in queue[]
 }

ANT_CMD * c9_selfq_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((ANT_CMD *) &c9selfQ.command[indx]); 
}













