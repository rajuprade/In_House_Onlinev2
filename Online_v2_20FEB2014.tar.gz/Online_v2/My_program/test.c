#include<stdio.h>

int main()
{

   fprintf(stderr,"I am before sleep\n");
   usleep(500000);
   fprintf(stderr,"#### I am after sleep\n");
   return 0;
}
