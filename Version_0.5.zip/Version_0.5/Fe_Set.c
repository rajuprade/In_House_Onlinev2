#include <stdio.h>
#include <stdlib.h>
#include <string.h>

main()
{
  int CB_Table[]={0x0180, 0x0181, 0x0188, 0x018A, 0x0190, 0x0194, 0x01E0, 0X01E1, 0X01E8, 0X01EA, 0X01F0, 0X01F4, 0X0000, 0X0001, 0X0008, 0X000A, 0X0010, 0X0014, 0X0060, 0X0061, 0X0068, 0X006A, 0X0070, 0X0074, 0X00A0, 0X00A1, 0X00A8, 0X00AA, 0X00B0, 0X00B4};
  int FE_Table[]={0x06, 0x05, 0x0a, 0x09}; 

  char SA_Table[][10] = {"00","14","30","44","TERM"};
  char FB_Table[][10] = {"50","150","233","327","610","1420"};
  char NC_Table[][10] = {"XHIGH", "HIGH", "MED", "LOW"};
  char LB_Table[][10] = {"1060","1280","1170","1390"};
  //char RF_Table[][10] = {"OFF","ON"};
  
  char sa[10], fb[10], n_cal[10], rf[10], lb[10]; /* lb is sub bands of LBand */
  int i, j, fe_dmask, swap;

  while(1)
  {
    printf("\nEnter SA, Freq and Swap : ");
    scanf("%s %s %d", sa, fb, &swap);

    for(i=0; i<5; i++)
    {
      if(!strcmp(sa, SA_Table[i]))
      {
	for(j=0; j<6; j++)
	{
	  if(!strcmp(fb, FB_Table[j]))
          {
	    printf("\nCurrent Value : %d", (i*6)+j);	    

	    if(swap == 1)
		CB_Table[(i*6)+j] = CB_Table[(i*6)+j] | 0x0200;
	    else if(swap == 0)
		CB_Table[(i*6)+j] = CB_Table[(i*6)+j] & 0XFDFF;

	    printf("\nFE_CODE after all values : %#06x", CB_Table[(i*6)+j]);

	    fe_dmask  = (CB_Table[(i*6)+j] & 0x00ff) | 0x0700;
	    printf("\nFE_Dmask :%#06x", fe_dmask);

	    fe_dmask  = ((CB_Table[(i*6)+j] & 0xff00) >> 8) | 0x0800;
	    printf("\nFE_Dmask :%#06x", fe_dmask);

	    break;
	  }
         
	}

      }
      
    }

    printf("\nEnter Noice Cal and RF: ");
    scanf("%s %s", n_cal, rf);

    fe_dmask = 0x0000;

    if(!strcmp(rf,"OFF"))
    {
     fe_dmask = fe_dmask | 0x0010;
    }
    else if(!strcmp(rf,"ON"))
    {
     fe_dmask = fe_dmask & 0xFFEF;
    }

    //.... Pattern for except L Band ....// 
    for(j=0; j<5; j++)
    {
      if(!strcmp(fb, FB_Table[j]))
      {
	for(i=0; i<4; i++)
	{
	 if(!strcmp(n_cal, NC_Table[i]))
	  {
	    fe_dmask = fe_dmask | ((j+1) << 8) | FE_Table[i];
	    
	    printf("\nFE_Dmask : %#06x",fe_dmask);
	  }

	}

      }
    }

    //.... Pattern for L Band ....// 
    if(!strcmp(fb,"1420"))
    {
      printf("\nEnter Sub Band : ");
      scanf("%s",lb);

      for(i=0; i<4; i++)
      {
	if(!strcmp(lb, LB_Table[i]))
	{
	  for(j=0; j<4; j++)
      	  {
	    if(!strcmp(n_cal, NC_Table[j]))
	    {
	      fe_dmask = fe_dmask | 0x0600 | FE_Table[j] | ((i*2) << 4);
	      printf("\nFE_Dmask : %#06x",fe_dmask);

	    } // if ends..

	  } // for ends..

	} // if ends..
      }
    
    } // if end..


  } // while(1) end..

} 
