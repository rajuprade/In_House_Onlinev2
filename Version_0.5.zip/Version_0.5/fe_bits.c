/**** Common BOX Settings ****/
char frq_band[][10]={"50","150","233","327","610","1420"};
int fb_bits[] = {0x0000, 0x0001, 0x0008, 0x000A, 0x0010, 0x0014};

char solar_attn[][10]={"0","14","30","44","TERM"};
int sa_bits[] = {0x0180, 0x01E0, 0x0000, 0x0060, 0x00A0};

char polar[][10] = {"UNSWAP","SWAP"};
int pl_bits[] = {0x0000, 0x0200};


/**** FE BOX Settings ****/
char band_sel[][10]={"1060","1170","1280","1390"};
int bs_bits[] = {0x00, 0x40, 0x20, 0x60};

char noise_cal[][10]={"LOW","MED","HIGH","XHIGH"};
int nc_bits[] = {0x09, 0x0A, 0x05, 0x06};

char rf[][10] = {"ON","OFF"};
int rf_bits[] = {0x10, 0x00};