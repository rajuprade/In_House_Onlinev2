#include"ssclink.h"
#include"servo.h"
#include"servo_queue.h"
#include"socket.h"
#include"server.h"

void* C00_servo( void* parameters)
{    
     int server_fd;
     ssize_t n;

     SRVANT_CMD *a1;
     a1 = malloc(sizeof(SRVANT_CMD));
  
     servocmd *c1;
     c1 = malloc(sizeof(servocmd));
    
     servoresp *r1;
     r1 = malloc(sizeof(servoresp));
     server_fd = *(int*)parameters;
     char *tstamp;
     tstamp = malloc(25);
  
       C00srvq.store = 0; C00srvq.retrieve = 0;
              for(;;)
              {
                    if((int)(C00srvq.store)>(int)(C00srvq.retrieve))
                     {
                       pthread_mutex_lock(&locks);
                       a1 = (SRVANT_CMD *) C00srv_retrieve((int)C00srvq.retrieve);
                       pthread_mutex_unlock(&locks);
                        tstamp = tp(tstamp);
                        strcpy(a1->SRVCMD.timestamp,tstamp);
                        c1 = &a1->SRVCMD;
                         if((servocmd *)c1 != (servocmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"servo"))
                                 {
                                    
                                    if((n=writen(server_fd,(unsigned char *)c1,sizeof(servocmd)))!=sizeof(servocmd))
                                     {  fprintf(stderr," ERROR Sending CMD to C00 servo system\n"); }
            
                                     else if (readable_timeo(server_fd,2) == 0)
                                      {
                                         fprintf(stderr, "C00 servo timeout\n");
                                        
                                      }
                               
                                      else
                                     { 
                                         printservocmd(c1);
                                         bzero(c1,sizeof(servocmd));
                                                                             
                                     }
                                  } 
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                        
                                  usleep(50000);
                                  bzero(r1,sizeof(servoresp)); 
                             
                               if((n=readn(server_fd,r1,sizeof(servoresp)))!=sizeof(servoresp))
                                  { fprintf(stderr," ERROR READING C00 servo RESPONSE\n");
                                     //terminate_thread(server_fd);
                                  }
                                 else
                                 {
                                    printservoresp(r1);
                                    //write_shm(a1,r1); 
                                    bzero(r1,sizeof(servoresp));
                                   fprintf(stderr," Writing to ONLINE from SERVO THREAD SUCCESSFUL\n");
                                 } 
                                 sleep(1);
                                 bzero(r1,sizeof(servoresp)); 
                             
                               if((n=readn(server_fd,r1,sizeof(servoresp)))!=sizeof(servoresp))
                                  { fprintf(stderr," ERROR READING C00 servo RESPONSE\n");
                                     //terminate_thread(server_fd);
                                  }
                                 else
                                 {
                                    printservoresp(r1);
                                    //write_shm(a1,r1); 
                                    bzero(r1,sizeof(servoresp));
                                   fprintf(stderr," Writing to ONLINE from SERVO THREAD SUCCESSFUL\n");
                                 } 
                                C00srvq.retrieve++; 
                                                
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                        
                       }
                   /*   else
                         { // Periodic Monitoring in the background 
                           bzero(c1,sizeof(servocmd));
                           strcpy(a1->antenna_name,"C00");
                           strcpy(a1->SRVCMD.system_name,"servo");
                           a1->SRVCMD.seq= 10;
                           strcpy(a1->SRVCMD.op_name,"mon");
                           a1->SRVCMD.number_param=0;
                            tstamp = tp(tstamp);
                            strcpy(a1->SRVCMD.timestamp,tstamp);
                            c1 = &a1->SRVCMD;
                          
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(servocmd)))!=sizeof(servocmd))
                            {  fprintf(stderr," ERROR Sending CMD to C00 Servo system\n"); }
                            else if (readable_timeo(server_fd,5) == 0)
                           {
                             fprintf(stderr, "C00 Servo system #Perodic Monitoring\n");
                             
                           }
                            else
                             {
                               // printcmd(c1);
                             }
                              
                             sleep(1);
                            bzero(r1,sizeof(servoresp));
                            if((n=readn(server_fd,r1,sizeof(servoresp)))!=sizeof(servoresp))
                           { fprintf(stderr," ERROR READING C00 Servo system RESPONSE\n");
                                     terminate_thread(server_fd);
                           }
                           
                           else if(n==0)
                            {
                              fprintf(stderr,"C00 servo system it's Socket connection\n");
                                terminate_thread(server_fd);
                            }
                           
                           else
                           {
                              //write_shm(a1,r1); 
                            } 
                          } */
                
                    }
  free(a1);
  free(r1);
  free(c1);
     
   return NULL;
}

