#ifndef _MCM_THREAD_H
#define _MCM_THREAD_H

#include"server.h"
#include"queue.h"
#include"socket.h"

/* #define SENTINEL_IP "192.168.33.2"
#define FIBER_IP "192.168.31.2"
#define FRONT_IP "192.168.31.3"
#define BACKEND_IP "192.168.31.4"
#define SELF_IP "192.168.31.5"
#define C01_SENTINEL_IP "192.168.32.2"
#define C01_FIBER_IP "192.168.32.3"
#define C01_FRONT_IP "192.168.32.4"
#define C01_BACKEND_IP "192.168.32.5"
#define C01_SELF_IP "192.168.32.6" */ 

#define SENTINEL_IP "192.168.33.2"
//#define SENTINEL_IP "192.168.21.105"
#define C01_SENTINEL_IP "192.168.32.2"
#define C02_SENTINEL_IP "192.168.32.3"
#define C03_SENTINEL_IP "192.168.32.4"
#define C04_SENTINEL_IP "192.168.32.5"
#define C05_SENTINEL_IP "192.168.31.2"
//#define C06_SENTINEL_IP "192.168.31.3"
#define C06_SENTINEL_IP "192.168.21.105"
#define C08_SENTINEL_IP "192.168.31.4"

#define FIBER_IP "192.168.36.2"        // C06 Fiber Optics MCM Card IP
#define C01_FIBER_IP "192.168.36.3"
#define C02_FIBER_IP "192.168.36.4"
#define C03_FIBER_IP "192.168.36.5"
#define C04_FIBER_IP "192.168.36.6"
#define C05_FIBER_IP "192.168.36.7"
//#define C06_FIBER_IP "192.168.36.8"
#define C06_FIBER_IP "192.168.21.106"
#define C08_FIBER_IP "192.168.36.9"

//#define FRONT_IP "192.168.8.120"            // S02 MCM card IP
#define FRONT_IP "192.168.31.3"  
#define C01_FRONT_IP "192.168.37.3"
#define C02_FRONT_IP "192.168.37.4"
#define C03_FRONT_IP "192.168.37.5"
#define C04_FRONT_IP "192.168.37.6"
#define C05_FRONT_IP "192.168.37.7"
#define C06_FRONT_IP "192.168.37.8"
#define C08_FRONT_IP "192.168.37.9"

#define BACKEND_IP "192.168.38.2"
#define C01_BACKEND_IP "192.168.38.3"
#define C02_BACKEND_IP "192.168.38.4"
#define C03_BACKEND_IP "192.168.38.5"
#define C04_BACKEND_IP "192.168.38.6"
#define C05_BACKEND_IP "192.168.38.7"
#define C06_BACKEND_IP "192.168.38.8"
#define C08_BACKEND_IP "192.168.38.9"


#define SELF_IP "192.168.39.2"
#define C01_SELF_IP "192.168.39.3"
#define C02_SELF_IP "192.168.39.4"
#define C03_SELF_IP "192.168.39.5"
#define C04_SELF_IP "192.168.39.6"
#define C05_SELF_IP "192.168.39.7"
#define C06_SELF_IP "192.168.39.8"
#define C08_SELF_IP "192.168.39.9"

void *sentinel_thread(void *);
void *fiber_thread(void *);
void *front_thread(void *);
void *backend_thread(void *);
void *self_thread(void *);

void *C01_sentinel_thread(void *);
void *C01_fiber_thread(void *);
void *C01_front_thread(void *);
void *C01_backend_thread(void *);
void *C01_self_thread(void *);

void *C02_sentinel_thread(void *);
void *C02_fiber_thread(void *);
void *C02_front_thread(void *);
void *C02_backend_thread(void *);
void *C02_self_thread(void *);

void *C03_sentinel_thread(void *);
void *C03_fiber_thread(void *);
void *C03_front_thread(void *);
void *C03_backend_thread(void *);
void *C03_self_thread(void *);

void *C04_sentinel_thread(void *);
void *C04_fiber_thread(void *);
void *C04_front_thread(void *);
void *C04_backend_thread(void *);
void *C04_self_thread(void *);

void *C05_sentinel_thread(void *);
void *C05_fiber_thread(void *);
void *C05_front_thread(void *);
void *C05_backend_thread(void *);
void *C05_self_thread(void *);

void *C06_sentinel_thread(void *);
void *C06_fiber_thread(void *);
void *C06_front_thread(void *);
void *C06_backend_thread(void *);
void *C06_self_thread(void *);

void *C08_sentinel_thread(void *);
void *C08_fiber_thread(void *);
void *C08_front_thread(void *);
void *C08_backend_thread(void *);
void *C08_self_thread(void *);

void *C09_sentinel_thread(void *);
void *C09_fiber_thread(void *);
void *C09_front_thread(void *);
void *C09_backend_thread(void *);
void *C09_self_thread(void *);

#endif
