
#ifndef _SYSTEM_H
#define _SYSTEM_H
#include"server.h"


void sentinel(ANT_CMD *);
void front_end(ANT_CMD *);
void fiber_optics(ANT_CMD *);
void back_end(ANT_CMD *);
void self_test(ANT_CMD *);

#endif
