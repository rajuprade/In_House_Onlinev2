#include"das.h"

int create_msgq_()
{
       /*  int msgid;
	    if((msgid = msgget(KEY, 0600 | IPC_CREAT)) < 0) {
	       fprintf(stderr," unable to get msgid %d\n",msgid);
	    }
        return (msgid); */

    int msqid;
    int msgflg = IPC_CREAT | 0600;
    key_t key;
   // message_buf sbuf;
  //  message_buf  rbuf;
    size_t buf_length;
    int ii;
    /*
     * Get the message queue id for the
     * "name" 1234, which was created by
     * the server.
     */
    key = 201;

(void) fprintf(stderr, "\nmsgget: Calling msgget(%#lx,\
%#o)\n",
key, msgflg);

    if ((msqid = msgget(key, msgflg )) < 0) {
        perror("msgget");
        exit(1);
    }
    else 
     (void) fprintf(stderr,"msgget: msgget succeeded: msqid = %d\n", msqid);

    return(msqid);


}

int sndmsgq_(message_buf *sbuf)
{
   int ii,j,k,qwait,await;
    message_buf  rbuf;
    size_t buf_length;
   
    sbuf->mtype = 1;
    ii=sbuf->mtype+1;
    sbuf->mtype = 1;
    k=128;
    buf_length = strlen(sbuf->mtext) + 1 ;
    /* fprintf(stderr,"MSEESAGE ID %d\n",msgID); 
    fprintf(stderr,"IN sendMSG => %s\n",sbuf.mtext); */
    

   
     while(msgrcv(msgID,(void *)&rbuf,k,ii,IPC_NOWAIT)>0);
      k=strlen(sbuf->mtext);
     if(msgsnd(msgID,sbuf, k+1,IPC_NOWAIT) < 0){
       fprintf(stderr," unable to send  mesg \n");
       return(-1);
     }
     else 
     printf("Message Sent=>%s\n", sbuf->mtext); 
     await=10;
     j=0;
     k=128;
     while(msgrcv(msgID,(void *)&rbuf,k,ii,IPC_NOWAIT)<0){
       fprintf(stderr,"waiting for ack id %d\n",ii);
       sleep(1);
       j++;
       if(j==await) {
	  fprintf(stderr,"abort:waiting for ack\n");
	  return(-2);
       }
    }
    fprintf(stderr,"ACK Got from DASSERVER : %s\n",rbuf.mtext);

    qwait=10;
    j=0;
    while(msgrcv(msgID,(void *)&rbuf,k,ii,IPC_NOWAIT)<0){
       fprintf(stderr,"waiting for success is %d \n",ii);
       sleep(1);
       j++;
       if(j==qwait) {
	  fprintf(stderr,"abort:waiting for success\n");
	  return(-3);
       }
    }
    fprintf(stderr,"%s\n",rbuf.mtext); 
    return(0);
}

/* int wrt_scan_hdr_(char *filename,ScanInfoType *scan_hdr,int *ityp)
{
    FILE *file;
    int stat;

    file=fopen(filename,"wb");
    if(file==0){
       fprintf(stderr,"Error opening file %s\n",filename);
       return(-1);
    }
    if(*ityp==0){
      stat=fwrite(&(scan_hdr->source),sizeof(SourceParType),1,file);
    } else if(*ityp==1){
      stat=fwrite(&(scan_hdr->proj),sizeof(ProjectType),1,file);
    }
    if(stat!=1){
       fprintf(stderr,"Error writing into %s\n",filename);
       fclose(file);
       return(-2);
    }
    fclose(file);
    return(0);

} */

