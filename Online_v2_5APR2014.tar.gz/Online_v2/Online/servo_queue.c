#include"servo_queue.h"

// SENVO system queue 

void C00srv_store(SRVANT_CMD element)
{
   servocmd *c1;
   c1 = malloc(sizeof(servocmd));
  
  if (C00srvq.store == MAXQUE ) {
    fprintf(stderr, "\nQueue is full!");
    return;
  }

  if(C00srvq.store==C00srvq.retrieve)
  {
    C00srvq.store = 0; C00srvq.retrieve = 0;
  }
    fprintf(stderr," ###### Element in Command Queue %s\n",element.SRVCMD.system_name);
    bzero(&C00srvq.srvcmd[C00srvq.store],MAXQUE);
    C00srvq.srvcmd[C00srvq.store]=element;
    c1 = &element.SRVCMD;
    printservocmd(c1); 
    fprintf(stderr," INSERTING in Command Queue %s\n",C00srvq.srvcmd[C00srvq.store].SRVCMD.system_name);
    C00srvq.store++;  // point to next available storage position in queue[]
 }

SRVANT_CMD * C00srv_retrieve(int indx)
{

   //fprintf(stderr, "\nq_retrieve() %d\n",indx);
  return((SRVANT_CMD *) &C00srvq.srvcmd[indx]); 
}
