#ifndef _QUEUE_H
#define _QUEUE_H

#include"server.h"
#include<stdio.h>
#include<string.h>
#include <stdlib.h>
#define MAXQUE 256 

typedef struct
{
  int front, rear;
  int retrieve ;      
  int store ;         
  ANT_CMD command[MAXQUE]; // It indicates the Queue for Commands 
} Queue;

typedef struct
{
  int f, r;
  int ret ;      
  int s;         
  resp Resp[MAXQUE]; // It indicates the Queue for Commands 
} RQueue;


extern RQueue RQ ; 
RQueue RQ;

extern void rq_store(ANT_CMD );
extern resp *rq_retrieve(int );


extern Queue senQ,frontQ,backQ,fiberQ,selfQ,c1senQ,c1frontQ,c1backQ,c1fiberQ,c1selfQ,      			      c2senQ,c2frontQ,c2backQ,c2fiberQ,c2selfQ,c3senQ,c3frontQ,c3backQ,c3fiberQ,c3selfQ,
c4senQ,c4frontQ,c4backQ,c4fiberQ,c4selfQ,c5senQ,c5frontQ,c5backQ,c5fiberQ,cselfQ,
c5senQ,c5frontQ,c5backQ,c5fiberQ,c5selfQ,c6senQ,c6frontQ,c6backQ,c6fiberQ,c6selfQ,
c8senQ,c8frontQ,c8backQ,c8fiberQ,c8selfQ,c9senQ,c9frontQ,c9backQ,c9fiberQ,c9selfQ;

 
Queue senQ,frontQ,backQ,fiberQ,selfQ,c1senQ,c1frontQ,c1backQ,c1fiberQ,c1selfQ,
c2senQ,c2frontQ,c2backQ,c2fiberQ,c2selfQ,c3senQ,c3frontQ,c3backQ,c3fiberQ,c3selfQ,
c4senQ,c4frontQ,c4backQ,c4fiberQ,c4selfQ,c5senQ,c5frontQ,c5backQ,c5fiberQ,cselfQ,
c5senQ,c5frontQ,c5backQ,c5fiberQ,c5selfQ,c6senQ,c6frontQ,c6backQ,c6fiberQ,c6selfQ,
c8senQ,c8frontQ,c8backQ,c8fiberQ,c8selfQ,c9senQ,c9frontQ,c9backQ,c9fiberQ,c9selfQ;

/* C00 Antenna System Queues */

extern void senq_store(ANT_CMD );
extern ANT_CMD *senq_retrieve(int );

extern void frontq_store(ANT_CMD );
extern ANT_CMD *frontq_retrieve(int );

extern void fiberq_store(ANT_CMD );
extern ANT_CMD *fiberq_retrieve(int );

extern void backq_store(ANT_CMD );
extern ANT_CMD *backq_retrieve(int );

extern void selfq_store(ANT_CMD );
extern ANT_CMD *selfq_retrieve(int );

/**** C01 Antenna system Queue */

extern void c1_senq_store(ANT_CMD );
extern ANT_CMD *c1_senq_retrieve(int );

extern void c1_frontq_store(ANT_CMD );
extern ANT_CMD *c1_frontq_retrieve(int );

extern void c1_fiberq_store(ANT_CMD );
extern ANT_CMD *c1_fiberq_retrieve(int );

extern void c1_backq_store(ANT_CMD );
extern ANT_CMD *c1_backq_retrieve(int );

extern void c1_selfq_store(ANT_CMD );
extern ANT_CMD *c1_selfq_retrieve(int );

/**** C02 Antenna system Queue */

extern void c2_senq_store(ANT_CMD );
extern ANT_CMD *c2_senq_retrieve(int );

extern void c2_frontq_store(ANT_CMD );
extern ANT_CMD *c2_frontq_retrieve(int );

extern void c2_fiberq_store(ANT_CMD );
extern ANT_CMD *c2_fiberq_retrieve(int );

extern void c2_backq_store(ANT_CMD );
extern ANT_CMD *c2_backq_retrieve(int );

extern void c2_selfq_store(ANT_CMD );
extern ANT_CMD *c2_selfq_retrieve(int );

/**** C03 Antenna system Queue */

extern void c3_senq_store(ANT_CMD );
extern ANT_CMD *c3_senq_retrieve(int );

extern void c3_frontq_store(ANT_CMD );
extern ANT_CMD *c3_frontq_retrieve(int );

extern void c3_fiberq_store(ANT_CMD );
extern ANT_CMD *c3_fiberq_retrieve(int );

extern void c3_backq_store(ANT_CMD );
extern ANT_CMD *c3_backq_retrieve(int );

extern void c3_selfq_store(ANT_CMD );
extern ANT_CMD *c3_selfq_retrieve(int );

/**** C04 Antenna system Queue */

extern void c4_senq_store(ANT_CMD );
extern ANT_CMD *c4_senq_retrieve(int );

extern void c4_frontq_store(ANT_CMD );
extern ANT_CMD *c4_frontq_retrieve(int );

extern void c4_fiberq_store(ANT_CMD );
extern ANT_CMD *c4_fiberq_retrieve(int );

extern void c4_backq_store(ANT_CMD );
extern ANT_CMD *c4_backq_retrieve(int );

extern void c4_selfq_store(ANT_CMD );
extern ANT_CMD *c4_selfq_retrieve(int );

/**** C05 Antenna system Queue */

extern void c5_senq_store(ANT_CMD );
extern ANT_CMD *c5_senq_retrieve(int );

extern void c5_frontq_store(ANT_CMD );
extern ANT_CMD *c5_frontq_retrieve(int );

extern void c5_fiberq_store(ANT_CMD );
extern ANT_CMD *c5_fiberq_retrieve(int );

extern void c5_backq_store(ANT_CMD );
extern ANT_CMD *c5_backq_retrieve(int );

extern void c5_selfq_store(ANT_CMD );
extern ANT_CMD *c5_selfq_retrieve(int );

/**** C06 Antenna system Queue */

extern void c6_senq_store(ANT_CMD );
extern ANT_CMD *c6_senq_retrieve(int );

extern void c6_frontq_store(ANT_CMD );
extern ANT_CMD *c6_frontq_retrieve(int );

extern void c6_fiberq_store(ANT_CMD );
extern ANT_CMD *c6_fiberq_retrieve(int );

extern void c6_backq_store(ANT_CMD );
extern ANT_CMD *c6_backq_retrieve(int );

extern void c6_selfq_store(ANT_CMD );
extern ANT_CMD *c6_selfq_retrieve(int );

/**** C08 Antenna system Queue */

extern void c8_senq_store(ANT_CMD );
extern ANT_CMD *c8_senq_retrieve(int );

extern void c8_frontq_store(ANT_CMD );
extern ANT_CMD *c8_frontq_retrieve(int );

extern void c8_fiberq_store(ANT_CMD );
extern ANT_CMD *c8_fiberq_retrieve(int );

extern void c8_backq_store(ANT_CMD );
extern ANT_CMD *c8_backq_retrieve(int );

extern void c8_selfq_store(ANT_CMD );
extern ANT_CMD *c8_selfq_retrieve(int );

/**** C09 Antenna system Queue */

extern void c9_senq_store(ANT_CMD );
extern ANT_CMD *c9_senq_retrieve(int );

extern void c9_frontq_store(ANT_CMD );
extern ANT_CMD *c9_frontq_retrieve(int );

extern void c9_fiberq_store(ANT_CMD );
extern ANT_CMD *c9_fiberq_retrieve(int );

extern void c9_backq_store(ANT_CMD );
extern ANT_CMD *c9_backq_retrieve(int );

extern void c9_selfq_store(ANT_CMD );
extern ANT_CMD *c9_selfq_retrieve(int );

#endif
