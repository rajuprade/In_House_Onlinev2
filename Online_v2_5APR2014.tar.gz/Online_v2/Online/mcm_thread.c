#include"mcm_thread.h"

void* sentinel_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1 = malloc(sizeof(ANT_CMD));
  
     cmd *c1;
     c1 = malloc(sizeof(cmd));
    
     resp *r1;
     r1 = malloc(sizeof(resp));
     server_fd = *(int*)parameters;
     char *tstamp;
     tstamp = malloc(25);
  
       senQ.store = 0; senQ.retrieve = 0;
              for(;;)
              {
                    if((int)(senQ.store)>(int)(senQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = (ANT_CMD *) senq_retrieve((int)senQ.retrieve);
                       pthread_mutex_unlock(&lock);
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                        c1 = &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"sentinel"))
                                 {
                                    
                                    if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," ERROR Sending CMD to C00 sentinel MCM device\n"); }
            
                                     else if (readable_timeo(server_fd,2) == 0)
                                      {
                                         fprintf(stderr, "C00 Sentinel MCM TIMEOUT\n");
                                        
                                      }
                                      else
                                     { 
                                         printcmd(c1);
                                         bzero(c1,sizeof(cmd));
                                                                             
                                     }
                                  } 
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                        
                                  usleep(500000);
                                  bzero(r1,sizeof(resp)); 
                             
                               if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr," ERROR READING C00 sentinel MCM RESPONSE\n");
                                     terminate_thread(server_fd);
                                  }
                                  else if(n==0)
                                  {
                                     fprintf(stderr,"C00 sentinel MCM closed it's Socket connection\n");
                                      terminate_thread(server_fd);
                                  }    
                                 else
                                 {
                                    printresp(r1);
                                    write_shm(a1,r1); 
                                    bzero(r1,sizeof(resp));
                                   fprintf(stderr," Writing to ONLINE from SENTINEL THREAD SUCCESSFUL\n");
                                 } 
                                senQ.retrieve++; 
                                                
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                        
                       }
                      else
                         { // Periodic Monitoring in the background 
                           bzero(c1,sizeof(cmd));
                           strcpy(a1->antenna_name,"C00");
                           strcpy(a1->CMD.system_name,"sentinel");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                            tstamp = tp(tstamp);
                            strcpy(a1->CMD.timestamp,tstamp);
                            c1 = &a1->CMD;
                          
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to C00 sentinel MCM device\n"); }
                            else if (readable_timeo(server_fd,5) == 0)
                           {
                             fprintf(stderr, "C00 Sentinel MCM TIMEOUT #Perodic Monitoring\n");
                             
                           }
                            else
                             {
                               // printcmd(c1);
                             }
                              
                             sleep(1);
                            bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                           { fprintf(stderr," ERROR READING C00 Sentinel MCM RESPONSE\n");
                                     terminate_thread(server_fd);
                           }
                           
                           else if(n==0)
                            {
                              fprintf(stderr,"C00 sentinel MCM closed it's Socket connection\n");
                                terminate_thread(server_fd);
                            }
                           
                           else
                           {
                              write_shm(a1,r1); 
                            } 
                          }
                
                    }
  free(a1);
  free(r1);
  free(c1);
     
   return NULL;
}

void* fiber_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1 = malloc(sizeof(ANT_CMD));
  
     cmd *c1;
     c1 = malloc(sizeof(cmd));
      char *tstamp;
     tstamp = malloc(25);
      resp *r1;
    r1 = malloc(sizeof(resp));
    server_fd = *(int*)parameters;
 
       fiberQ.store = 0; fiberQ.retrieve = 0;
              for(;;)
              {
                    if((int)(fiberQ.store)>(int)(fiberQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = (ANT_CMD*) fiberq_retrieve((int)fiberQ.retrieve);
                       pthread_mutex_unlock(&lock);
                        
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                         c1= &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"fiber_optics"))
                                 {
                                         
                                    if((n= writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," ERROR Sending CMD to C00 FIBER MCM device\n");}
                                       else
                                      { 
                                         printcmd(c1);
                                         bzero(c1,sizeof(cmd));
                                       
                                      }
                                  }
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                        
                                    usleep(500000);
                                   bzero(r1,sizeof(resp));               
                              if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr,"ERROR READING C00 FIBER MCM RESPONSE\n"); 
                                     terminate_thread(server_fd);
                                  }
                               else if(n==0)
                                {
                                  fprintf(stderr,"C00  FIBER OPTICS MCM closed it's Socket connection\n");
                                   terminate_thread(server_fd);
                                }
                              else
                              {
                                     printresp(r1);
                                     write_shm(a1,r1);                  
                                     fprintf(stderr," Writing to ONLINE from FIBER THREAD SUCCESSFUL\n");
                               } 
                            
                             fiberQ.retrieve++;                      
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                       }
                       else
                         { // Periodic Monitoring in the background 
                            bzero(c1,sizeof(cmd));
                           strcpy(a1->antenna_name,"C00");
                           strcpy(a1->CMD.system_name,"fiber_optics");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                            tstamp = tp(tstamp);
                            strcpy(a1->CMD.timestamp,tstamp);
                            c1 = &a1->CMD;
                          
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to MCM device\n"); }
                            else
                            {// printcmd(c1);
                            }
                             sleep(1);
                             bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                           {
                             fprintf(stderr," ERROR READING C00 FIBER MCM RESPONSE\n"); 
                              terminate_thread(server_fd);
                           }
                             
                           else if(n==0)
                            {
                              fprintf(stderr,"C00  FIBER OPTICS MCM closed it's Socket connection\n");
                               terminate_thread(server_fd);
                            }
                           
                           else
                           {
                             //printresp(r1);
                              write_shm(a1,r1); 
                            } 
                          } 
                      
                    }
  free(a1);
  free(r1);
  free(c1);
   return NULL;
}

void* front_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1 = malloc(sizeof(ANT_CMD));
    
     cmd *c1;
     c1 = malloc(sizeof(cmd));
 
      char *tstamp;
     tstamp = malloc(25);
     resp *r1;
    r1 = malloc(sizeof(resp));
    server_fd = *(int*)parameters;

       frontQ.store = 0; frontQ.retrieve = 0;
              for(;;)
              {
                    if((int)(frontQ.store)>(int)(frontQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = ( ANT_CMD*) frontq_retrieve((int)frontQ.retrieve);
                        pthread_mutex_unlock(&lock);
                      
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                         c1= &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"front_end"))
                                 {
                                         
                                    if((n= writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," ERROR Sending CMD to C00 FRONT END MCM device\n");}
                                       else
                                      { 
                                         printcmd(c1);   bzero(c1,sizeof(cmd));
                                        
                                      }
                                  }
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                        
                                   usleep(500000);
                                   bzero(r1,sizeof(resp));               
                              if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr,"ERROR READING C00 FRONT END MCM RESPONSE\n");
                                     terminate_thread(server_fd); 
                                  }
                              else if(n==0)
                            {
                              fprintf(stderr,"C00 FRONT END MCM closed it's Socket connection\n");
                               terminate_thread(server_fd);
                            }
                              else
                              {
                                    printresp(r1);
                                    write_shm(a1,r1); 
                                    bzero(r1,sizeof(resp));
                                   fprintf(stderr," Writing to ONLINE from FRONT END SUCCESSFUL\n");
                                  
                               } 
                           
                             frontQ.retrieve++;                      
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                       
                       }
                       
                      else
                         { // Periodic Monitoring in the background
                            bzero(c1,sizeof(cmd));
                           strcpy(a1->antenna_name,"C00");
                           strcpy(a1->CMD.system_name,"front_end");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                            tstamp = tp(tstamp);
                            strcpy(a1->CMD.timestamp,tstamp);
                            c1 = &a1->CMD;
                     
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to C00 FRONT END MCM device\n"); }
                            else
                            {// printcmd(c1);
                            }
                             sleep(1);
                             bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                           { fprintf(stderr," ERROR READING C00 FRONTEND MCM RESPONSE\n"); 
                               terminate_thread(server_fd);
                           }
                             
                           else if(n==0)
                            {
                              fprintf(stderr,"C00 FRONT END MCM closed it's Socket connection\n");
                               terminate_thread(server_fd);
                            }
                           
                           else
                           {
                             //printresp(r1);
                              write_shm(a1,r1); 
                            
                           }
                        
                         }
                    }
     free(a1);
  free(r1);
  free(c1);
   return NULL;
}


void* backend_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1 = malloc(sizeof(ANT_CMD));
  
     cmd *c1;
     c1 = malloc(sizeof(cmd));
   
     char *tstamp;
     tstamp = malloc(25);
     resp *r1;
    r1 = malloc(sizeof(resp));
    server_fd = *(int*)parameters;
  
       backQ.store = 0; backQ.retrieve = 0;
              for(;;)
              {
                    if((int)(backQ.store)>(int)(backQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = (ANT_CMD *) backq_retrieve((int)backQ.retrieve);
                       pthread_mutex_unlock(&lock);
                        
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                        c1= &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"back_end"))
                                 {
                                         
                                    if((n= writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," Sending CMD to C00 BACKEND MCM device\n");}
                                       else
                                      { 
                                         printcmd(c1);bzero(c1,sizeof(cmd));
                                        
                                      }
                                  }
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                        
                                   usleep(500000);
                                   bzero(r1,sizeof(resp));               
                              if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr,"ERROR READING C00 BACKEND MCM RESPONSE\n"); 
                                     terminate_thread(server_fd);
                                  }
                               else if(n==0)
                               {
                                 fprintf(stderr,"C00 BACKEND MCM closed it's Socket connection\n");
                                  terminate_thread(server_fd);
                               }
                           
                              else
                              {
                                    printresp(r1);
                                    write_shm(a1,r1); 
                                    bzero(r1,sizeof(resp));
                                    fprintf(stderr," Writing to ONLINE from BACKEND THREAD SUCCESSFUL\n");
                              } 
                           
                             backQ.retrieve++;                      
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                      
                       }
                       else
                         { // Periodic Monitoring in the background
                             bzero(c1,sizeof(cmd));
                            strcpy(a1->antenna_name,"C00");
                           strcpy(a1->CMD.system_name,"back_end");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                            tstamp = tp(tstamp);
                            strcpy(a1->CMD.timestamp,tstamp);
                            c1 = &a1->CMD;
                            
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to C00 BACKEND MCM device\n"); }
                            else
                            {// printcmd(c1);
                            }
                             sleep(1);
                             bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                           { fprintf(stderr," ERROR READING C00 back END MCM RESPONSE\n");
                              terminate_thread(server_fd);
                           }
                             
                           else if(n==0)
                            {
                              fprintf(stderr,"C00 BACKEND MCM closed it's Socket connection\n");
                               terminate_thread(server_fd);
                            }
                           
                           else
                           {
                             //printresp(r1);
                              write_shm(a1,r1); 
                             
                           } 
                            
                         }
                          
                    }
     free(a1);
  free(r1);
  free(c1);
   return NULL;
}


void* self_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1= malloc(sizeof(ANT_CMD));
 
     cmd *c1;
     c1 = malloc(sizeof(cmd));
   
     char *tstamp;
     tstamp = malloc(25);
     resp *r1;
    r1 = malloc(sizeof(resp));
    server_fd = *(int*)parameters;
   
       selfQ.store = 0; selfQ.retrieve = 0;
              for(;;)
              {
                    if((int)(selfQ.store)>(int)(selfQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = (ANT_CMD *) selfq_retrieve((int)selfQ.retrieve);
                        pthread_mutex_unlock(&lock);
                        
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                        c1= &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"self_test"))
                                 {
                                         
                                    if((n= writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," Sending CMD to C00 SELF SYSTEM MCM device\n");}
                                       else
                                      { 
                                         printcmd(c1); bzero(c1,sizeof(cmd));
                                         //bzero(c1,sizeof(cmd));
                                      }
                                  }
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                                     
                                   bzero(r1,sizeof(resp));               
                              if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr,"ERROR READING C00 SELF SYSTEM MCM RESPONSE\n");
                                     terminate_thread(server_fd);
                                  }
                                else if(n==0)
                            {
                              fprintf(stderr,"C00 SELF SYSTEM MCM closed it's Socket connection\n");
                               terminate_thread(server_fd);
                            }
                              else
                              {
                                    printresp(r1);
                                    write_shm(a1,r1); 
                                      bzero(r1,sizeof(resp));
                                     fprintf(stderr," Writing to ONLINE SUCCESSFUL\n");
                                   
                                                                                    
                               }
                            
                             selfQ.retrieve++;                      
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                       }
                       else
                         { // Periodic Monitoring in the background 
                             bzero(c1,sizeof(cmd));
                           strcpy(a1->antenna_name,"C00");
                           strcpy(a1->CMD.system_name,"self_test");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                            tstamp = tp(tstamp);
                            strcpy(a1->CMD.timestamp,tstamp);
                            c1 = &a1->CMD;
                           
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to MCM device\n"); }
                            else
                            {// printcmd(c1);
                            }
                             sleep(1);
                             bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                           { fprintf(stderr," ERROR READING C00 SELF SYSTEM MCM RESPONSE\n");
                              terminate_thread(server_fd);
                           }
                             
                           else if(n==0)
                            {
                              fprintf(stderr,"C00 SELF SYSTEM MCM closed it's Socket connection\n");
                                terminate_thread(server_fd);
                            }
                           
                           else
                           {
                             //printresp(r1);
                              write_shm(a1,r1); 
                           }
                          
                         }
                    }
  free(a1);
  free(r1);
  free(c1);
   return NULL;
}

/*************************************** C01 Antenna syste Thread functions here ******/

void* C01_sentinel_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1 = malloc(sizeof(ANT_CMD));
   
     cmd *c1;
     c1 = malloc(sizeof(cmd));
  
     resp *r1;
    r1 = malloc(sizeof(resp));
    server_fd = *(int*)parameters;
     char *tstamp;
     tstamp = malloc(25);
  
       c1senQ.store = 0; c1senQ.retrieve = 0;
              for(;;)
              {
                   if((int)(c1senQ.store)>(int)(c1senQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = (ANT_CMD *) c1_senq_retrieve((int)c1senQ.retrieve);
                       pthread_mutex_unlock(&lock);
                        
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                        c1 = &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"sentinel"))
                                 {
                                    
                                    if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," ERROR Sending CMD C01 sentinel MCM device\n"); }
                                    else
                                   { 
                                         printcmd(c1); bzero(c1,sizeof(cmd));
                                        // bzero(c1,sizeof(cmd));   
                                         
                                    }
                                  } 
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                        
                                  usleep(500000);
                                 bzero(r1,sizeof(resp)); 
                              if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr," ERROR READING C01 sentinel MCM RESPONSE\n");  
                                     terminate_thread(server_fd); }
                               else if(n==0)
                                {
                                  fprintf(stderr,"C01 sentinel MCM closed it's Socket connection\n");
                                   terminate_thread(server_fd);
                                }     
                            else
                              {
                                    printresp(r1);
                                    write_shm(a1,r1); 
                                    bzero(r1,sizeof(resp));
                                   fprintf(stderr," Writing to ONLINE from SENTINEL THREAD SUCCESSFUL\n");
                               } 
                             c1senQ.retrieve++; 
                                             
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                        
                       }
                       else
                         { // Periodic Monitoring in the background 
                            bzero(c1,sizeof(cmd));
                           strcpy(a1->antenna_name,"C01");
                           strcpy(a1->CMD.system_name,"sentinel");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                            tstamp = tp(tstamp);
                            strcpy(a1->CMD.timestamp,tstamp);
                            c1 = &a1->CMD;
                            
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to C01 sentinel MCM MCM device\n"); }
                            else
                            {// printcmd(c1);
                            }
                             sleep(1);
                             bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                           { fprintf(stderr," ERROR READING C01 Sentinel MCM RESPONSE\n"); terminate_thread(server_fd);  }
                            else if(n==0)
                            {
                              fprintf(stderr,"C01 sentinel MCM closed it's Socket connection\n");
                                terminate_thread(server_fd);
                            }
                           else
                           {
                           
                                write_shm(a1,r1); 
                           } 
                         
                         }
                    }
     free(a1);
  free(r1);
  free(c1);
   return NULL;
}

void* C01_fiber_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1 = malloc(sizeof(ANT_CMD));
  
     cmd *c1;
     c1 = malloc(sizeof(cmd));
      char *tstamp;
     tstamp = malloc(25);
    
     resp *r1;
    r1 = malloc(sizeof(resp));
    server_fd = *(int*)parameters;
 
       c1fiberQ.store = 0; c1fiberQ.retrieve = 0;
              for(;;)
              {
                    if((int)(c1fiberQ.store)>(int)(c1fiberQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = (ANT_CMD*) c1_fiberq_retrieve((int)c1fiberQ.retrieve);
                       pthread_mutex_unlock(&lock);
                       
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                         c1= &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"fiber_optics"))
                                 {
                                         
                                    if((n= writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," ERROR Sending CMD to C01 FIBER OPTICS MCM device\n");}
                                       else
                                      { 
                                         printcmd(c1);  bzero(c1,sizeof(cmd));
                                       
                                      }
                                  }
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                        
                                    usleep(500000);
                                   bzero(r1,sizeof(resp));               
                              if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr,"ERROR READING C01 FIBER OPTICS MCM RESPONSE\n"); terminate_thread(server_fd); }
                                else if(n==0)
                                {
                                 fprintf(stderr,"C01 FIBER OPTICS MCM closed it's Socket connection\n");
                                  terminate_thread(server_fd);
                               } 
                              else
                              {
                                     printresp(r1);
                                     write_shm(a1,r1);                  
                                     fprintf(stderr," Writing to ONLINE from FIBER THREAD SUCCESSFUL\n");
                               } 
                            
                             c1fiberQ.retrieve++;                      
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                       }
                      else
                         { // Periodic Monitoring in the background 
                            bzero(c1,sizeof(cmd));
                           strcpy(a1->antenna_name,"C01");
                           strcpy(a1->CMD.system_name,"fiber_optics");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                            tstamp = tp(tstamp);
                            strcpy(a1->CMD.timestamp,tstamp);
                            c1 = &a1->CMD;
                            
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to C01 FIBER OPTICS MCM device\n"); }
                            else
                            {// printcmd(c1);
                            }
                             sleep(1);
                             bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                           { fprintf(stderr," ERROR READING C01  FIBER OPTICS MCM RESPONSE\n");shutdown(server_fd,SHUT_RDWR);
                                     close(server_fd);
                                     pthread_exit(NULL);  }
                             else if(n==0)
                            {
                              fprintf(stderr,"C01 FIBER OPTICS MCM closed it's Socket connection\n");
                               terminate_thread(server_fd);
                            } 
                           else
                           {
                             
                                write_shm(a1,r1);  
                            
                           } 
                          
                         }
                    }
     free(a1);
  free(r1);
  free(c1);
   return NULL;
}

void* C01_front_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1 = malloc(sizeof(ANT_CMD));
 
     cmd *c1;
     c1 = malloc(sizeof(cmd));
   
      char *tstamp;
     tstamp = malloc(25);
     resp *r1;
    r1 = malloc(sizeof(resp));
    server_fd = *(int*)parameters;
 
       c1frontQ.store = 0; c1frontQ.retrieve = 0;
              for(;;)
              {
                    if((int)(c1frontQ.store)>(int)(c1frontQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = ( ANT_CMD*) c1_frontq_retrieve((int)c1frontQ.retrieve);
                       pthread_mutex_unlock(&lock);
                       
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                         c1= &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"front_end"))
                                 {
                                         
                                    if((n= writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," ERROR Sending CMD to C01 FRONT END MCM device\n");}
                                       else
                                      { 
                                         printcmd(c1);  bzero(c1,sizeof(cmd));
                                         //bzero(c1,sizeof(cmd));
                                      }
                                  }
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                        
                                   usleep(500000);
                                   bzero(r1,sizeof(resp));               
                              if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr,"ERROR READING C01 FRONT END MCM RESPONSE\n"); 
                                    terminate_thread(server_fd);}
                               else if(n==0)
                              {
                                fprintf(stderr,"C01 FRONT END MCM closed it's Socket connection\n");
                                 terminate_thread(server_fd);
                              }
                              else
                              { printresp(r1); write_shm(a1,r1);  }
                           
                             c1frontQ.retrieve++;                      
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                       
                       }
                     else
                         { // Periodic Monitoring in the background 
                            bzero(c1,sizeof(cmd));
                           strcpy(a1->antenna_name,"C01");
                           strcpy(a1->CMD.system_name,"front_end");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                           tstamp = tp(tstamp);
                           strcpy(a1->CMD.timestamp,tstamp);
                           c1 = &a1->CMD;
                              
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to C01 FRONT END MCM device\n"); }
                            else
                            {// printcmd(c1);
                            }
                             sleep(1);
                             bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                           { fprintf(stderr," ERROR READING C01 FRONT END MCM RESPONSE\n"); terminate_thread(server_fd); }
                             else if(n==0)
                            {
                              fprintf(stderr,"C01 FRONT END MCM closed it's Socket connection\n");
                               terminate_thread(server_fd);
                            }
                           else
                           { write_shm(a1,r1);  }
                          
                         }
                    }
     free(a1);
  free(r1);
  free(c1);
   return NULL;
}


void* C01_backend_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1 = malloc(sizeof(ANT_CMD));
   
     cmd *c1;
     c1 = malloc(sizeof(cmd));
   
        char *tstamp;
     tstamp = malloc(25);
     resp *r1;
    r1 = malloc(sizeof(resp));
    server_fd = *(int*)parameters;
  
       c1backQ.store = 0; c1backQ.retrieve = 0;
              for(;;)
              {
                    if((int)(c1backQ.store)>(int)(c1backQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = (ANT_CMD *) c1_backq_retrieve((int)c1backQ.retrieve);
                        pthread_mutex_unlock(&lock);
                        
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                        c1= &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"back_end"))
                                 {
                                         
                                    if((n= writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," Sending CMD to C01 BACK END MCM device\n");}
                                       else
                                      { 
                                         printcmd(c1); bzero(c1,sizeof(cmd));
                                         //bzero(c1,sizeof(cmd));
                                      }
                                  }
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                        
                                   usleep(500000);
                                   bzero(r1,sizeof(resp));               
                              if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr,"ERROR READING C01 BACK END MCM RESPONSE\n");
                                    terminate_thread(server_fd);}
                                else if(n==0)
                               {
                                 fprintf(stderr,"C01 BACK END MCM closed it's Socket connection\n");
                                  terminate_thread(server_fd);
                               } 
                              else
                              { printresp(r1);write_shm(a1,r1); } 
                           
                             c1backQ.retrieve++;                      
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                        
                       }
                      else
                         { // Periodic Monitoring in the background
                            bzero(c1,sizeof(cmd));
                           strcpy(a1->antenna_name,"C01");
                           strcpy(a1->CMD.system_name,"back_end");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                            tstamp = tp(tstamp);
                            strcpy(a1->CMD.timestamp,tstamp);
                            c1 = &a1->CMD;
                            
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to C01 BACK END MCM device\n"); }
                            else
                            {// printcmd(c1);
                            }
                             sleep(1);
                             bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                           { fprintf(stderr," ERROR READING C01 Back END MCM RESPONSE\n"); terminate_thread(server_fd); }
                             else if(n==0)
                            {
                              fprintf(stderr,"C01 BACK END MCM closed it's Socket connection\n");
                               terminate_thread(server_fd);
                            } 
                           else
                           { write_shm(a1,r1); }
                       
                         }
                    }
     free(a1);
  free(r1);
  free(c1);
   return NULL;
}


void* C01_self_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1= malloc(sizeof(ANT_CMD));
  
     cmd *c1;
     c1 = malloc(sizeof(cmd));
  
     char *tstamp;
     tstamp = malloc(25);
     resp *r1;
    r1 = malloc(sizeof(resp));
    server_fd = *(int*)parameters;
  
       c1selfQ.store = 0; c1selfQ.retrieve = 0;
              for(;;)
              {
                    if((int)(c1selfQ.store)>(int)(c1selfQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = (ANT_CMD *) c1_selfq_retrieve((int)c1selfQ.retrieve);
                       pthread_mutex_unlock(&lock);
                       
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                        c1= &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"self_test"))
                                 {
                                         
                                    if((n= writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," Sending CMD to MCM device\n");}
                                       else
                                      { 
                                         printcmd(c1); bzero(c1,sizeof(cmd));
                                         //bzero(c1,sizeof(cmd));
                                      }
                                  }
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                                     
                                   bzero(r1,sizeof(resp));               
                              if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr,"ERROR READING C01  SELF SYSTEM  MCM RESPONSE\n"); 
                                     terminate_thread(server_fd); }
                              else if(n==0)
                            {
                              fprintf(stderr,"C01  SELF SYSTEM MCM closed it's Socket connection\n");
                               terminate_thread(server_fd); 
                            }
                              else
                              { write_shm(a1,r1); } 
                           
                             c1selfQ.retrieve++;                      
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                       }
                     else
                         { // Periodic Monitoring in the background 
                           bzero(c1,sizeof(cmd));
                           strcpy(a1->antenna_name,"C01");
                           strcpy(a1->CMD.system_name,"self_test");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                            tstamp = tp(tstamp);
                            strcpy(a1->CMD.timestamp,tstamp);
                            c1 = &a1->CMD;
                            
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to C01  SELF SYSTEM  MCM device\n"); }
                            else
                            {// printcmd(c1);
                            }
                             sleep(1);
                             bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                            { fprintf(stderr," ERROR READING C01 Self Test MCM RESPONSE\n"); terminate_thread(server_fd);}
                             else if(n==0)
                            {
                              fprintf(stderr,"C01  SELF SYSTEM MCM closed it's Socket connection\n");
                               terminate_thread(server_fd);
                            }
                           else
                           { write_shm(a1,r1); } 
                           
                         }
                    }
  free(a1);
  free(r1);
  free(c1);
   return NULL;
}

/*************************************** C02 Antenna syste Thread functions here ******/

void* C02_sentinel_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1 = malloc(sizeof(ANT_CMD));
   
     cmd *c1;
     c1 = malloc(sizeof(cmd));
  
     resp *r1;
    r1 = malloc(sizeof(resp));
    server_fd = *(int*)parameters;
     char *tstamp;
     tstamp = malloc(25);
  
       c2senQ.store = 0; c2senQ.retrieve = 0;
              for(;;)
              {
                   if((int)(c2senQ.store)>(int)(c2senQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = (ANT_CMD *) c2_senq_retrieve((int)c2senQ.retrieve);
                       pthread_mutex_unlock(&lock);
                        
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                        c1 = &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"sentinel"))
                                 {
                                    
                                    if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," ERROR Sending CMD C02 sentinel MCM device\n"); }
                                    else
                                   { 
                                         printcmd(c1); bzero(c1,sizeof(cmd));
                                        // bzero(c1,sizeof(cmd));   
                                         
                                    }
                                  } 
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                        
                                  usleep(500000);
                                 bzero(r1,sizeof(resp)); 
                              if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr," ERROR READING C02 sentinel MCM RESPONSE\n");  
                                     terminate_thread(server_fd); }
                               else if(n==0)
                                {
                                  fprintf(stderr,"C02 sentinel MCM closed it's Socket connection\n");
                                   terminate_thread(server_fd);
                                }     
                            else
                              {
                                    printresp(r1);
                                    write_shm(a1,r1); 
                                    bzero(r1,sizeof(resp));
                                   fprintf(stderr," Writing to ONLINE from SENTINEL THREAD SUCCESSFUL\n");
                               } 
                             c2senQ.retrieve++; 
                                             
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                        
                       }
                       else
                         { // Periodic Monitoring in the background 
                            bzero(c1,sizeof(cmd));
                           strcpy(a1->antenna_name,"C02");
                           strcpy(a1->CMD.system_name,"sentinel");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                            tstamp = tp(tstamp);
                            strcpy(a1->CMD.timestamp,tstamp);
                            c1 = &a1->CMD;
                            
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to C02 sentinel MCM MCM device\n"); }
                            else
                            {// printcmd(c1);
                            }
                             sleep(1);
                             bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                           { fprintf(stderr," ERROR READING C02 Sentinel MCM RESPONSE\n"); terminate_thread(server_fd);  }
                            else if(n==0)
                            {
                              fprintf(stderr,"C02 sentinel MCM closed it's Socket connection\n");
                                terminate_thread(server_fd);
                            }
                           else
                           {
                           
                                write_shm(a1,r1); 
                           } 
                         
                         }
                    }
     free(a1);
  free(r1);
  free(c1);
   return NULL;
}

void* C02_fiber_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1 = malloc(sizeof(ANT_CMD));
  
     cmd *c1;
     c1 = malloc(sizeof(cmd));
      char *tstamp;
     tstamp = malloc(25);
    
     resp *r1;
    r1 = malloc(sizeof(resp));
    server_fd = *(int*)parameters;
 
       c2fiberQ.store = 0; c2fiberQ.retrieve = 0;
              for(;;)
              {
                    if((int)(c2fiberQ.store)>(int)(c2fiberQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = (ANT_CMD*) c2_fiberq_retrieve((int)c2fiberQ.retrieve);
                       pthread_mutex_unlock(&lock);
                       
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                         c1= &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"fiber_optics"))
                                 {
                                         
                                    if((n= writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," ERROR Sending CMD to C02 FIBER OPTICS MCM device\n");}
                                       else
                                      { 
                                         printcmd(c1);  bzero(c1,sizeof(cmd));
                                       
                                      }
                                  }
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                        
                                    usleep(500000);
                                   bzero(r1,sizeof(resp));               
                              if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr,"ERROR READING C02 FIBER OPTICS MCM RESPONSE\n");
                                    terminate_thread(server_fd); }
                                else if(n==0)
                                {
                                 fprintf(stderr,"C02 FIBER OPTICS MCM closed it's Socket connection\n");
                                  terminate_thread(server_fd);
                               } 
                              else
                              {
                                     printresp(r1);
                                     write_shm(a1,r1);                  
                                     fprintf(stderr," Writing to ONLINE from FIBER THREAD SUCCESSFUL\n");
                               } 
                            
                             c2fiberQ.retrieve++;                      
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                       }
                      else
                         { // Periodic Monitoring in the background 
                            bzero(c1,sizeof(cmd));
                           strcpy(a1->antenna_name,"C02");
                           strcpy(a1->CMD.system_name,"fiber_optics");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                            tstamp = tp(tstamp);
                            strcpy(a1->CMD.timestamp,tstamp);
                            c1 = &a1->CMD;
                            
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to C02 FIBER OPTICS MCM device\n"); }
                            else
                            {// printcmd(c1);
                            }
                             sleep(1);
                             bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                           { fprintf(stderr," ERROR READING C02  FIBER OPTICS MCM RESPONSE\n");
                                     shutdown(server_fd,SHUT_RDWR);
                                     close(server_fd);
                                     pthread_exit(NULL);  }
                             else if(n==0)
                            {
                              fprintf(stderr,"C02 FIBER OPTICS MCM closed it's Socket connection\n");
                               terminate_thread(server_fd);
                            } 
                           else
                           {
                              write_shm(a1,r1);  
                            
                           } 
                          
                         }
                    }
     free(a1);
  free(r1);
  free(c1);
   return NULL;
}

void* C02_front_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1 = malloc(sizeof(ANT_CMD));
 
     cmd *c1;
     c1 = malloc(sizeof(cmd));
   
      char *tstamp;
     tstamp = malloc(25);
     resp *r1;
    r1 = malloc(sizeof(resp));
    server_fd = *(int*)parameters;
 
       c2frontQ.store = 0; c2frontQ.retrieve = 0;
              for(;;)
              {
                    if((int)(c2frontQ.store)>(int)(c2frontQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = ( ANT_CMD*) c2_frontq_retrieve((int)c2frontQ.retrieve);
                       pthread_mutex_unlock(&lock);
                       
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                         c1= &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"front_end"))
                                 {
                                         
                                    if((n= writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," ERROR Sending CMD to C02 FRONT END MCM device\n");}
                                       else
                                      { 
                                         printcmd(c1);  bzero(c1,sizeof(cmd));
                                         //bzero(c1,sizeof(cmd));
                                      }
                                  }
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                        
                                   usleep(500000);
                                   bzero(r1,sizeof(resp));               
                              if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr,"ERROR READING C02 FRONT END MCM RESPONSE\n"); 
                                    terminate_thread(server_fd);}
                               else if(n==0)
                              {
                                fprintf(stderr,"C02 FRONT END MCM closed it's Socket connection\n");
                                 terminate_thread(server_fd);
                              }
                              else
                              { printresp(r1); write_shm(a1,r1);  }
                           
                             c2frontQ.retrieve++;                      
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                       
                       }
                     else
                         { // Periodic Monitoring in the background 
                            bzero(c1,sizeof(cmd));
                           strcpy(a1->antenna_name,"C02");
                           strcpy(a1->CMD.system_name,"front_end");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                           tstamp = tp(tstamp);
                           strcpy(a1->CMD.timestamp,tstamp);
                           c1 = &a1->CMD;
                              
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to C02 FRONT END MCM device\n"); }
                            else
                            {// printcmd(c1);
                            }
                             sleep(1);
                             bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                           { fprintf(stderr," ERROR READING C02 FRONT END MCM RESPONSE\n"); terminate_thread(server_fd); }
                             else if(n==0)
                            {
                              fprintf(stderr,"C02 FRONT END MCM closed it's Socket connection\n");
                               terminate_thread(server_fd);
                            }
                           else
                           { write_shm(a1,r1);  }
                          
                         }
                    }
     free(a1);
  free(r1);
  free(c1);
   return NULL;
}


void* C02_backend_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1 = malloc(sizeof(ANT_CMD));
   
     cmd *c1;
     c1 = malloc(sizeof(cmd));
   
        char *tstamp;
     tstamp = malloc(25);
     resp *r1;
    r1 = malloc(sizeof(resp));
    server_fd = *(int*)parameters;
  
       c2backQ.store = 0; c2backQ.retrieve = 0;
              for(;;)
              {
                    if((int)(c2backQ.store)>(int)(c2backQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = (ANT_CMD *) c2_backq_retrieve((int)c2backQ.retrieve);
                        pthread_mutex_unlock(&lock);
                        
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                        c1= &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"back_end"))
                                 {
                                         
                                    if((n= writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," Sending CMD to C02 BACK END MCM device\n");}
                                       else
                                      { 
                                         printcmd(c1); bzero(c1,sizeof(cmd));
                                         //bzero(c1,sizeof(cmd));
                                      }
                                  }
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                        
                                   usleep(500000);
                                   bzero(r1,sizeof(resp));               
                              if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr,"ERROR READING C02 BACK END MCM RESPONSE\n");
                                    terminate_thread(server_fd);}
                                else if(n==0)
                               {
                                 fprintf(stderr,"C02 BACK END MCM closed it's Socket connection\n");
                                  terminate_thread(server_fd);
                               } 
                              else
                              { printresp(r1);write_shm(a1,r1); } 
                           
                             c2backQ.retrieve++;                      
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                        
                       }
                      else
                         { // Periodic Monitoring in the background
                            bzero(c1,sizeof(cmd));
                           strcpy(a1->antenna_name,"C02");
                           strcpy(a1->CMD.system_name,"back_end");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                            tstamp = tp(tstamp);
                            strcpy(a1->CMD.timestamp,tstamp);
                            c1 = &a1->CMD;
                            
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to C02 BACK END MCM device\n"); }
                            else
                            {// printcmd(c1);
                            }
                             sleep(1);
                             bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                           { fprintf(stderr," ERROR READING C02 Back END MCM RESPONSE\n"); terminate_thread(server_fd); }
                             else if(n==0)
                            {
                              fprintf(stderr,"C02 BACK END MCM closed it's Socket connection\n");
                               terminate_thread(server_fd);
                            } 
                           else
                           { write_shm(a1,r1); }
                       
                         }
                    }
     free(a1);
  free(r1);
  free(c1);
   return NULL;
}


void* C02_self_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1= malloc(sizeof(ANT_CMD));
  
     cmd *c1;
     c1 = malloc(sizeof(cmd));
  
     char *tstamp;
     tstamp = malloc(25);
     resp *r1;
    r1 = malloc(sizeof(resp));
    server_fd = *(int*)parameters;
  
       c2selfQ.store = 0; c2selfQ.retrieve = 0;
              for(;;)
              {
                    if((int)(c2selfQ.store)>(int)(c2selfQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = (ANT_CMD *) c2_selfq_retrieve((int)c2selfQ.retrieve);
                       pthread_mutex_unlock(&lock);
                       
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                        c1= &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"self_test"))
                                 {
                                         
                                    if((n= writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," Sending CMD to MCM device\n");}
                                       else
                                      { 
                                         printcmd(c1); bzero(c1,sizeof(cmd));
                                         //bzero(c1,sizeof(cmd));
                                      }
                                  }
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                                     
                                   bzero(r1,sizeof(resp));               
                              if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr,"ERROR READING C02  SELF SYSTEM  MCM RESPONSE\n"); 
                                     terminate_thread(server_fd); }
                              else if(n==0)
                            {
                              fprintf(stderr,"C02 SELF SYSTEM MCM closed it's Socket connection\n");
                               terminate_thread(server_fd); 
                            }
                              else
                              { write_shm(a1,r1); } 
                           
                             c2selfQ.retrieve++;                      
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                       }
                     else
                         { // Periodic Monitoring in the background 
                           bzero(c1,sizeof(cmd));
                           strcpy(a1->antenna_name,"C02");
                           strcpy(a1->CMD.system_name,"self_test");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                            tstamp = tp(tstamp);
                            strcpy(a1->CMD.timestamp,tstamp);
                            c1 = &a1->CMD;
                            
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to C02  SELF SYSTEM  MCM device\n"); }
                            else
                            {// printcmd(c1);
                            }
                             sleep(1);
                             bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                            { fprintf(stderr," ERROR READING C02 Self Test MCM RESPONSE\n"); terminate_thread(server_fd);}
                             else if(n==0)
                            {
                              fprintf(stderr,"C02  SELF SYSTEM MCM closed it's Socket connection\n");
                               terminate_thread(server_fd);
                            }
                           else
                           { write_shm(a1,r1); } 
                           
                         }
                    }
  free(a1);
  free(r1);
  free(c1);
   return NULL;
}

/*************************************** C03 Antenna syste Thread functions here ******/

void* C03_sentinel_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1 = malloc(sizeof(ANT_CMD));
   
     cmd *c1;
     c1 = malloc(sizeof(cmd));
  
     resp *r1;
    r1 = malloc(sizeof(resp));
    server_fd = *(int*)parameters;
     char *tstamp;
     tstamp = malloc(25);
  
       c3senQ.store = 0; c3senQ.retrieve = 0;
              for(;;)
              {
                   if((int)(c3senQ.store)>(int)(c3senQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = (ANT_CMD *) c3_senq_retrieve((int)c3senQ.retrieve);
                       pthread_mutex_unlock(&lock);
                        
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                        c1 = &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"sentinel"))
                                 {
                                    
                                    if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," ERROR Sending CMD C03 sentinel MCM device\n"); }
                                    else
                                   { 
                                         printcmd(c1); bzero(c1,sizeof(cmd));
                                        // bzero(c1,sizeof(cmd));   
                                         
                                    }
                                  } 
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                        
                                  usleep(500000);
                                 bzero(r1,sizeof(resp)); 
                              if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr," ERROR READING C03 sentinel MCM RESPONSE\n");  
                                     terminate_thread(server_fd); }
                               else if(n==0)
                                {
                                  fprintf(stderr,"C03 sentinel MCM closed it's Socket connection\n");
                                   terminate_thread(server_fd);
                                }     
                            else
                              {
                                    printresp(r1);
                                    write_shm(a1,r1); 
                                    bzero(r1,sizeof(resp));
                                   fprintf(stderr," Writing to ONLINE from SENTINEL THREAD SUCCESSFUL\n");
                               } 
                             c3senQ.retrieve++; 
                                             
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                        
                       }
                       else
                         { // Periodic Monitoring in the background 
                            bzero(c1,sizeof(cmd));
                           strcpy(a1->antenna_name,"C03");
                           strcpy(a1->CMD.system_name,"sentinel");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                            tstamp = tp(tstamp);
                            strcpy(a1->CMD.timestamp,tstamp);
                            c1 = &a1->CMD;
                            
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to C03 sentinel MCM MCM device\n"); }
                            else
                            {// printcmd(c1);
                            }
                             sleep(1);
                             bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                           { fprintf(stderr," ERROR READING C03 Sentinel MCM RESPONSE\n"); terminate_thread(server_fd);  }
                            else if(n==0)
                            {
                              fprintf(stderr,"C01 sentinel MCM closed it's Socket connection\n");
                                terminate_thread(server_fd);
                            }
                           else
                           {
                           
                                write_shm(a1,r1); 
                           } 
                         
                         }
                    }
     free(a1);
  free(r1);
  free(c1);
   return NULL;
}

void* C03_fiber_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1 = malloc(sizeof(ANT_CMD));
  
     cmd *c1;
     c1 = malloc(sizeof(cmd));
      char *tstamp;
     tstamp = malloc(25);
    
     resp *r1;
    r1 = malloc(sizeof(resp));
    server_fd = *(int*)parameters;
 
       c3fiberQ.store = 0; c3fiberQ.retrieve = 0;
              for(;;)
              {
                    if((int)(c3fiberQ.store)>(int)(c3fiberQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = (ANT_CMD*) c3_fiberq_retrieve((int)c3fiberQ.retrieve);
                       pthread_mutex_unlock(&lock);
                       
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                         c1= &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"fiber_optics"))
                                 {
                                         
                                    if((n= writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," ERROR Sending CMD to C03 FIBER OPTICS MCM device\n");}
                                       else
                                      { 
                                         printcmd(c1);  bzero(c1,sizeof(cmd));
                                       
                                      }
                                  }
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                        
                                    usleep(500000);
                                   bzero(r1,sizeof(resp));               
                              if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr,"ERROR READING C03 FIBER OPTICS MCM RESPONSE\n"); terminate_thread(server_fd); }
                                else if(n==0)
                                {
                                 fprintf(stderr,"C03 FIBER OPTICS MCM closed it's Socket connection\n");
                                  terminate_thread(server_fd);
                               } 
                              else
                              {
                                     printresp(r1);
                                     write_shm(a1,r1);                  
                                     fprintf(stderr," Writing to ONLINE from FIBER THREAD SUCCESSFUL\n");
                               } 
                            
                             c3fiberQ.retrieve++;                      
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                       }
                      else
                         { // Periodic Monitoring in the background 
                            bzero(c1,sizeof(cmd));
                           strcpy(a1->antenna_name,"C03");
                           strcpy(a1->CMD.system_name,"fiber_optics");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                            tstamp = tp(tstamp);
                            strcpy(a1->CMD.timestamp,tstamp);
                            c1 = &a1->CMD;
                            
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to C03 FIBER OPTICS MCM device\n"); }
                            else
                            {// printcmd(c1);
                            }
                             sleep(1);
                             bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                           { fprintf(stderr," ERROR READING C03  FIBER OPTICS MCM RESPONSE\n");shutdown(server_fd,SHUT_RDWR);
                                     close(server_fd);
                                     pthread_exit(NULL);  }
                             else if(n==0)
                            {
                              fprintf(stderr,"C03 FIBER OPTICS MCM closed it's Socket connection\n");
                               terminate_thread(server_fd);
                            } 
                           else
                           {
                             
                                write_shm(a1,r1);  
                            
                           } 
                          
                         }
                    }
     free(a1);
  free(r1);
  free(c1);
   return NULL;
}

void* C03_front_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1 = malloc(sizeof(ANT_CMD));
 
     cmd *c1;
     c1 = malloc(sizeof(cmd));
   
      char *tstamp;
     tstamp = malloc(25);
     resp *r1;
    r1 = malloc(sizeof(resp));
    server_fd = *(int*)parameters;
 
       c3frontQ.store = 0; c3frontQ.retrieve = 0;
              for(;;)
              {
                    if((int)(c3frontQ.store)>(int)(c3frontQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = ( ANT_CMD*) c3_frontq_retrieve((int)c3frontQ.retrieve);
                       pthread_mutex_unlock(&lock);
                       
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                         c1= &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"front_end"))
                                 {
                                         
                                    if((n= writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," ERROR Sending CMD to C03 FRONT END MCM device\n");}
                                       else
                                      { 
                                         printcmd(c1);  bzero(c1,sizeof(cmd));
                                         //bzero(c1,sizeof(cmd));
                                      }
                                  }
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                        
                                   usleep(500000);
                                   bzero(r1,sizeof(resp));               
                              if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr,"ERROR READING C03 FRONT END MCM RESPONSE\n"); 
                                    terminate_thread(server_fd);}
                               else if(n==0)
                              {
                                fprintf(stderr,"C03 FRONT END MCM closed it's Socket connection\n");
                                 terminate_thread(server_fd);
                              }
                              else
                              { printresp(r1); write_shm(a1,r1);  }
                           
                             c3frontQ.retrieve++;                      
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                       
                       }
                     else
                         { // Periodic Monitoring in the background 
                            bzero(c1,sizeof(cmd));
                           strcpy(a1->antenna_name,"C03");
                           strcpy(a1->CMD.system_name,"front_end");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                           tstamp = tp(tstamp);
                           strcpy(a1->CMD.timestamp,tstamp);
                           c1 = &a1->CMD;
                              
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to C03 FRONT END MCM device\n"); }
                            else
                            {// printcmd(c1);
                            }
                             sleep(1);
                             bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                           { fprintf(stderr," ERROR READING C03 FRONT END MCM RESPONSE\n"); terminate_thread(server_fd); }
                             else if(n==0)
                            {
                              fprintf(stderr,"C01 FRONT END MCM closed it's Socket connection\n");
                               terminate_thread(server_fd);
                            }
                           else
                           { write_shm(a1,r1);  }
                          
                         }
                    }
     free(a1);
  free(r1);
  free(c1);
   return NULL;
}


void* C03_backend_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1 = malloc(sizeof(ANT_CMD));
   
     cmd *c1;
     c1 = malloc(sizeof(cmd));
   
        char *tstamp;
     tstamp = malloc(25);
     resp *r1;
    r1 = malloc(sizeof(resp));
    server_fd = *(int*)parameters;
  
       c3backQ.store = 0; c3backQ.retrieve = 0;
              for(;;)
              {
                    if((int)(c3backQ.store)>(int)(c3backQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = (ANT_CMD *) c3_backq_retrieve((int)c3backQ.retrieve);
                        pthread_mutex_unlock(&lock);
                        
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                        c1= &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"back_end"))
                                 {
                                         
                                    if((n= writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," Sending CMD to C03 BACK END MCM device\n");}
                                       else
                                      { 
                                         printcmd(c1); bzero(c1,sizeof(cmd));
                                         //bzero(c1,sizeof(cmd));
                                      }
                                  }
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                        
                                   usleep(500000);
                                   bzero(r1,sizeof(resp));               
                              if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr,"ERROR READING C03 BACK END MCM RESPONSE\n");
                                    terminate_thread(server_fd);}
                                else if(n==0)
                               {
                                 fprintf(stderr,"C03 BACK END MCM closed it's Socket connection\n");
                                  terminate_thread(server_fd);
                               } 
                              else
                              { printresp(r1);write_shm(a1,r1); } 
                           
                             c3backQ.retrieve++;                      
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                        
                       }
                      else
                         { // Periodic Monitoring in the background
                            bzero(c1,sizeof(cmd));
                           strcpy(a1->antenna_name,"C03");
                           strcpy(a1->CMD.system_name,"back_end");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                            tstamp = tp(tstamp);
                            strcpy(a1->CMD.timestamp,tstamp);
                            c1 = &a1->CMD;
                            
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to C03 BACK END MCM device\n"); }
                            else
                            {// printcmd(c1);
                            }
                             sleep(1);
                             bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                           { fprintf(stderr," ERROR READING C03 Back END MCM RESPONSE\n"); terminate_thread(server_fd); }
                             else if(n==0)
                            {
                              fprintf(stderr,"C03 BACK END MCM closed it's Socket connection\n");
                               terminate_thread(server_fd);
                            } 
                           else
                           { write_shm(a1,r1); }
                       
                         }
                    }
     free(a1);
  free(r1);
  free(c1);
   return NULL;
}


void* C03_self_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1= malloc(sizeof(ANT_CMD));
  
     cmd *c1;
     c1 = malloc(sizeof(cmd));
  
     char *tstamp;
     tstamp = malloc(25);
     resp *r1;
    r1 = malloc(sizeof(resp));
    server_fd = *(int*)parameters;
  
       c3selfQ.store = 0; c3selfQ.retrieve = 0;
              for(;;)
              {
                    if((int)(c3selfQ.store)>(int)(c3selfQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = (ANT_CMD *) c3_selfq_retrieve((int)c3selfQ.retrieve);
                       pthread_mutex_unlock(&lock);
                       
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                        c1= &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"self_test"))
                                 {
                                         
                                    if((n= writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," Sending CMD to MCM device\n");}
                                       else
                                      { 
                                         printcmd(c1); bzero(c1,sizeof(cmd));
                                         //bzero(c1,sizeof(cmd));
                                      }
                                  }
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                                     
                                   bzero(r1,sizeof(resp));               
                              if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr,"ERROR READING C03  SELF SYSTEM  MCM RESPONSE\n"); 
                                     terminate_thread(server_fd); }
                              else if(n==0)
                            {
                              fprintf(stderr,"C03  SELF SYSTEM MCM closed it's Socket connection\n");
                               terminate_thread(server_fd); 
                            }
                              else
                              { write_shm(a1,r1); } 
                           
                             c3selfQ.retrieve++;                      
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                       }
                     else
                         { // Periodic Monitoring in the background 
                           bzero(c1,sizeof(cmd));
                           strcpy(a1->antenna_name,"C03");
                           strcpy(a1->CMD.system_name,"self_test");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                            tstamp = tp(tstamp);
                            strcpy(a1->CMD.timestamp,tstamp);
                            c1 = &a1->CMD;
                            
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to C03  SELF SYSTEM  MCM device\n"); }
                            else
                            {// printcmd(c1);
                            }
                             sleep(1);
                             bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                            { fprintf(stderr," ERROR READING C03 Self Test MCM RESPONSE\n"); terminate_thread(server_fd);}
                             else if(n==0)
                            {
                              fprintf(stderr,"C03  SELF SYSTEM MCM closed it's Socket connection\n");
                               terminate_thread(server_fd);
                            }
                           else
                           { write_shm(a1,r1); } 
                           
                         }
                    }
  free(a1);
  free(r1);
  free(c1);
   return NULL;
}

/*************************************** C04 Antenna syste Thread functions here ******/

void* C04_sentinel_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1 = malloc(sizeof(ANT_CMD));
   
     cmd *c1;
     c1 = malloc(sizeof(cmd));
  
     resp *r1;
    r1 = malloc(sizeof(resp));
    server_fd = *(int*)parameters;
     char *tstamp;
     tstamp = malloc(25);
  
       c4senQ.store = 0; c4senQ.retrieve = 0;
              for(;;)
              {
                   if((int)(c4senQ.store)>(int)(c4senQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = (ANT_CMD *) c4_senq_retrieve((int)c4senQ.retrieve);
                       pthread_mutex_unlock(&lock);
                        
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                        c1 = &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"sentinel"))
                                 {
                                    
                                    if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," ERROR Sending CMD C04 sentinel MCM device\n"); }
                                    else
                                   { 
                                         printcmd(c1); bzero(c1,sizeof(cmd));
                                        // bzero(c1,sizeof(cmd));   
                                         
                                    }
                                  } 
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                        
                                  usleep(500000);
                                 bzero(r1,sizeof(resp)); 
                              if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr," ERROR READING C04 sentinel MCM RESPONSE\n");  
                                     terminate_thread(server_fd); }
                               else if(n==0)
                                {
                                  fprintf(stderr,"C04 sentinel MCM closed it's Socket connection\n");
                                   terminate_thread(server_fd);
                                }     
                            else
                              {
                                    printresp(r1);
                                    write_shm(a1,r1); 
                                    bzero(r1,sizeof(resp));
                                   fprintf(stderr," Writing to ONLINE from SENTINEL THREAD SUCCESSFUL\n");
                               } 
                             c4senQ.retrieve++; 
                                             
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                        
                       }
                       else
                         { // Periodic Monitoring in the background 
                            bzero(c1,sizeof(cmd));
                           strcpy(a1->antenna_name,"C04");
                           strcpy(a1->CMD.system_name,"sentinel");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                            tstamp = tp(tstamp);
                            strcpy(a1->CMD.timestamp,tstamp);
                            c1 = &a1->CMD;
                            
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to C04 sentinel MCM MCM device\n"); }
                            else
                            {// printcmd(c1);
                            }
                             sleep(1);
                             bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                           { fprintf(stderr," ERROR READING C04 Sentinel MCM RESPONSE\n"); terminate_thread(server_fd);  }
                            else if(n==0)
                            {
                              fprintf(stderr,"C04 sentinel MCM closed it's Socket connection\n");
                                terminate_thread(server_fd);
                            }
                           else
                           {
                           
                                write_shm(a1,r1); 
                           } 
                         
                         }
                    }
     free(a1);
  free(r1);
  free(c1);
   return NULL;
}

void* C04_fiber_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1 = malloc(sizeof(ANT_CMD));
  
     cmd *c1;
     c1 = malloc(sizeof(cmd));
      char *tstamp;
     tstamp = malloc(25);
    
     resp *r1;
    r1 = malloc(sizeof(resp));
    server_fd = *(int*)parameters;
 
       c4fiberQ.store = 0; c4fiberQ.retrieve = 0;
              for(;;)
              {
                    if((int)(c4fiberQ.store)>(int)(c4fiberQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = (ANT_CMD*) c4_fiberq_retrieve((int)c4fiberQ.retrieve);
                       pthread_mutex_unlock(&lock);
                       
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                         c1= &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"fiber_optics"))
                                 {
                                         
                                    if((n= writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," ERROR Sending CMD to C04 FIBER OPTICS MCM device\n");}
                                       else
                                      { 
                                         printcmd(c1);  bzero(c1,sizeof(cmd));
                                       
                                      }
                                  }
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                        
                                    usleep(500000);
                                   bzero(r1,sizeof(resp));               
                              if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr,"ERROR READING C04 FIBER OPTICS MCM RESPONSE\n"); terminate_thread(server_fd); }
                                else if(n==0)
                                {
                                 fprintf(stderr,"C04 FIBER OPTICS MCM closed it's Socket connection\n");
                                  terminate_thread(server_fd);
                               } 
                              else
                              {
                                     printresp(r1);
                                     write_shm(a1,r1);                  
                                     fprintf(stderr," Writing to ONLINE from FIBER THREAD SUCCESSFUL\n");
                               } 
                            
                             c4fiberQ.retrieve++;                      
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                       }
                      else
                         { // Periodic Monitoring in the background 
                            bzero(c1,sizeof(cmd));
                           strcpy(a1->antenna_name,"C04");
                           strcpy(a1->CMD.system_name,"fiber_optics");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                            tstamp = tp(tstamp);
                            strcpy(a1->CMD.timestamp,tstamp);
                            c1 = &a1->CMD;
                            
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to C04 FIBER OPTICS MCM device\n"); }
                            else
                            {// printcmd(c1);
                            }
                             sleep(1);
                             bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                           { fprintf(stderr," ERROR READING C04  FIBER OPTICS MCM RESPONSE\n");shutdown(server_fd,SHUT_RDWR);
                                     close(server_fd);
                                     pthread_exit(NULL);  }
                             else if(n==0)
                            {
                              fprintf(stderr,"C01 FIBER OPTICS MCM closed it's Socket connection\n");
                               terminate_thread(server_fd);
                            } 
                           else
                           {
                             
                                write_shm(a1,r1);  
                            
                           } 
                          
                         }
                    }
     free(a1);
  free(r1);
  free(c1);
   return NULL;
}

void* C04_front_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1 = malloc(sizeof(ANT_CMD));
 
     cmd *c1;
     c1 = malloc(sizeof(cmd));
   
      char *tstamp;
     tstamp = malloc(25);
     resp *r1;
    r1 = malloc(sizeof(resp));
    server_fd = *(int*)parameters;
 
       c4frontQ.store = 0; c4frontQ.retrieve = 0;
              for(;;)
              {
                    if((int)(c4frontQ.store)>(int)(c4frontQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = ( ANT_CMD*) c4_frontq_retrieve((int)c4frontQ.retrieve);
                       pthread_mutex_unlock(&lock);
                       
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                         c1= &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"front_end"))
                                 {
                                         
                                    if((n= writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," ERROR Sending CMD to C04 FRONT END MCM device\n");}
                                       else
                                      { 
                                         printcmd(c1);  bzero(c1,sizeof(cmd));
                                         //bzero(c1,sizeof(cmd));
                                      }
                                  }
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                        
                                   usleep(500000);
                                   bzero(r1,sizeof(resp));               
                              if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr,"ERROR READING C04 FRONT END MCM RESPONSE\n"); 
                                    terminate_thread(server_fd);}
                               else if(n==0)
                              {
                                fprintf(stderr,"C01 FRONT END MCM closed it's Socket connection\n");
                                 terminate_thread(server_fd);
                              }
                              else
                              { printresp(r1); write_shm(a1,r1);  }
                           
                             c4frontQ.retrieve++;                      
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                       
                       }
                     else
                         { // Periodic Monitoring in the background 
                            bzero(c1,sizeof(cmd));
                           strcpy(a1->antenna_name,"C04");
                           strcpy(a1->CMD.system_name,"front_end");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                           tstamp = tp(tstamp);
                           strcpy(a1->CMD.timestamp,tstamp);
                           c1 = &a1->CMD;
                              
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to C04 FRONT END MCM device\n"); }
                            else
                            {// printcmd(c1);
                            }
                             sleep(1);
                             bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                           { fprintf(stderr," ERROR READING C04 FRONT END MCM RESPONSE\n"); terminate_thread(server_fd); }
                             else if(n==0)
                            {
                              fprintf(stderr,"C04 FRONT END MCM closed it's Socket connection\n");
                               terminate_thread(server_fd);
                            }
                           else
                           { write_shm(a1,r1);  }
                          
                         }
                    }
     free(a1);
  free(r1);
  free(c1);
   return NULL;
}


void* C04_backend_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1 = malloc(sizeof(ANT_CMD));
   
     cmd *c1;
     c1 = malloc(sizeof(cmd));
   
        char *tstamp;
     tstamp = malloc(25);
     resp *r1;
    r1 = malloc(sizeof(resp));
    server_fd = *(int*)parameters;
  
       c4backQ.store = 0; c4backQ.retrieve = 0;
              for(;;)
              {
                    if((int)(c4backQ.store)>(int)(c4backQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = (ANT_CMD *) c4_backq_retrieve((int)c4backQ.retrieve);
                        pthread_mutex_unlock(&lock);
                        
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                        c1= &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"back_end"))
                                 {
                                         
                                    if((n= writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," Sending CMD to C04 BACK END MCM device\n");}
                                       else
                                      { 
                                         printcmd(c1); bzero(c1,sizeof(cmd));
                                         //bzero(c1,sizeof(cmd));
                                      }
                                  }
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                        
                                   usleep(500000);
                                   bzero(r1,sizeof(resp));               
                              if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr,"ERROR READING C04 BACK END MCM RESPONSE\n");
                                    terminate_thread(server_fd);}
                                else if(n==0)
                               {
                                 fprintf(stderr,"C04 BACK END MCM closed it's Socket connection\n");
                                  terminate_thread(server_fd);
                               } 
                              else
                              { printresp(r1);write_shm(a1,r1); } 
                           
                             c4backQ.retrieve++;                      
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                        
                       }
                      else
                         { // Periodic Monitoring in the background
                            bzero(c1,sizeof(cmd));
                           strcpy(a1->antenna_name,"C04");
                           strcpy(a1->CMD.system_name,"back_end");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                            tstamp = tp(tstamp);
                            strcpy(a1->CMD.timestamp,tstamp);
                            c1 = &a1->CMD;
                            
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to C04 BACK END MCM device\n"); }
                            else
                            {// printcmd(c1);
                            }
                             sleep(1);
                             bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                           { fprintf(stderr," ERROR READING C04 Back END MCM RESPONSE\n"); terminate_thread(server_fd); }
                             else if(n==0)
                            {
                              fprintf(stderr,"C04 BACK END MCM closed it's Socket connection\n");
                               terminate_thread(server_fd);
                            } 
                           else
                           { write_shm(a1,r1); }
                       
                         }
                    }
     free(a1);
  free(r1);
  free(c1);
   return NULL;
}


void* C04_self_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1= malloc(sizeof(ANT_CMD));
  
     cmd *c1;
     c1 = malloc(sizeof(cmd));
  
     char *tstamp;
     tstamp = malloc(25);
     resp *r1;
    r1 = malloc(sizeof(resp));
    server_fd = *(int*)parameters;
  
       c4selfQ.store = 0; c4selfQ.retrieve = 0;
              for(;;)
              {
                    if((int)(c4selfQ.store)>(int)(c4selfQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = (ANT_CMD *) c4_selfq_retrieve((int)c4selfQ.retrieve);
                       pthread_mutex_unlock(&lock);
                       
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                        c1= &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"self_test"))
                                 {
                                         
                                    if((n= writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," Sending CMD to MCM device\n");}
                                       else
                                      { 
                                         printcmd(c1); bzero(c1,sizeof(cmd));
                                         //bzero(c1,sizeof(cmd));
                                      }
                                  }
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                                     
                                   bzero(r1,sizeof(resp));               
                              if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr,"ERROR READING C04  SELF SYSTEM  MCM RESPONSE\n"); 
                                     terminate_thread(server_fd); }
                              else if(n==0)
                            {
                              fprintf(stderr,"C04  SELF SYSTEM MCM closed it's Socket connection\n");
                               terminate_thread(server_fd); 
                            }
                              else
                              { write_shm(a1,r1); } 
                           
                             c4selfQ.retrieve++;                      
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                       }
                     else
                         { // Periodic Monitoring in the background 
                           bzero(c1,sizeof(cmd));
                           strcpy(a1->antenna_name,"C04");
                           strcpy(a1->CMD.system_name,"self_test");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                            tstamp = tp(tstamp);
                            strcpy(a1->CMD.timestamp,tstamp);
                            c1 = &a1->CMD;
                            
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to C04 SELF SYSTEM  MCM device\n"); }
                            else
                            {// printcmd(c1);
                            }
                             sleep(1);
                             bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                            { fprintf(stderr," ERROR READING C01 Self Test MCM RESPONSE\n"); terminate_thread(server_fd);}
                             else if(n==0)
                            {
                              fprintf(stderr,"C04 SELF SYSTEM MCM closed it's Socket connection\n");
                               terminate_thread(server_fd);
                            }
                           else
                           { write_shm(a1,r1); } 
                           
                         }
                    }
  free(a1);
  free(r1);
  free(c1);
   return NULL;
}

/*************************************** C05 Antenna syste Thread functions here ******/

void* C05_sentinel_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1 = malloc(sizeof(ANT_CMD));
   
     cmd *c1;
     c1 = malloc(sizeof(cmd));
  
     resp *r1;
    r1 = malloc(sizeof(resp));
    server_fd = *(int*)parameters;
     char *tstamp;
     tstamp = malloc(25);
  
       c5senQ.store = 0; c5senQ.retrieve = 0;
              for(;;)
              {
                   if((int)(c5senQ.store)>(int)(c5senQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = (ANT_CMD *) c5_senq_retrieve((int)c5senQ.retrieve);
                       pthread_mutex_unlock(&lock);
                        
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                        c1 = &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"sentinel"))
                                 {
                                    
                                    if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," ERROR Sending CMD C05 sentinel MCM device\n"); }
                                    else
                                   { 
                                         printcmd(c1); bzero(c1,sizeof(cmd));
                                        // bzero(c1,sizeof(cmd));   
                                         
                                    }
                                  } 
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                        
                                  usleep(500000);
                                 bzero(r1,sizeof(resp)); 
                              if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr," ERROR READING C05 sentinel MCM RESPONSE\n");  
                                     terminate_thread(server_fd); }
                               else if(n==0)
                                {
                                  fprintf(stderr,"C05 sentinel MCM closed it's Socket connection\n");
                                   terminate_thread(server_fd);
                                }     
                            else
                              {
                                    printresp(r1);
                                    write_shm(a1,r1); 
                                    bzero(r1,sizeof(resp));
                                   fprintf(stderr," Writing to ONLINE from SENTINEL THREAD SUCCESSFUL\n");
                               } 
                             c5senQ.retrieve++; 
                                             
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                        
                       }
                       else
                         { // Periodic Monitoring in the background 
                            bzero(c1,sizeof(cmd));
                           strcpy(a1->antenna_name,"C05");
                           strcpy(a1->CMD.system_name,"sentinel");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                            tstamp = tp(tstamp);
                            strcpy(a1->CMD.timestamp,tstamp);
                            c1 = &a1->CMD;
                            
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to C05 sentinel MCM MCM device\n"); }
                            else
                            {// printcmd(c1);
                            }
                             sleep(1);
                             bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                           { fprintf(stderr," ERROR READING C05 Sentinel MCM RESPONSE\n"); terminate_thread(server_fd);  }
                            else if(n==0)
                            {
                              fprintf(stderr,"C05 sentinel MCM closed it's Socket connection\n");
                                terminate_thread(server_fd);
                            }
                           else
                           {
                           
                                write_shm(a1,r1); 
                           } 
                         
                         }
                    }
     free(a1);
  free(r1);
  free(c1);
   return NULL;
}

void* C05_fiber_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1 = malloc(sizeof(ANT_CMD));
  
     cmd *c1;
     c1 = malloc(sizeof(cmd));
      char *tstamp;
     tstamp = malloc(25);
    
     resp *r1;
    r1 = malloc(sizeof(resp));
    server_fd = *(int*)parameters;
 
       c5fiberQ.store = 0; c5fiberQ.retrieve = 0;
              for(;;)
              {
                    if((int)(c5fiberQ.store)>(int)(c5fiberQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = (ANT_CMD*) c5_fiberq_retrieve((int)c5fiberQ.retrieve);
                       pthread_mutex_unlock(&lock);
                       
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                         c1= &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"fiber_optics"))
                                 {
                                         
                                    if((n= writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," ERROR Sending CMD to C05 FIBER OPTICS MCM device\n");}
                                       else
                                      { 
                                         printcmd(c1);  bzero(c1,sizeof(cmd));
                                       
                                      }
                                  }
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                        
                                    usleep(500000);
                                   bzero(r1,sizeof(resp));               
                              if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr,"ERROR READING C05 FIBER OPTICS MCM RESPONSE\n"); terminate_thread(server_fd); }
                                else if(n==0)
                                {
                                 fprintf(stderr,"C05 FIBER OPTICS MCM closed it's Socket connection\n");
                                  terminate_thread(server_fd);
                               } 
                              else
                              {
                                     printresp(r1);
                                     write_shm(a1,r1);                  
                                     fprintf(stderr," Writing to ONLINE from FIBER THREAD SUCCESSFUL\n");
                               } 
                            
                             c5fiberQ.retrieve++;                      
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                       }
                      else
                         { // Periodic Monitoring in the background 
                            bzero(c1,sizeof(cmd));
                           strcpy(a1->antenna_name,"C05");
                           strcpy(a1->CMD.system_name,"fiber_optics");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                            tstamp = tp(tstamp);
                            strcpy(a1->CMD.timestamp,tstamp);
                            c1 = &a1->CMD;
                            
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to C05 FIBER OPTICS MCM device\n"); }
                            else
                            {// printcmd(c1);
                            }
                             sleep(1);
                             bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                           { fprintf(stderr," ERROR READING C05 FIBER OPTICS MCM RESPONSE\n");shutdown(server_fd,SHUT_RDWR);
                                     close(server_fd);
                                     pthread_exit(NULL);  }
                             else if(n==0)
                            {
                              fprintf(stderr,"C05 FIBER OPTICS MCM closed it's Socket connection\n");
                               terminate_thread(server_fd);
                            } 
                           else
                           {
                             
                                write_shm(a1,r1);  
                            
                           } 
                          
                         }
                    }
     free(a1);
  free(r1);
  free(c1);
   return NULL;
}

void* C05_front_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1 = malloc(sizeof(ANT_CMD));
 
     cmd *c1;
     c1 = malloc(sizeof(cmd));
   
      char *tstamp;
     tstamp = malloc(25);
     resp *r1;
    r1 = malloc(sizeof(resp));
    server_fd = *(int*)parameters;
 
       c5frontQ.store = 0; c5frontQ.retrieve = 0;
              for(;;)
              {
                    if((int)(c5frontQ.store)>(int)(c5frontQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = ( ANT_CMD*) c5_frontq_retrieve((int)c5frontQ.retrieve);
                       pthread_mutex_unlock(&lock);
                       
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                         c1= &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"front_end"))
                                 {
                                         
                                    if((n= writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," ERROR Sending CMD to C05 FRONT END MCM device\n");}
                                       else
                                      { 
                                         printcmd(c1);  bzero(c1,sizeof(cmd));
                                         //bzero(c1,sizeof(cmd));
                                      }
                                  }
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                        
                                   usleep(500000);
                                   bzero(r1,sizeof(resp));               
                              if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr,"ERROR READING C05 FRONT END MCM RESPONSE\n"); 
                                    terminate_thread(server_fd);}
                               else if(n==0)
                              {
                                fprintf(stderr,"C05 FRONT END MCM closed it's Socket connection\n");
                                 terminate_thread(server_fd);
                              }
                              else
                              { printresp(r1); write_shm(a1,r1);  }
                           
                             c5frontQ.retrieve++;                      
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                       
                       }
                     else
                         { // Periodic Monitoring in the background 
                            bzero(c1,sizeof(cmd));
                           strcpy(a1->antenna_name,"C05");
                           strcpy(a1->CMD.system_name,"front_end");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                           tstamp = tp(tstamp);
                           strcpy(a1->CMD.timestamp,tstamp);
                           c1 = &a1->CMD;
                              
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to C05 FRONT END MCM device\n"); }
                            else
                            {// printcmd(c1);
                            }
                             sleep(1);
                             bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                           { fprintf(stderr," ERROR READING C05 FRONT END MCM RESPONSE\n"); terminate_thread(server_fd); }
                             else if(n==0)
                            {
                              fprintf(stderr,"C01 FRONT END MCM closed it's Socket connection\n");
                               terminate_thread(server_fd);
                            }
                           else
                           { write_shm(a1,r1);  }
                          
                         }
                    }
     free(a1);
  free(r1);
  free(c1);
   return NULL;
}


void* C05_backend_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1 = malloc(sizeof(ANT_CMD));
   
     cmd *c1;
     c1 = malloc(sizeof(cmd));
   
        char *tstamp;
     tstamp = malloc(25);
     resp *r1;
    r1 = malloc(sizeof(resp));
    server_fd = *(int*)parameters;
  
       c5backQ.store = 0; c5backQ.retrieve = 0;
              for(;;)
              {
                    if((int)(c5backQ.store)>(int)(c5backQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = (ANT_CMD *) c5_backq_retrieve((int)c5backQ.retrieve);
                        pthread_mutex_unlock(&lock);
                        
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                        c1= &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"back_end"))
                                 {
                                         
                                    if((n= writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," Sending CMD to C05 BACK END MCM device\n");}
                                       else
                                      { 
                                         printcmd(c1); bzero(c1,sizeof(cmd));
                                         //bzero(c1,sizeof(cmd));
                                      }
                                  }
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                        
                                   usleep(500000);
                                   bzero(r1,sizeof(resp));               
                              if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr,"ERROR READING C05 BACK END MCM RESPONSE\n");
                                    terminate_thread(server_fd);}
                                else if(n==0)
                               {
                                 fprintf(stderr,"C05 BACK END MCM closed it's Socket connection\n");
                                  terminate_thread(server_fd);
                               } 
                              else
                              { printresp(r1);write_shm(a1,r1); } 
                           
                             c5backQ.retrieve++;                      
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                        
                       }
                      else
                         { // Periodic Monitoring in the background
                            bzero(c1,sizeof(cmd));
                           strcpy(a1->antenna_name,"C05");
                           strcpy(a1->CMD.system_name,"back_end");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                            tstamp = tp(tstamp);
                            strcpy(a1->CMD.timestamp,tstamp);
                            c1 = &a1->CMD;
                            
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to C05 BACK END MCM device\n"); }
                            else
                            {// printcmd(c1);
                            }
                             sleep(1);
                             bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                           { fprintf(stderr," ERROR READING C05 Back END MCM RESPONSE\n"); terminate_thread(server_fd); }
                             else if(n==0)
                            {
                              fprintf(stderr,"C05 BACK END MCM closed it's Socket connection\n");
                               terminate_thread(server_fd);
                            } 
                           else
                           { write_shm(a1,r1); }
                       
                         }
                    }
     free(a1);
  free(r1);
  free(c1);
   return NULL;
}


void* C05_self_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1= malloc(sizeof(ANT_CMD));
  
     cmd *c1;
     c1 = malloc(sizeof(cmd));
  
     char *tstamp;
     tstamp = malloc(25);
     resp *r1;
    r1 = malloc(sizeof(resp));
    server_fd = *(int*)parameters;
  
       c5selfQ.store = 0; c5selfQ.retrieve = 0;
              for(;;)
              {
                    if((int)(c5selfQ.store)>(int)(c5selfQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = (ANT_CMD *) c5_selfq_retrieve((int)c5selfQ.retrieve);
                       pthread_mutex_unlock(&lock);
                       
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                        c1= &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"self_test"))
                                 {
                                         
                                    if((n= writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," Sending CMD to MCM device\n");}
                                       else
                                      { 
                                         printcmd(c1); bzero(c1,sizeof(cmd));
                                         //bzero(c1,sizeof(cmd));
                                      }
                                  }
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                                     
                                   bzero(r1,sizeof(resp));               
                              if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr,"ERROR READING C05  SELF SYSTEM  MCM RESPONSE\n"); 
                                     terminate_thread(server_fd); }
                              else if(n==0)
                            {
                              fprintf(stderr,"C05  SELF SYSTEM MCM closed it's Socket connection\n");
                               terminate_thread(server_fd); 
                            }
                              else
                              { write_shm(a1,r1); } 
                           
                             c5selfQ.retrieve++;                      
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                       }
                     else
                         { // Periodic Monitoring in the background 
                           bzero(c1,sizeof(cmd));
                           strcpy(a1->antenna_name,"C05");
                           strcpy(a1->CMD.system_name,"self_test");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                            tstamp = tp(tstamp);
                            strcpy(a1->CMD.timestamp,tstamp);
                            c1 = &a1->CMD;
                            
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to C05  SELF SYSTEM  MCM device\n"); }
                            else
                            {// printcmd(c1);
                            }
                             sleep(1);
                             bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                            { fprintf(stderr," ERROR READING C05 Self Test MCM RESPONSE\n"); terminate_thread(server_fd);}
                             else if(n==0)
                            {
                              fprintf(stderr,"C05 SELF SYSTEM MCM closed it's Socket connection\n");
                               terminate_thread(server_fd);
                            }
                           else
                           { write_shm(a1,r1); } 
                           
                         }
                    }
  free(a1);
  free(r1);
  free(c1);
   return NULL;
}

/*************************************** C06 Antenna syste Thread functions here ******/

void* C06_sentinel_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1 = malloc(sizeof(ANT_CMD));
   
     cmd *c1;
     c1 = malloc(sizeof(cmd));
  
     resp *r1;
    r1 = malloc(sizeof(resp));
    server_fd = *(int*)parameters;
     char *tstamp;
     tstamp = malloc(25);
  
       c6senQ.store = 0; c6senQ.retrieve = 0;
              for(;;)
              {
                   if((int)(c6senQ.store)>(int)(c6senQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = (ANT_CMD *) c6_senq_retrieve((int)c6senQ.retrieve);
                       pthread_mutex_unlock(&lock);
                        
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                        c1 = &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"sentinel"))
                                 {
                                    
                                    if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," ERROR Sending CMD C06 sentinel MCM device\n"); }
                                    else
                                   { 
                                         printcmd(c1); bzero(c1,sizeof(cmd));
                                        // bzero(c1,sizeof(cmd));   
                                         
                                    }
                                  } 
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                        
                                  usleep(500000);
                                 bzero(r1,sizeof(resp)); 
                              if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr," ERROR READING C06 sentinel MCM RESPONSE\n");  
                                     terminate_thread(server_fd); }
                               else if(n==0)
                                {
                                  fprintf(stderr,"C06 sentinel MCM closed it's Socket connection\n");
                                   terminate_thread(server_fd);
                                }     
                            else
                              {
                                    printresp(r1);
                                    write_shm(a1,r1); 
                                    bzero(r1,sizeof(resp));
                                   fprintf(stderr," Writing to ONLINE from SENTINEL THREAD SUCCESSFUL\n");
                               } 
                             c6senQ.retrieve++; 
                                             
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                        
                       }
                       else
                         { // Periodic Monitoring in the background 
                            bzero(c1,sizeof(cmd));
                           strcpy(a1->antenna_name,"C06");
                           strcpy(a1->CMD.system_name,"sentinel");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                            tstamp = tp(tstamp);
                            strcpy(a1->CMD.timestamp,tstamp);
                            c1 = &a1->CMD;
                            
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to C06 sentinel MCM MCM device\n"); }
                            else
                            {// printcmd(c1);
                            }
                             sleep(1);
                             bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                           { fprintf(stderr," ERROR READING C06 Sentinel MCM RESPONSE\n"); terminate_thread(server_fd);  }
                            else if(n==0)
                            {
                              fprintf(stderr,"C06 sentinel MCM closed it's Socket connection\n");
                                terminate_thread(server_fd);
                            }
                           else
                           {
                           
                                write_shm(a1,r1); 
                           } 
                         
                         }
                    }
     free(a1);
  free(r1);
  free(c1);
   return NULL;
}

void* C06_fiber_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1 = malloc(sizeof(ANT_CMD));
  
     cmd *c1;
     c1 = malloc(sizeof(cmd));
      char *tstamp;
     tstamp = malloc(25);
    
     resp *r1;
    r1 = malloc(sizeof(resp));
    server_fd = *(int*)parameters;
 
       c6fiberQ.store = 0; c6fiberQ.retrieve = 0;
              for(;;)
              {
                    if((int)(c6fiberQ.store)>(int)(c6fiberQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = (ANT_CMD*) c6_fiberq_retrieve((int)c6fiberQ.retrieve);
                       pthread_mutex_unlock(&lock);
                       
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                         c1= &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"fiber_optics"))
                                 {
                                         
                                    if((n= writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," ERROR Sending CMD to C06 FIBER OPTICS MCM device\n");}
                                       else
                                      { 
                                         printcmd(c1);  bzero(c1,sizeof(cmd));
                                       
                                      }
                                  }
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                        
                                    usleep(500000);
                                   bzero(r1,sizeof(resp));               
                              if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr,"ERROR READING C06 FIBER OPTICS MCM RESPONSE\n"); terminate_thread(server_fd); }
                                else if(n==0)
                                {
                                 fprintf(stderr,"C06 FIBER OPTICS MCM closed it's Socket connection\n");
                                  terminate_thread(server_fd);
                               } 
                              else
                              {
                                     printresp(r1);
                                     write_shm(a1,r1);                  
                                     fprintf(stderr," Writing to ONLINE from FIBER THREAD SUCCESSFUL\n");
                               } 
                            
                             c6fiberQ.retrieve++;                      
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                       }
                      else
                         { // Periodic Monitoring in the background 
                            bzero(c1,sizeof(cmd));
                           strcpy(a1->antenna_name,"C06");
                           strcpy(a1->CMD.system_name,"fiber_optics");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                            tstamp = tp(tstamp);
                            strcpy(a1->CMD.timestamp,tstamp);
                            c1 = &a1->CMD;
                            
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to C06 FIBER OPTICS MCM device\n"); }
                            else
                            {// printcmd(c1);
                            }
                             sleep(1);
                             bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                           { fprintf(stderr," ERROR READING C06 FIBER OPTICS MCM RESPONSE\n");
                                terminate_thread(server_fd);       }
                             else if(n==0)
                            {
                              fprintf(stderr,"C06 FIBER OPTICS MCM closed it's Socket connection\n");
                               terminate_thread(server_fd);
                            } 
                           else
                           {
                             
                                write_shm(a1,r1);  
                            
                           } 
                          
                         }
                    }
     free(a1);
  free(r1);
  free(c1);
   return NULL;
}

void* C06_front_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1 = malloc(sizeof(ANT_CMD));
 
     cmd *c1;
     c1 = malloc(sizeof(cmd));
   
      char *tstamp;
     tstamp = malloc(25);
     resp *r1;
    r1 = malloc(sizeof(resp));
    server_fd = *(int*)parameters;
 
       c6frontQ.store = 0; c6frontQ.retrieve = 0;
              for(;;)
              {
                    if((int)(c6frontQ.store)>(int)(c6frontQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = ( ANT_CMD*) c6_frontq_retrieve((int)c6frontQ.retrieve);
                       pthread_mutex_unlock(&lock);
                       
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                         c1= &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"front_end"))
                                 {
                                         
                                    if((n= writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," ERROR Sending CMD to C06 FRONT END MCM device\n");}
                                       else
                                      { 
                                         printcmd(c1);  bzero(c1,sizeof(cmd));
                                         //bzero(c1,sizeof(cmd));
                                      }
                                  }
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                        
                                   usleep(500000);
                                   bzero(r1,sizeof(resp));               
                              if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr,"ERROR READING C06 FRONT END MCM RESPONSE\n"); 
                                    terminate_thread(server_fd);}
                               else if(n==0)
                              {
                                fprintf(stderr,"C06 FRONT END MCM closed it's Socket connection\n");
                                 terminate_thread(server_fd);
                              }
                              else
                              { printresp(r1); write_shm(a1,r1);  }
                           
                             c6frontQ.retrieve++;                      
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                       
                       }
                     else
                         { // Periodic Monitoring in the background 
                            bzero(c1,sizeof(cmd));
                           strcpy(a1->antenna_name,"C06");
                           strcpy(a1->CMD.system_name,"front_end");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                           tstamp = tp(tstamp);
                           strcpy(a1->CMD.timestamp,tstamp);
                           c1 = &a1->CMD;
                              
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to C06 FRONT END MCM device\n"); }
                            else
                            {// printcmd(c1);
                            }
                             sleep(1);
                             bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                           { fprintf(stderr," ERROR READING C06 FRONT END MCM RESPONSE\n"); terminate_thread(server_fd); }
                             else if(n==0)
                            {
                              fprintf(stderr,"C06 FRONT END MCM closed it's Socket connection\n");
                               terminate_thread(server_fd);
                            }
                           else
                           { write_shm(a1,r1);  }
                          
                         }
                    }
     free(a1);
  free(r1);
  free(c1);
   return NULL;
}


void* C06_backend_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1 = malloc(sizeof(ANT_CMD));
   
     cmd *c1;
     c1 = malloc(sizeof(cmd));
   
        char *tstamp;
     tstamp = malloc(25);
     resp *r1;
    r1 = malloc(sizeof(resp));
    server_fd = *(int*)parameters;
  
       c6backQ.store = 0; c6backQ.retrieve = 0;
              for(;;)
              {
                    if((int)(c6backQ.store)>(int)(c6backQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = (ANT_CMD *) c6_backq_retrieve((int)c6backQ.retrieve);
                        pthread_mutex_unlock(&lock);
                        
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                        c1= &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"back_end"))
                                 {
                                         
                                    if((n= writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," Sending CMD to C06 BACK END MCM device\n");}
                                       else
                                      { 
                                         printcmd(c1); bzero(c1,sizeof(cmd));
                                         //bzero(c1,sizeof(cmd));
                                      }
                                  }
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                        
                                   usleep(500000);
                                   bzero(r1,sizeof(resp));               
                              if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr,"ERROR READING C06 BACK END MCM RESPONSE\n");
                                    terminate_thread(server_fd);}
                                else if(n==0)
                               {
                                 fprintf(stderr,"C06 BACK END MCM closed it's Socket connection\n");
                                  terminate_thread(server_fd);
                               } 
                              else
                              { printresp(r1);write_shm(a1,r1); } 
                           
                             c6backQ.retrieve++;                      
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                        
                       }
                      else
                         { // Periodic Monitoring in the background
                            bzero(c1,sizeof(cmd));
                           strcpy(a1->antenna_name,"C06");
                           strcpy(a1->CMD.system_name,"back_end");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                            tstamp = tp(tstamp);
                            strcpy(a1->CMD.timestamp,tstamp);
                            c1 = &a1->CMD;
                            
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to C06 BACK END MCM device\n"); }
                            else
                            {// printcmd(c1);
                            }
                             sleep(1);
                             bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                           { fprintf(stderr," ERROR READING C06 Back END MCM RESPONSE\n"); terminate_thread(server_fd); }
                             else if(n==0)
                            {
                              fprintf(stderr,"C05 BACK END MCM closed it's Socket connection\n");
                               terminate_thread(server_fd);
                            } 
                           else
                           { write_shm(a1,r1); }
                       
                         }
                    }
     free(a1);
  free(r1);
  free(c1);
   return NULL;
}


void* C06_self_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1= malloc(sizeof(ANT_CMD));
  
     cmd *c1;
     c1 = malloc(sizeof(cmd));
  
     char *tstamp;
     tstamp = malloc(25);
     resp *r1;
    r1 = malloc(sizeof(resp));
    server_fd = *(int*)parameters;
  
       c6selfQ.store = 0; c6selfQ.retrieve = 0;
              for(;;)
              {
                    if((int)(c6selfQ.store)>(int)(c6selfQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = (ANT_CMD *) c6_selfq_retrieve((int)c6selfQ.retrieve);
                       pthread_mutex_unlock(&lock);
                       
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                        c1= &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"self_test"))
                                 {
                                         
                                    if((n= writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," Sending CMD to MCM device\n");}
                                       else
                                      { 
                                         printcmd(c1); bzero(c1,sizeof(cmd));
                                         //bzero(c1,sizeof(cmd));
                                      }
                                  }
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                                     
                                   bzero(r1,sizeof(resp));               
                              if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr,"ERROR READING C06  SELF SYSTEM  MCM RESPONSE\n"); 
                                     terminate_thread(server_fd); }
                              else if(n==0)
                            {
                              fprintf(stderr,"C06  SELF SYSTEM MCM closed it's Socket connection\n");
                               terminate_thread(server_fd); 
                            }
                              else
                              { write_shm(a1,r1); } 
                           
                             c6selfQ.retrieve++;                      
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                       }
                     else
                         { // Periodic Monitoring in the background 
                           bzero(c1,sizeof(cmd));
                           strcpy(a1->antenna_name,"C06");
                           strcpy(a1->CMD.system_name,"self_test");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                            tstamp = tp(tstamp);
                            strcpy(a1->CMD.timestamp,tstamp);
                            c1 = &a1->CMD;
                            
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to C06  SELF SYSTEM  MCM device\n"); }
                            else
                            {// printcmd(c1);
                            }
                             sleep(1);
                             bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                            { fprintf(stderr," ERROR READING C06 Self Test MCM RESPONSE\n"); terminate_thread(server_fd);}
                             else if(n==0)
                            {
                              fprintf(stderr,"C06 SELF SYSTEM MCM closed it's Socket connection\n");
                               terminate_thread(server_fd);
                            }
                           else
                           { write_shm(a1,r1); } 
                           
                         }
                    }
  free(a1);
  free(r1);
  free(c1);
   return NULL;
}


/*************************************** C08 Antenna syste Thread functions here ******/

void* C08_sentinel_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1 = malloc(sizeof(ANT_CMD));
   
     cmd *c1;
     c1 = malloc(sizeof(cmd));
  
     resp *r1;
    r1 = malloc(sizeof(resp));
    server_fd = *(int*)parameters;
     char *tstamp;
     tstamp = malloc(25);
  
       c8senQ.store = 0; c8senQ.retrieve = 0;
              for(;;)
              {
                   if((int)(c8senQ.store)>(int)(c8senQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = (ANT_CMD *) c8_senq_retrieve((int)c8senQ.retrieve);
                       pthread_mutex_unlock(&lock);
                        
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                        c1 = &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"sentinel"))
                                 {
                                    
                                    if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," ERROR Sending CMD C08 sentinel MCM device\n"); }
                                    else
                                   { 
                                         printcmd(c1); bzero(c1,sizeof(cmd));
                                        // bzero(c1,sizeof(cmd));   
                                         
                                    }
                                  } 
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                        
                                  usleep(500000);
                                 bzero(r1,sizeof(resp)); 
                              if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr," ERROR READING C08 sentinel MCM RESPONSE\n");  
                                     terminate_thread(server_fd); }
                               else if(n==0)
                                {
                                  fprintf(stderr,"C08 sentinel MCM closed it's Socket connection\n");
                                   terminate_thread(server_fd);
                                }     
                            else
                              {
                                    printresp(r1);
                                    write_shm(a1,r1); 
                                    bzero(r1,sizeof(resp));
                                   fprintf(stderr," Writing to ONLINE from SENTINEL THREAD SUCCESSFUL\n");
                               } 
                             c8senQ.retrieve++; 
                                             
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                        
                       }
                       else
                         { // Periodic Monitoring in the background 
                            bzero(c1,sizeof(cmd));
                           strcpy(a1->antenna_name,"C08");
                           strcpy(a1->CMD.system_name,"sentinel");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                            tstamp = tp(tstamp);
                            strcpy(a1->CMD.timestamp,tstamp);
                            c1 = &a1->CMD;
                            
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to C08 sentinel MCM MCM device\n"); }
                            else
                            {// printcmd(c1);
                            }
                             sleep(1);
                             bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                           { fprintf(stderr," ERROR READING C08 Sentinel MCM RESPONSE\n"); terminate_thread(server_fd);  }
                            else if(n==0)
                            {
                              fprintf(stderr,"C08 sentinel MCM closed it's Socket connection\n");
                                terminate_thread(server_fd);
                            }
                           else
                           {
                           
                                write_shm(a1,r1); 
                           } 
                         
                         }
                    }
     free(a1);
  free(r1);
  free(c1);
   return NULL;
}

void* C08_fiber_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1 = malloc(sizeof(ANT_CMD));
  
     cmd *c1;
     c1 = malloc(sizeof(cmd));
      char *tstamp;
     tstamp = malloc(25);
    
     resp *r1;
    r1 = malloc(sizeof(resp));
    server_fd = *(int*)parameters;
 
       c8fiberQ.store = 0; c8fiberQ.retrieve = 0;
              for(;;)
              {
                    if((int)(c8fiberQ.store)>(int)(c8fiberQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = (ANT_CMD*) c8_fiberq_retrieve((int)c8fiberQ.retrieve);
                       pthread_mutex_unlock(&lock);
                       
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                         c1= &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"fiber_optics"))
                                 {
                                         
                                    if((n= writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," ERROR Sending CMD to C08 FIBER OPTICS MCM device\n");}
                                       else
                                      { 
                                         printcmd(c1);  bzero(c1,sizeof(cmd));
                                       
                                      }
                                  }
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                        
                                    usleep(500000);
                                   bzero(r1,sizeof(resp));               
                              if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr,"ERROR READING C08 FIBER OPTICS MCM RESPONSE\n"); terminate_thread(server_fd); }
                                else if(n==0)
                                {
                                 fprintf(stderr,"C08 FIBER OPTICS MCM closed it's Socket connection\n");
                                  terminate_thread(server_fd);
                               } 
                              else
                              {
                                     printresp(r1);
                                     write_shm(a1,r1);                  
                                     fprintf(stderr," Writing to ONLINE from FIBER THREAD SUCCESSFUL\n");
                               } 
                            
                             c8fiberQ.retrieve++;                      
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                       }
                      else
                         { // Periodic Monitoring in the background 
                            bzero(c1,sizeof(cmd));
                           strcpy(a1->antenna_name,"C08");
                           strcpy(a1->CMD.system_name,"fiber_optics");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                            tstamp = tp(tstamp);
                            strcpy(a1->CMD.timestamp,tstamp);
                            c1 = &a1->CMD;
                            
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to C08 FIBER OPTICS MCM device\n"); }
                            else
                            {// printcmd(c1);
                            }
                             sleep(1);
                             bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                           { fprintf(stderr," ERROR READING C08 FIBER OPTICS MCM RESPONSE\n");shutdown(server_fd,SHUT_RDWR);
                                     close(server_fd);
                                     pthread_exit(NULL);  }
                             else if(n==0)
                            {
                              fprintf(stderr,"C08 FIBER OPTICS MCM closed it's Socket connection\n");
                               terminate_thread(server_fd);
                            } 
                           else
                           {
                               write_shm(a1,r1);  
                            
                           } 
                          
                         }
                    }
     free(a1);
  free(r1);
  free(c1);
   return NULL;
}

void* C08_front_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1 = malloc(sizeof(ANT_CMD));
 
     cmd *c1;
     c1 = malloc(sizeof(cmd));
   
      char *tstamp;
     tstamp = malloc(25);
     resp *r1;
    r1 = malloc(sizeof(resp));
    server_fd = *(int*)parameters;
 
       c8frontQ.store = 0; c8frontQ.retrieve = 0;
              for(;;)
              {
                    if((int)(c8frontQ.store)>(int)(c8frontQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = ( ANT_CMD*) c8_frontq_retrieve((int)c8frontQ.retrieve);
                       pthread_mutex_unlock(&lock);
                       
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                         c1= &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"front_end"))
                                 {
                                         
                                    if((n= writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," ERROR Sending CMD to C08 FRONT END MCM device\n");}
                                       else
                                      { 
                                         printcmd(c1);  bzero(c1,sizeof(cmd));
                                         //bzero(c1,sizeof(cmd));
                                      }
                                  }
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                        
                                   usleep(500000);
                                   bzero(r1,sizeof(resp));               
                              if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr,"ERROR READING C08 FRONT END MCM RESPONSE\n"); 
                                    terminate_thread(server_fd);}
                               else if(n==0)
                              {
                                fprintf(stderr,"C08 FRONT END MCM closed it's Socket connection\n");
                                 terminate_thread(server_fd);
                              }
                              else
                              { printresp(r1); write_shm(a1,r1);  }
                           
                             c8frontQ.retrieve++;                      
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                       
                       }
                     else
                         { // Periodic Monitoring in the background 
                            bzero(c1,sizeof(cmd));
                           strcpy(a1->antenna_name,"C08");
                           strcpy(a1->CMD.system_name,"front_end");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                           tstamp = tp(tstamp);
                           strcpy(a1->CMD.timestamp,tstamp);
                           c1 = &a1->CMD;
                              
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to C08 FRONT END MCM device\n"); }
                            else
                            {// printcmd(c1);
                            }
                             sleep(1);
                             bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                           { fprintf(stderr," ERROR READING C08 FRONT END MCM RESPONSE\n"); terminate_thread(server_fd); }
                             else if(n==0)
                            {
                              fprintf(stderr,"C08 FRONT END MCM closed it's Socket connection\n");
                               terminate_thread(server_fd);
                            }
                           else
                           { write_shm(a1,r1);  }
                          
                         }
                    }
     free(a1);
  free(r1);
  free(c1);
   return NULL;
}


void* C08_backend_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1 = malloc(sizeof(ANT_CMD));
   
     cmd *c1;
     c1 = malloc(sizeof(cmd));
   
        char *tstamp;
     tstamp = malloc(25);
     resp *r1;
    r1 = malloc(sizeof(resp));
    server_fd = *(int*)parameters;
  
       c8backQ.store = 0; c8backQ.retrieve = 0;
              for(;;)
              {
                    if((int)(c8backQ.store)>(int)(c8backQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = (ANT_CMD *) c8_backq_retrieve((int)c8backQ.retrieve);
                        pthread_mutex_unlock(&lock);
                        
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                        c1= &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"back_end"))
                                 {
                                         
                                    if((n= writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," Sending CMD to C08 BACK END MCM device\n");}
                                       else
                                      { 
                                         printcmd(c1); bzero(c1,sizeof(cmd));
                                         //bzero(c1,sizeof(cmd));
                                      }
                                  }
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                        
                                   usleep(500000);
                                   bzero(r1,sizeof(resp));               
                              if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr,"ERROR READING C08 BACK END MCM RESPONSE\n");
                                    terminate_thread(server_fd);}
                                else if(n==0)
                               {
                                 fprintf(stderr,"C08 BACK END MCM closed it's Socket connection\n");
                                  terminate_thread(server_fd);
                               } 
                              else
                              { printresp(r1);write_shm(a1,r1); } 
                           
                             c8backQ.retrieve++;                      
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                        
                       }
                      else
                         { // Periodic Monitoring in the background
                            bzero(c1,sizeof(cmd));
                           strcpy(a1->antenna_name,"C08");
                           strcpy(a1->CMD.system_name,"back_end");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                            tstamp = tp(tstamp);
                            strcpy(a1->CMD.timestamp,tstamp);
                            c1 = &a1->CMD;
                            
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to C08 BACK END MCM device\n"); }
                            else
                            {// printcmd(c1);
                            }
                             sleep(1);
                             bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                           { fprintf(stderr," ERROR READING C08 Back END MCM RESPONSE\n"); terminate_thread(server_fd); }
                             else if(n==0)
                            {
                              fprintf(stderr,"C08 BACK END MCM closed it's Socket connection\n");
                               terminate_thread(server_fd);
                            } 
                           else
                           { write_shm(a1,r1); }
                       
                         }
                    }
     free(a1);
  free(r1);
  free(c1);
   return NULL;
}


void* C08_self_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1= malloc(sizeof(ANT_CMD));
  
     cmd *c1;
     c1 = malloc(sizeof(cmd));
  
     char *tstamp;
     tstamp = malloc(25);
     resp *r1;
    r1 = malloc(sizeof(resp));
    server_fd = *(int*)parameters;
  
       c8selfQ.store = 0; c8selfQ.retrieve = 0;
              for(;;)
              {
                    if((int)(c8selfQ.store)>(int)(c8selfQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = (ANT_CMD *) c8_selfq_retrieve((int)c8selfQ.retrieve);
                       pthread_mutex_unlock(&lock);
                       
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                        c1= &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"self_test"))
                                 {
                                         
                                    if((n= writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," Sending CMD to MCM device\n");}
                                       else
                                      { 
                                         printcmd(c1); bzero(c1,sizeof(cmd));
                                         //bzero(c1,sizeof(cmd));
                                      }
                                  }
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                                     
                                   bzero(r1,sizeof(resp));               
                              if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr,"ERROR READING C08  SELF SYSTEM  MCM RESPONSE\n"); 
                                     terminate_thread(server_fd); }
                              else if(n==0)
                            {
                              fprintf(stderr,"C08  SELF SYSTEM MCM closed it's Socket connection\n");
                               terminate_thread(server_fd); 
                            }
                              else
                              { write_shm(a1,r1); } 
                           
                             c8selfQ.retrieve++;                      
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                       }
                     else
                         { // Periodic Monitoring in the background 
                           bzero(c1,sizeof(cmd));
                           strcpy(a1->antenna_name,"C08");
                           strcpy(a1->CMD.system_name,"self_test");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                            tstamp = tp(tstamp);
                            strcpy(a1->CMD.timestamp,tstamp);
                            c1 = &a1->CMD;
                            
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to C08 SELF SYSTEM  MCM device\n"); }
                            else
                            {// printcmd(c1);
                            }
                             sleep(1);
                             bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                            { fprintf(stderr," ERROR READING C08 Self Test MCM RESPONSE\n"); terminate_thread(server_fd);}
                             else if(n==0)
                            {
                              fprintf(stderr,"C08 SELF SYSTEM MCM closed it's Socket connection\n");
                               terminate_thread(server_fd);
                            }
                           else
                           { write_shm(a1,r1); } 
                           
                         }
                    }
  free(a1);
  free(r1);
  free(c1);
   return NULL;
}

/*************************************** C09 Antenna syste Thread functions here ******/

void* C09_sentinel_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1 = malloc(sizeof(ANT_CMD));
   
     cmd *c1;
     c1 = malloc(sizeof(cmd));
  
     resp *r1;
    r1 = malloc(sizeof(resp));
    server_fd = *(int*)parameters;
     char *tstamp;
     tstamp = malloc(25);
  
       c9senQ.store = 0; c9senQ.retrieve = 0;
              for(;;)
              {
                   if((int)(c9senQ.store)>(int)(c9senQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = (ANT_CMD *) c9_senq_retrieve((int)c9senQ.retrieve);
                       pthread_mutex_unlock(&lock);
                        
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                        c1 = &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"sentinel"))
                                 {
                                    
                                    if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," ERROR Sending CMD C09 sentinel MCM device\n"); }
                                    else
                                   { 
                                         printcmd(c1); bzero(c1,sizeof(cmd));
                                        // bzero(c1,sizeof(cmd));   
                                         
                                    }
                                  } 
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                        
                                  usleep(500000);
                                 bzero(r1,sizeof(resp)); 
                              if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr," ERROR READING C09 sentinel MCM RESPONSE\n");  
                                     terminate_thread(server_fd); }
                               else if(n==0)
                                {
                                  fprintf(stderr,"C09 sentinel MCM closed it's Socket connection\n");
                                   terminate_thread(server_fd);
                                }     
                            else
                              {
                                    printresp(r1);
                                    write_shm(a1,r1); 
                                    bzero(r1,sizeof(resp));
                                   fprintf(stderr," Writing to ONLINE from SENTINEL THREAD SUCCESSFUL\n");
                               } 
                             c9senQ.retrieve++; 
                                             
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                        
                       }
                       else
                         { // Periodic Monitoring in the background 
                            bzero(c1,sizeof(cmd));
                           strcpy(a1->antenna_name,"C09");
                           strcpy(a1->CMD.system_name,"sentinel");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                            tstamp = tp(tstamp);
                            strcpy(a1->CMD.timestamp,tstamp);
                            c1 = &a1->CMD;
                            
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to C09 sentinel MCM MCM device\n"); }
                            else
                            {// printcmd(c1);
                            }
                             sleep(1);
                             bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                           { fprintf(stderr," ERROR READING C09 Sentinel MCM RESPONSE\n"); terminate_thread(server_fd);  }
                            else if(n==0)
                            {
                              fprintf(stderr,"C09 sentinel MCM closed it's Socket connection\n");
                                terminate_thread(server_fd);
                            }
                           else
                           {
                           
                                write_shm(a1,r1); 
                           } 
                         
                         }
                    }
     free(a1);
  free(r1);
  free(c1);
   return NULL;
}

void* C09_fiber_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1 = malloc(sizeof(ANT_CMD));
  
     cmd *c1;
     c1 = malloc(sizeof(cmd));
      char *tstamp;
     tstamp = malloc(25);
    
     resp *r1;
    r1 = malloc(sizeof(resp));
    server_fd = *(int*)parameters;
 
       c9fiberQ.store = 0; c9fiberQ.retrieve = 0;
              for(;;)
              {
                    if((int)(c9fiberQ.store)>(int)(c9fiberQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = (ANT_CMD*) c9_fiberq_retrieve((int)c9fiberQ.retrieve);
                       pthread_mutex_unlock(&lock);
                       
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                         c1= &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"fiber_optics"))
                                 {
                                         
                                    if((n= writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," ERROR Sending CMD to C09 FIBER OPTICS MCM device\n");}
                                       else
                                      { 
                                         printcmd(c1);  bzero(c1,sizeof(cmd));
                                       
                                      }
                                  }
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                        
                                    usleep(500000);
                                   bzero(r1,sizeof(resp));               
                              if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr,"ERROR READING C09 FIBER OPTICS MCM RESPONSE\n"); terminate_thread(server_fd); }
                                else if(n==0)
                                {
                                 fprintf(stderr,"C09 FIBER OPTICS MCM closed it's Socket connection\n");
                                  terminate_thread(server_fd);
                               } 
                              else
                              {
                                     printresp(r1);
                                     write_shm(a1,r1);                  
                                     fprintf(stderr," Writing to ONLINE from FIBER THREAD SUCCESSFUL\n");
                               } 
                            
                             c9fiberQ.retrieve++;                      
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                       }
                      else
                         { // Periodic Monitoring in the background 
                            bzero(c1,sizeof(cmd));
                           strcpy(a1->antenna_name,"C09");
                           strcpy(a1->CMD.system_name,"fiber_optics");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                            tstamp = tp(tstamp);
                            strcpy(a1->CMD.timestamp,tstamp);
                            c1 = &a1->CMD;
                            
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to C09 FIBER OPTICS MCM device\n"); }
                            else
                            {// printcmd(c1);
                            }
                             sleep(1);
                             bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                           { fprintf(stderr," ERROR READING C09 FIBER OPTICS MCM RESPONSE\n");shutdown(server_fd,SHUT_RDWR);
                                     close(server_fd);
                                     pthread_exit(NULL);  }
                             else if(n==0)
                            {
                              fprintf(stderr,"C09 FIBER OPTICS MCM closed it's Socket connection\n");
                               terminate_thread(server_fd);
                            } 
                           else
                           {
                             
                                write_shm(a1,r1);  
                            
                           } 
                          
                         }
                    }
     free(a1);
  free(r1);
  free(c1);
   return NULL;
}

void* C09_front_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1 = malloc(sizeof(ANT_CMD));
 
     cmd *c1;
     c1 = malloc(sizeof(cmd));
   
      char *tstamp;
     tstamp = malloc(25);
     resp *r1;
    r1 = malloc(sizeof(resp));
    server_fd = *(int*)parameters;
 
       c9frontQ.store = 0; c9frontQ.retrieve = 0;
              for(;;)
              {
                    if((int)(c9frontQ.store)>(int)(c9frontQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = ( ANT_CMD*) c9_frontq_retrieve((int)c9frontQ.retrieve);
                       pthread_mutex_unlock(&lock);
                       
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                         c1= &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"front_end"))
                                 {
                                         
                                    if((n= writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," ERROR Sending CMD to C09 FRONT END MCM device\n");}
                                       else
                                      { 
                                         printcmd(c1);  bzero(c1,sizeof(cmd));
                                         //bzero(c1,sizeof(cmd));
                                      }
                                  }
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                        
                                   usleep(500000);
                                   bzero(r1,sizeof(resp));               
                              if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr,"ERROR READING C07 FRONT END MCM RESPONSE\n"); 
                                    terminate_thread(server_fd);}
                               else if(n==0)
                              {
                                fprintf(stderr,"C09 FRONT END MCM closed it's Socket connection\n");
                                 terminate_thread(server_fd);
                              }
                              else
                              { printresp(r1); write_shm(a1,r1);  }
                           
                             c9frontQ.retrieve++;                      
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                       
                       }
                     else
                         { // Periodic Monitoring in the background 
                            bzero(c1,sizeof(cmd));
                           strcpy(a1->antenna_name,"C09");
                           strcpy(a1->CMD.system_name,"front_end");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                           tstamp = tp(tstamp);
                           strcpy(a1->CMD.timestamp,tstamp);
                           c1 = &a1->CMD;
                              
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to C09 FRONT END MCM device\n"); }
                            else
                            {// printcmd(c1);
                            }
                             sleep(1);
                             bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                           { fprintf(stderr," ERROR READING C09 FRONT END MCM RESPONSE\n"); terminate_thread(server_fd); }
                             else if(n==0)
                            {
                              fprintf(stderr,"C09 FRONT END MCM closed it's Socket connection\n");
                               terminate_thread(server_fd);
                            }
                           else
                           { write_shm(a1,r1);  }
                          
                         }
                    }
     free(a1);
  free(r1);
  free(c1);
   return NULL;
}


void* C09_backend_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1 = malloc(sizeof(ANT_CMD));
   
     cmd *c1;
     c1 = malloc(sizeof(cmd));
   
        char *tstamp;
     tstamp = malloc(25);
     resp *r1;
    r1 = malloc(sizeof(resp));
    server_fd = *(int*)parameters;
  
       c9backQ.store = 0; c9backQ.retrieve = 0;
              for(;;)
              {
                    if((int)(c9backQ.store)>(int)(c9backQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = (ANT_CMD *) c9_backq_retrieve((int)c9backQ.retrieve);
                        pthread_mutex_unlock(&lock);
                        
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                        c1= &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"back_end"))
                                 {
                                         
                                    if((n= writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," Sending CMD to C09 BACK END MCM device\n");}
                                       else
                                      { 
                                         printcmd(c1); bzero(c1,sizeof(cmd));
                                         //bzero(c1,sizeof(cmd));
                                      }
                                  }
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                        
                                   usleep(500000);
                                   bzero(r1,sizeof(resp));               
                              if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr,"ERROR READING C09 BACK END MCM RESPONSE\n");
                                    terminate_thread(server_fd);}
                                else if(n==0)
                               {
                                 fprintf(stderr,"C09 BACK END MCM closed it's Socket connection\n");
                                  terminate_thread(server_fd);
                               } 
                              else
                              { printresp(r1);write_shm(a1,r1); } 
                           
                             c9backQ.retrieve++;                      
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                        
                       }
                      else
                         { // Periodic Monitoring in the background
                            bzero(c1,sizeof(cmd));
                           strcpy(a1->antenna_name,"C09");
                           strcpy(a1->CMD.system_name,"back_end");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                            tstamp = tp(tstamp);
                            strcpy(a1->CMD.timestamp,tstamp);
                            c1 = &a1->CMD;
                            
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to C09 BACK END MCM device\n"); }
                            else
                            {// printcmd(c1);
                            }
                             sleep(1);
                             bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                           { fprintf(stderr," ERROR READING C09 Back END MCM RESPONSE\n"); terminate_thread(server_fd); }
                             else if(n==0)
                            {
                              fprintf(stderr,"C07 BACK END MCM closed it's Socket connection\n");
                               terminate_thread(server_fd);
                            } 
                           else
                           { write_shm(a1,r1); }
                       
                         }
                    }
     free(a1);
  free(r1);
  free(c1);
   return NULL;
}


void* C09_self_thread( void* parameters)
{    
     int server_fd;
     ssize_t n;
     ANT_CMD *a1;
     a1= malloc(sizeof(ANT_CMD));
  
     cmd *c1;
     c1 = malloc(sizeof(cmd));
  
     char *tstamp;
     tstamp = malloc(25);
     resp *r1;
    r1 = malloc(sizeof(resp));
    server_fd = *(int*)parameters;
  
       c9selfQ.store = 0; c9selfQ.retrieve = 0;
              for(;;)
              {
                    if((int)(c9selfQ.store)>(int)(c9selfQ.retrieve))
                     {
                       pthread_mutex_lock(&lock);
                       a1 = (ANT_CMD *) c9_selfq_retrieve((int)c9selfQ.retrieve);
                       pthread_mutex_unlock(&lock);
                       
                        tstamp = tp(tstamp);
                        strcpy(a1->CMD.timestamp,tstamp);
                        c1= &a1->CMD;
                         if((cmd *)c1 != (cmd *)NULL)
                           {  
                                if(!strcasecmp(c1->system_name,"self_test"))
                                 {
                                         
                                    if((n= writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                                     {  fprintf(stderr," Sending CMD to MCM device\n");}
                                       else
                                      { 
                                         printcmd(c1); bzero(c1,sizeof(cmd));
                                         //bzero(c1,sizeof(cmd));
                                      }
                                  }
                                  else
                                  { fprintf(stderr,"SYSTEM NAME doesn't MATCHES\n");}
                                     
                                   bzero(r1,sizeof(resp));               
                              if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                                  { fprintf(stderr,"ERROR READING C09 SELF SYSTEM  MCM RESPONSE\n"); 
                                     terminate_thread(server_fd); }
                              else if(n==0)
                            {
                              fprintf(stderr,"C09 SELF SYSTEM MCM closed it's Socket connection\n");
                               terminate_thread(server_fd); 
                            }
                              else
                              { write_shm(a1,r1); } 
                           
                             c9selfQ.retrieve++;                      
                         }
                         else
                         { fprintf(stderr," COMMAND is NULL in the QUEUE\n"); }
                       }
                     else
                         { // Periodic Monitoring in the background 
                           bzero(c1,sizeof(cmd));
                           strcpy(a1->antenna_name,"C09");
                           strcpy(a1->CMD.system_name,"self_test");
                           a1->CMD.seq= 10;
                           strcpy(a1->CMD.op_name,"mon");
                           a1->CMD.number_param=0;
                            tstamp = tp(tstamp);
                            strcpy(a1->CMD.timestamp,tstamp);
                            c1 = &a1->CMD;
                            
                            if((n=writen(server_fd,(unsigned char *)c1,sizeof(cmd)))!=sizeof(cmd))
                            {  fprintf(stderr," ERROR Sending CMD to C09 SELF SYSTEM  MCM device\n"); }
                            else
                            {// printcmd(c1);
                            }
                             sleep(1);
                             bzero(r1,sizeof(resp));
                            if((n=readn(server_fd,r1,sizeof(resp)))!=sizeof(resp))
                            { fprintf(stderr," ERROR READING C09 Self Test MCM RESPONSE\n"); terminate_thread(server_fd);}
                             else if(n==0)
                            {
                              fprintf(stderr,"C07 SELF SYSTEM MCM closed it's Socket connection\n");
                               terminate_thread(server_fd);
                            }
                           else
                           { write_shm(a1,r1); } 
                           
                         }
                    }
  free(a1);
  free(r1);
  free(c1);
   return NULL;
}



