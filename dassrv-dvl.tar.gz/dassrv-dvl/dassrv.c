/*   dassrv.c : 97july07  :  runs on the same machine as ONLINE   */
# include <stdio.h>
# include <string.h>
# include <errno.h>
# include <sys/types.h>
# include <sys/ipc.h>
# include <sys/msg.h>
# include <ctype.h>
# include <unistd.h>
# include <malloc.h>
# include "newcorr.h"
# include "usock.h"
#define _INCLUDE_SERVICE_NAMES_
# include "protocol.h"
#undef _INCLUDE_SERVICE_NAMES_

enum { Len = 512 };
enum {SubMax=8};
enum {MaxCorrelators=4};
static char *CorrelatorName[MaxCorrelators]={"CorrB","CorrA","CorrC","CorrD"}; /* acqB, acqA, ctl, dum */
static int   PortNum[4]={6004,6001,6005,6007}; /* acqB, acqA, ctl, dum Port Numbers */
static unsigned int CorrMask[MaxCorrelators]={1<<1,1<<0,1<<2,1<<3}; /* acqB, acqA, ctl, dum (Online Convention) */
static unsigned int CorrBandMask[MaxCorrelators];
typedef struct { unsigned int corr_id; 
                 ProjectType  proj[MaxCorrelators];} ProjectTable;

typedef struct { long type; char buf[Len]; } MsgType;


int          LocalByteOrder ;
int          ComSock[MaxCorrelators],SendReply=0 ;
int          MsgId=-1, MsgSrc=1, CmdId, CmdType, Cmd;
char         CmdTypeStr[32], CmdStr[32];
int          InpMsgKey=CmdMsgQ; /* InpMsgQ */
MsgType      Msg;
ProjectTable ProjTab[SubMax];
unsigned int CorrId,OpenCorr;
static int   SaNum;
static int   DryRun=0;

#define CheckPrivilige(cn,cs)  { if(cs !=0){ fprintf(stderr,"Ignoring PriviligedCmd %s from NonPriviliged SubArray %d\n",DasCmdName[cn],cs); return -1; } }

int map_mask(unsigned int o_antmask, unsigned int *d_antmask) /* ONLINE -> DAS */
{ int i,j,k;
  char *AntName[MAX_ANTS]={"C00","C01","C02","C03","C04","C05","C06","C08",
			   "C09","C10","C11","C12","C13","C14","E02","E03",
			   "E04","E05","E06","S01","S02","S03","S04","S06",
			   "W01","W02","W03","W04","W05","W06"};
  char *AntName_O[MAX_ANTS+1]={"CEB","C03","C12","C04","C09","C02","C01",
			       "C00","W01","C11","C14","C13","C10","W02",
			       "W03","W04","W05","E02","E03","C05","C06",
			       "E04","E05","E06","C08","W06","S01","S02", 
			       "S03","S04","S06"};
  *d_antmask=0;
  for(i=0;i<MAX_ANTS+1;i++)
  { if(1<<i & o_antmask)
    { for(k=-1,j=0;j<MAX_ANTS;j++)
      if(!strcmp(AntName_O[i],AntName[j])){ k=j; break;}
      if(k <0){fprintf(stderr,"Illegal Antenna %s\n",AntName_O[i]); return -1;}
      *d_antmask |= 1<<k;
    }
  }
  return 0;
}

int min_match(const char *p1, const char *p2)
{ int diff, match=0;
  if (p1 == 0 || p2 == 0) return -1;
  while (*p1)
    if ((diff = toupper(*p1++) - toupper(*p2++)) != 0) break; else match++;
  if (diff == 0 && match < 3 && *p2) return -*p2;
  return diff;
}
int match_1st_str(const char *str, char **p, int items)
{ int i;
  if (p == 0 || *p == 0) return -1;
  for (i=0; i < items; i++)
    if (min_match(str, p[i]) == 0) break;
  return i;
}

int get_msgid(void)
{ int i, n;
  if (MsgId < 0)
    if ((MsgId = msgget(InpMsgKey, MsgPerm | IPC_CREAT)) < 0)
    { perror("MSGGET: "); return -errno; }
  for (i=4*SubMax; i >= 0; i--)
    if ((n=msgrcv(MsgId, (void *)Msg.buf, Len-2, i, IPC_NOWAIT|MSG_NOERROR))<0)
    { if (errno == ENOMSG) continue; }
    else i++;
  fprintf(stderr,"All the stale messages cleared\n");
  return MsgId;
}
int get_msg(MsgType *msg)
{ int i, n;
  for (i=2*SubMax; i > 0; i--)
  { if ((n=msgrcv(MsgId, (void *)msg, Len-2, 2*i-1, IPC_NOWAIT|MSG_NOERROR))<0)
      if (errno == ENOMSG) continue; else { perror("MSGRCV: "); MsgId = -1; return -12; }
    else break;
  }
  if (i == 0) return 0; else MsgSrc = 2*i-1;
  if (msg->buf[n-1] != 0) msg->buf[n] = 0;
  n = strlen(msg->buf);
  while (n > 0 && isspace(msg->buf[n-1])) msg->buf[--n] = 0;
  return n+1;
}
int parse_cmd(ProtocolType *frame, const char *msg, char *str)
{ int i, len=0;

  if (sscanf(msg,"%d %d %s %s", &SaNum, &CmdId, CmdTypeStr, CmdStr) != 4)
    return -1;
  CmdType = match_1st_str(CmdTypeStr, ServiceName, Services);
  Cmd = match_1st_str(CmdStr, DasCmdName, DasCmds);
  if (CmdType == Services || Cmd == DasCmds) return -3;

  *str = 0;
  for (i=0; i < 4; i++)
  { while (isspace(*msg)) msg++; while (*msg && !isspace(*msg)) msg++; }
  while (isspace(*msg)) msg++;
  if (*msg) { strcpy(str, msg); len = strlen(str); }
  ConsProt(CmdNode, AcqNode, CmdType, Cmd, CmdId, Request, 0, len, frame);
  return 1;
}

int  const_frame(ProtocolType *frame, char *sockbuf,long off,char *param, char *buf, long nb)
{ char filename[256];  FILE *fp;   int  n;
  strcpy(filename, param) ;
  if ( (fp = fopen(filename,"rb")) == NULL) { perror(filename); return -7 ; }
  n = fread(buf,1, nb,fp) ;
  fclose(fp) ;
  fprintf(stderr,"got %d bytes from %s\n",n,filename) ;
  //printf("FILE CONTENT ===>%s",buf);
  memcpy(sockbuf+off, buf, n) ;
  frame->len = n+off;  frame->usrflag = 0 ;   
  return 0;
}

int get_cmd(ProtocolType *frame,char **sockbuf, char *param_str, MsgType *msg)
{ int n;
  SourceParType  source ;
  ProjectTable   *ptab;
  ProjectType    proj;
  int            sac,i;
  long           off;
  unsigned int   o_antmask,d_antmask;
  unsigned short bandmask;
  char           filename[256],buf[ProtMaxBuf];
  
  fprintf(stderr,"#### Waiting for command from Online\n");
  if((n = get_msg(msg))<=0) return n;
  fprintf(stderr,"Cmd Recvd: %s\n", msg->buf);
  if((n = parse_cmd(&frame[0], msg->buf, param_str))<0)
  { fprintf(stderr,"error parsing %s\n",msg->buf); return n;}
  for(i=1;i<MaxCorrelators;i++)
    memcpy(&frame[i],&frame[0],sizeof(ProtocolType));
  SendReply = 1 ;
  if((sac =MsgSrc/4 < 0) || sac > SubMax)
    {fprintf(stderr,"Illegal SubArray Number %d\n",sac); return -1;}
  if(SaNum < 0 || SaNum > SubMax)
    {fprintf(stderr,"Illegal SubArray Number %d\n",SaNum); return -1;}
  ptab=&ProjTab[SaNum];
  for(i=0;i<MaxCorrelators;i++)
    for(n=0;n<ProtMaxBuf;n++)sockbuf[i][n]=0;
  switch (CmdType)
  { case DAS :
      for(i=0;i<MaxCorrelators;i++){frame[i].type=DAS; frame[i].cmd=Cmd;}
      switch(Cmd)
      { case DAS_RESUME :
  	  SendReply = 0 ; break;
        case DAS_INIT:
	  CheckPrivilige(DAS_INIT,sac);
	  if(sscanf(param_str,"%d %x %hx %s",&CorrId,&o_antmask,&bandmask,filename) !=4)
	  { fprintf(stderr,"Too few params in %s\n",param_str); return -1;}

          /* GBSE : CorrID 8 only for GSBE  */
            if ( CorrId != 8 && CorrId != 12 ) CorrId = CorrMask[2] | CorrId;  /* force send to CorrCtl */
          
	  if(map_mask(o_antmask,&d_antmask)) return -1;

	  for(i=0;i<MaxCorrelators;i++)
	  { memcpy(sockbuf[i],&d_antmask,sizeof(unsigned int));
	    if(1<<i&CorrMask[i])bandmask = CorrBandMask[i];
	    memcpy(sockbuf[i]+sizeof(unsigned int),&bandmask,sizeof(unsigned short));
	    off=sizeof(unsigned int)+sizeof(unsigned short);
	    if((n=const_frame(&frame[i],sockbuf[i],off,filename, buf,ProtMaxBuf))<0)
	      return n;
	  }
	  for(n=off;n<ProtMaxBuf;n++)if(sockbuf[0][n]==0) break;
          if (n == ProtMaxBuf){for(i=0;i<MaxCorrelators;i++)sockbuf[i][n-1]=0;}
          for(i=0;i<MaxCorrelators;i++)frame[i].len=n ; 
          break ;
        case DAS_FINISH:
	  CheckPrivilige(DAS_FINISH,sac);
	  if(sscanf(param_str,"%d",&CorrId) !=1)
	  { fprintf(stderr,"Too few params in %s\n",param_str); return -1;}
          /* GBSE : CorrID 8 only for GSBE  */
	  if (CorrId != 8 && CorrId != 12) CorrId = CorrMask[2] | CorrId;  /* force send to CorrCtl */
	  for(i=0;i<MaxCorrelators;i++)frame[i].len=0 ; 
          
          break ;
        case ADDPROJ:
	  CheckPrivilige(ADDPROJ,sac);
	  if(sscanf(param_str,"%d %s",&CorrId,filename) !=2)
	  { fprintf(stderr,"Too few params in %s\n",param_str); return -1;}

          /* GBSE : CorrID 8 only for GSBE  */
	  if (CorrId != 8 && CorrId != 12 ) CorrId = CorrMask[2] | CorrId;  /* force send to CorrCtl */

	  if(ptab->corr_id&CorrId)
	  { for(i=0;i<MaxCorrelators;i++)
	      if((CorrId&ptab->corr_id)&CorrMask[i])
	      { fprintf(stderr,"SubArray %d curretnly running",SaNum);
	        fprintf(stderr," Project %s on %s:- Delete First\n",
			ptab->proj[i].code,CorrelatorName[i]); 
	      }
	     return -1;
	  }
	  for(i=0;i<MaxCorrelators;i++)
	  { if(CorrId & CorrMask[i])
	    { if ((n=const_frame(&frame[i],sockbuf[i],0,filename, buf,
				 sizeof(ProjectType)))<0) return n;
	       memcpy(&proj,sockbuf[i],sizeof(ProjectType));
	       if(map_mask(proj.antmask,&d_antmask)) return -1;
	       proj.antmask=d_antmask; proj.code[7]='\0';
	       proj.bandmask &= CorrBandMask[i];
	       memcpy(&ptab->proj[i],&proj,sizeof(ProjectType));
	       memcpy(sockbuf[i],&proj,sizeof(ProjectType));
       	       fprintf(stderr,"%s :AddProjReq for %s %x %x %x\n",CorrelatorName[i],
		       proj.code,proj.antmask,proj.bandmask, CorrBandMask[2]);

	    }
	  }
	  break;
        case DELETEPROJ:
	  CheckPrivilige(DELETEPROJ,sac);
	  if(sscanf(param_str,"%d",&CorrId) !=1)
	  { fprintf(stderr,"Too few params in %s\n",param_str); return -1;}
          /* GBSE : CorrID 8 only for GSBE */
          if ( CorrId != 8 && CorrId != 12 ) CorrId = CorrMask[2] | CorrId;  /* force send to CorrCtl */
	  if(!ptab->corr_id & CorrId)
  	  { fprintf(stderr,"SubArray %d: No Project or Bad CorrId\n",SaNum); return -1;}
          for(i=0;i<MaxCorrelators;i++)
	    if(CorrId &CorrMask[i])
	    {strncpy(sockbuf[i],ptab->proj[i].code,8);frame[i].len=8;frame[i].usrflag=0;}
	  break;
        case STARTPROJ :
	  if(ptab->corr_id==0)
	  { fprintf(stderr,"SubArray %d: No Project to start!\n",SaNum); return -1;}
	  CorrId=ptab->corr_id;

	  for(i=0;i<MaxCorrelators;i++)
	  { if(CorrMask[i]&CorrId)
	    { strncpy(sockbuf[i],ptab->proj[i].code,8);
	      if((n=const_frame(&frame[i],sockbuf[i],8,param_str,buf,
				sizeof(SourceParType)))<0) return n;
	      memcpy(&source,sockbuf[i]+8,sizeof(SourceParType));
	      if(map_mask(source.antmask,&d_antmask)) return -1;
	      source.antmask=d_antmask;
	      source.bandmask &=CorrBandMask[i];
	      memcpy(sockbuf[i]+8,&source,sizeof(SourceParType));
	      fprintf(stderr,"%s : StartReq for Code %s AntMask %x BandMask %x\n",CorrelatorName[i],
		      ptab->proj[i].code,source.antmask,source.bandmask);
	    }
	  }
	  break;
        case STOPPROJ :
	  if(ptab->corr_id==0)
	  { fprintf(stderr,"SubArray %d: No Project to stop!\n",SaNum); return -1;}
	  CorrId=ptab->corr_id;
	  for(i=0;i<MaxCorrelators;i++)
	  { if(CorrMask[i]&CorrId)
	    { strncpy(sockbuf[i],ptab->proj[i].code,8);
	      frame[i].len=8;frame[i].usrflag=0;
	      fprintf(stderr,"%s : StopReq for Project %s\n",CorrelatorName[i],
		      ptab->proj[i].code);
	    }
	  }
          break;
	default       : SendReply = 0 ;
       }
    default : break ;
  }
  return 1;
}
void rep_cmd(ProtocolType *frame, MsgType *msg, char *corr_name)
{ int l;
  msg->type = MsgSrc+1;
  if (frame->flag & Success)
    l = sprintf(msg->buf,"SUCCEDED");
  else l = sprintf(msg->buf,"FAILED");
  if ((l=msgsnd(MsgId, (void *)msg, l+1, 0)) < 0)
    fprintf(stderr, "Error in replying for CmdId=%d\n", CmdId);
  else fprintf(stderr, "'%s' sent to ONLINE\n",msg->buf) ;
}
void ack_cmd(int CmdId, MsgType *msg)
{ int l;
  fprintf(stderr," ###### ACK COMMAND ####\n");
  msg->type = MsgSrc+1;
  l = sprintf(msg->buf,"ack from DAS");
  if ((l=msgsnd(MsgId, (void *)msg, l+1, 0)) < 0)
    fprintf(stderr,"Error in acknowledging for CmdId=%d\n", CmdId);
 else
   { //fprintf(stderr,"####MSGTYPE => %ld  ######ACK_MSG=>%s Length=>%d\n",msg->type,msg->buf,l); 
   }
}
int send_cmd(int com_sock,ProtocolType *frame, char *sockbuf, ProtocolType *rframe)
{ int l, m = ProtSz ; 

  l = tcp_send(com_sock, frame, ProtSz, 0) ;
  if(frame->len) tcp_send(com_sock, sockbuf, frame->len, 0) ;
  
  l = tcp_recv(com_sock, rframe, m, 0);
  if (l == -1)
  { perror("tcp_recv");
    fprintf(stderr,
           "FrameErr m=%d %d %d %d\n",m,frame->type,frame->cmd,frame->len);
    rframe->flag = Failure ;
  }
  else rframe->len = 0 ;
  fprintf(stderr,"%d F=%d S=%d\n",rframe->flag,Failure,Success);

  return 0;

}

int conn_corr()
{ ProtocolType frame;
  int n=1,i; 
  fprintf(stderr,"CorrId=%d\n",CorrId);	
  for(i=0;i<4;i++)
  { if(CorrId & (CorrMask[i]))
  { if(ComSock[i]>0) continue; /* already connected */
    fprintf(stderr,"#### conn_corr()=>open %d Corr %s Port %d\n",i,CorrelatorName[i],PortNum[i]);
    if((ComSock[i]=open_tcp_sock(PortNum[i])) < 0)
      { fprintf(stderr,"error opening socket for %s\n",CorrelatorName[i]); return -1; }
      ConsProt(CmdNode, AcqNode, AckMsg, 0, 0, LocalByteOrder, 0, 0, &frame);
      fprintf(stderr,"Waiting for %s to acknowledge.....",CorrelatorName[i]) ;
      tcp_send(ComSock[i], &frame, ProtSz, 0) ;
      n = tcp_recv(ComSock[i], &frame, ProtSz, 0) ;
      fprintf(stderr,"   OK! Got %d\n", n) ;
      OpenCorr |= (1<<i);
      usleep(12000);
    }
  }
  return 0;
}

int setmask(unsigned char dpcmux)
{ unsigned char  s[4];
  unsigned char dpc2bandmask[4]={4,8,1,2}; /* assumes default sampler connections: viz, (L130,L175,U130,U175) */
  int i;

  for (i=0; i<4; i++) 
  { s[i] = dpcmux & 0x3; dpcmux=dpcmux>>2; }
  
  CorrBandMask[0] = (dpc2bandmask[s[0]]|dpc2bandmask[s[1]]); /* acqB */
  CorrBandMask[1] = (dpc2bandmask[s[2]]|dpc2bandmask[s[3]]); /* acqA */
  CorrBandMask[2] = CorrBandMask[0] | CorrBandMask[1];       /* ctl  */
  
  CorrBandMask[3] = CorrBandMask[1];  /* Temporary for GSBE dummy correlator
                                         HardCoded - Assigning Only USB BAND 03 %3% */

  fprintf(stderr, "##### INFO CorrBandMask 0[%x] 1[%x] 2[%x] 3[%x]\n",
          CorrBandMask[0],CorrBandMask[1],  CorrBandMask[2],CorrBandMask[3]);
  return 0;
}

int main(int argc, char *argv[]) 
{ ProtocolType  frame[MaxCorrelators], rframe[MaxCorrelators];
  char          param[Len],*sockbuf[MaxCorrelators];
  int           n,i,err;
  char          corr_sel_file[1024],dpc_mode[32];
  CorrType      corr;


#ifdef CORR_SEL_FILE
  strncpy(corr_sel_file,CORR_SEL_FILE,1023); 
#else
  strcpy(corr_sel_file,"/home/teleset/corrsel.hdr");
#endif
  if((err = corr_pre(corr_sel_file, &corr)))
  { fprintf(stderr,"error %d parsing configuration file %s\n",err,corr_sel_file); return 1;}
  fprintf(stderr,">> Reading configuration from %s\n", corr_sel_file) ;

  n=1; if (*((unsigned char *)&n) == 1) LocalByteOrder = LittleEnd;
  else LocalByteOrder = BigEnd;

  for(i=0;i<MaxCorrelators;i++)
  { if((sockbuf[i]=malloc(ProtMaxBuf))==NULL)
    { fprintf(stderr,"Malloc Failure!\n"); return -1; }
    ComSock[i]=-1;
  }
  for(n=0;n<SubMax;n++)
    for (i=0;i<MaxCorrelators;i++)
    { ProjTab[n].proj[i].code[0]='\0';ProjTab[n].corr_id=0;}
  OpenCorr=0;

/* Decides mask for correlator Mode i.e. Indian Polar,USB/LSB Polar etc  */
  setmask(corr.corrpar.dpcmux);
  get_dpc_mode_name(corr.corrpar.dpcmux,dpc_mode); 

  fprintf(stderr,"DPCMODE=%s Corr0Mask=%x Corr1Mask=%x Corr2Mask=%x\n",
	  dpc_mode,CorrBandMask[0],CorrBandMask[1],CorrBandMask[2]);
  

  get_msgid(); /* connect to the ONLINE MsgQueue */

  while (1)
  { n = get_cmd(frame,sockbuf,param,&Msg);
     
    if (n < 0)
    { fprintf(stderr,"Error Number %d\n", n); 
      rframe[0].flag=Failure; rep_cmd(&rframe[0], &Msg,"");
    }
    if(n == 0) { sleep(1); continue; }
    if(n > 0)
    { ack_cmd(CmdId,&Msg); /* let ONLINE know we got the command */
      for(i=0;i<MaxCorrelators;i++)
      { if(CorrId & CorrMask[i])
        { fprintf(stderr, "To %s: %s, CmdDest=%d, CmdId=%d, CmdType=%s, Cmd=%s, param=%s\n",
		 CorrelatorName[i],NodeName[frame[i].dest], frame[i].id, frame[i].usrflag,
		  ServiceName[frame[i].type], CmdStr, param);
		  fprintf(stderr,"CorrId=%d\n",CorrId);

/*        if((i<3)&&(!DryRun))   i==3 is the DummyCorrelator*/

/* Changed Logic for GBSE  */
	  if((i<4)&&(!DryRun))  /* i==3 is the DummyCorrelator*/
	  { if(ComSock[i]<0) /* socket not yet open */
	     if(conn_corr()<0)
	     { fprintf(stderr,"Cannot Connect to %s\n",CorrelatorName[i]); return -1;}
	    send_cmd(ComSock[i],&frame[i],sockbuf[i],&rframe[i]);
	  }else
	  { rframe[i].type=frame[i].type; rframe[i].cmd=frame[i].cmd;
	    rframe[i].flag=Success;  /* DryRuns and dummy correlator alway work! */
	  }


	  rep_cmd(&rframe[i], &Msg, CorrelatorName[i]); /* report status to ONLINE */

	  if (rframe[i].type == DAS)
          { ProjectTable *ptab=&ProjTab[SaNum];
	    switch(rframe[i].cmd)
	    { case DAS_FINISH:
	        if(rframe[i].flag&Success)
	        { OpenCorr &= ~(CorrMask[i]); if(i<3)close(ComSock[i]);}
	        if(OpenCorr==0) return 0;
		break;
	      case ADDPROJ:
	        if(rframe[i].flag&Success)ptab->corr_id |=CorrMask[i];
		break;
	      case DELETEPROJ:
		if(rframe[i].flag&Success)ptab->corr_id &=!CorrMask[i];
		break;
	      default:
		break;
	    }
	  }
	}
      }
    }
  }
}
