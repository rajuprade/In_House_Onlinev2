#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <stdio.h>
#include<stdlib.h>
#include <string.h>

#define MSGSZ     128


/*
 * Declare the message structure.
 */

typedef struct msgbuf {
         long    mtype;
         char    mtext[256*4];
         } message_buf;

main()
{
    int msqid;
    int msgflg = IPC_CREAT | 0600;
    key_t key;
    message_buf sbuf;
    message_buf  rbuf;
    size_t buf_length;
    int ii;
    /*
     * Get the message queue id for the
     * "name" 1234, which was created by
     * the server.
     */
    key = 201;

(void) fprintf(stderr, "\nmsgget: Calling msgget(%#lx,\
%#o)\n",
key, msgflg);

    if ((msqid = msgget(key, msgflg )) < 0) {
        perror("msgget");
        exit(1);
    }
    else 
     (void) fprintf(stderr,"msgget: msgget succeeded: msqid = %d\n", msqid);


    /*
     * We'll send message type 1
     */
     for(;;)
    {
      sbuf.mtype = 1;
    
    (void) fprintf(stderr,"msgget: msgget succeeded: msqid = %d\n", msqid);
    
     // (void) strcpy(sbuf.mtext, "0 bband init init  7FFFFFFE"); 
    (void) strcpy(sbuf.mtext, "0 0 das init   8 7FFFFFFE   F /home/teleset/gsb.hdr"); // Init Command 
  
    // (void)  strcpy(sbuf.mtext, " 0 1  das addp  8 /home/teleset/proj.hdr.user0");                // ADD project command 
     
  //   (void)  strcpy(sbuf.mtext, " 4 2  das start /home/teleset/scan.hdr.user4");                // DAS Start command 
   
     //  (void)  strcpy(sbuf.mtext, "4 3 das stop");                //   DAS Stop command 

//     (void)  strcpy(sbuf.mtext, "0 4 das delp  8");                // DElete project command 
  
     //(void)  strcpy(sbuf.mtext, "0  5 das fini  8");                // Finish  command 

    (void) fprintf(stderr,"msgget: msgget succeeded: msqid = %d\n", msqid);
    
    buf_length = strlen(sbuf.mtext) + 1 ;
    
    

    /*  
     * Send a message.
     */
    if (msgsnd(msqid, &sbuf, buf_length, IPC_NOWAIT) < 0) {
       printf ("%d, %d, %s, %d\n", msqid, sbuf.mtype, sbuf.mtext, buf_length);
        perror("msgsnd");
        exit(1);
      }

   else 
     printf("Message Sent=>%s\n", sbuf.mtext); 

        rbuf.mtype = 1;
        buf_length = strlen(rbuf.mtext) + 1 ;
        if(msgrcv(msqid,&rbuf,sizeof(rbuf.mtext),2,0) < 0)
        {
          printf ("MSQID=> %d MTYPE=>%ld MTEXT=>%s BUFFER_LENGTH=>%d\n", msqid, 2, rbuf.mtext, buf_length);
          perror("msgrcv");
          exit(1);
        }

   else 
      printf("Message Recieved => %s\n", rbuf.mtext); 
   }
    exit(0);
}
