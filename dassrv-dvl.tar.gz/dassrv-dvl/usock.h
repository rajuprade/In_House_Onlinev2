# ifndef _SOCK_H_
# define _SOCK_H_

extern int open_tcp_sock(int port);
extern int conn_tcp_sock(char *serv_host, int port);
extern int tcp_recv(int sockfd, void *buf, int nbytes, int flags);
extern int tcp_send(int sockfd, void *buf, int nbytes, int flags);
extern int open_udp_sock(int port);
extern int conn_udp_sock(char *serv_host, int port, void *addr, int *addr_len);
extern int make_udp_conn(int sofd,char *serv_host,int port,void *addr,int *len);
extern int udp_recv(int sockfd, void *buf, int nbytes, int flags);
extern int udp_send(int sockfd, void *buf, int nbytes, int flags);
extern int udp_recvfrom(int sockfd,void *buf,int nbytes,int flags,void*,int*);
extern int udp_sendto(int sockfd,void *buf,int nbytes,int flags,void*, int );
extern int block_sock(int sockfd, int unblock);
extern int get_tcp_sock(int sock, void *bufp, int len, int wait_ms);
extern void close_sock(int sockfd);

extern void init_sock(void);
extern int  conn_sock(char *name);
extern int  serv_sock(char *name);
extern void discard_sockmsg(int sock, int size);

# define open_sock conn_sock
# endif
