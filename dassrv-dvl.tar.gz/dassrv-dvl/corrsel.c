#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "newcorr.h"
#include <ctype.h>

#define MaxObsModes 256

#define DEFINE_MODE(c,n,m,d){\
     Mode[ObsModes].id=ObsModes;\
     Mode[ObsModes].maxchan=c;\
     strcpy(Mode[ObsModes].name,n);\
     strcpy(Mode[ObsModes].mac,m);\
     strcpy(Mode[ObsModes].dpc,d);\
     ObsModes++;\
     if(ObsModes==MaxObsModes)\
     { fprintf(stderr,"Exceeded MaxObsModes!\n"); return 1;}\
  }

typedef struct ObsModeStuct
{  int   id,maxchan;
  char   name[32],mac[32],dpc[32];
} ObsMode;

ObsMode Mode[MaxObsModes];
int     ObsModes;

int setmodes()
{ ObsModes=0;
  DEFINE_MODE(128,"IndianPolar","RRLL","IndianPolar");
  DEFINE_MODE(128,"UsbPolar","RRRL","UsbPolar");
  DEFINE_MODE(128,"LsbPolar","RRRL","LsbPolar");
  DEFINE_MODE(256,"UsbHighRes","RR","UsbPolar");
  DEFINE_MODE(256,"LsbHighRes","RR","LsbPolar");
  DEFINE_MODE(128,"UsbCopy","RRLL","UsbCopy");
  DEFINE_MODE(128,"LsbCopy","RRLL","LsbCopy");
  DEFINE_MODE(128,"AllU130","RRLL","AllU130");
  DEFINE_MODE(128,"AllU175","RRLL","AllU175");
  DEFINE_MODE(128,"AllL130","RRLL","AllL130");
  DEFINE_MODE(128,"AllL175","RRLL","AllL175");
  /*
  DEFINE_MODE(256,"U130HighRes","RR","AllU130");
  DEFINE_MODE(256,"U175HighRes","RR","AllU175");
  DEFINE_MODE(256,"L130HighRes","RR","AllL130");
  DEFINE_MODE(256,"L175HighRes","RR","AllL175");
  */
  return 0;
}
int main(int argc, char **argv)
{ int  sel_mode,lta1,clk_sel,i;
  char sel_chan[128],ans[256],*p;
  short chan_num[MAX_CHANS];
  float bw;
  FILE  *fp;
  char  corr_sel_file[1024];
  char  *BandWidth[]={"16","8","4","2","1","0.5","0.25","0.125"};

  strcpy(corr_sel_file,"corrsel.hdr");
#ifdef CORR_SEL_FILE
  strncpy(corr_sel_file,CORR_SEL_FILE,1023); /* defined in Makefile */
#endif

  if((fp=fopen(corr_sel_file,"w"))==NULL)
  { fprintf(stderr,"cannot open %s\n",corr_sel_file); return 1;}
  
  sel_chan[0]='\0';
  if(setmodes()){fprintf(stderr,"Mode Initialization Error\n"); return 1;}

  for(sel_mode=-1;sel_mode<0;)
 {  sel_mode=0;   /* default to IndianPolar */
     fprintf(stderr,"Please specify a numeric ObservingMode from the list below\n");
     for(i=0;i<ObsModes;i++)
       fprintf(stderr,"%2d %s\n",Mode[i].id,Mode[i].name);
     fprintf(stderr,"ObservingMode No [%d] : ",sel_mode); 
     fgets(ans,250,stdin);
     for(p=ans;*p!='\0' && isspace(*p);p++);
     for(i=strlen(ans);i>0;i--)
       if(isspace(ans[i-1]))ans[i-1]='\0';
     if(*p && strlen(p))sel_mode=(int)atoi(p);
     if(sel_mode<0 || sel_mode>=ObsModes)
     { fprintf(stderr,"Illegal choice %2d\n",sel_mode); sel_mode=-1;}
  }
  fprintf(stderr,">> Mode %2d [%s] selected\n\n",Mode[sel_mode].id,Mode[sel_mode].name);


  for(lta1=-1;lta1<=0;)
  { lta1=16;
    fprintf(stderr,"Please specify lta1 (16==2sec)\n");
    fprintf(stderr,"lta1 [%d] : ",lta1);
    fgets(ans,250,stdin);
    for(p=ans;*p!='\0' && isspace(*p);p++);
    for(i=strlen(ans);i>0;i--)
      if(isspace(ans[i-1]))ans[i-1]='\0';
    if(*p && strlen(p))lta1=(int)atoi(p);
    if(lta1<=0 )
      fprintf(stderr,"Illegal choice %2d\n",lta1); 
  }
  fprintf(stderr,">> Lta1 %d selected\n\n",lta1);

  for(bw=-1.0;bw<0;)
  { clk_sel=0;bw=16.0;
    fprintf(stderr,"Please specify bandwidth (one of 16 8 4 2 1 0.5 0.25 0.125) (MHz)\n");
    fprintf(stderr,"Bandwidth [%s] :",BandWidth[clk_sel]);
    fgets(ans,250,stdin);
    for(p=ans;*p!='\0' && isspace(*p);p++);
    for(i=strlen(ans);i>0;i--)
      if(isspace(ans[i-1]))ans[i-1]='\0';
    if(*p && strlen(p))bw=atof(p);
    if(bw<0.125 || bw > 16.0)
    { fprintf(stderr,"Illegal choice %6.3f\n",bw); bw=-1;}
    else
    { clk_sel=0;
      while(bw < 16.0){bw *=2; clk_sel++;}
    }
  }
  fprintf(stderr,">> Bandwidth %s (CLK_SEL  %d) selected\n\n",BandWidth[clk_sel],clk_sel);
  
  while(!strlen(sel_chan))
  { sprintf(sel_chan, "0:%d:1",Mode[sel_mode].maxchan-1);
    fprintf(stderr,"Please give channel selection\n");
    fprintf(stderr,"Channel Selection [%s] :", sel_chan);
    fgets(ans,250,stdin);
    for(p=ans;*p!='\0' && isspace(*p);p++);
    for(i=strlen(ans);i>0;i--)
      if(isspace(ans[i-1]))ans[i-1]='\0';
    if(*p && strlen(p))strcpy(sel_chan,p);
    i=get_range(sel_chan,chan_num,MAX_CHANS);
    if(chan_num[0]<0 || chan_num[i-1]>=Mode[sel_mode].maxchan)
    { fprintf(stderr,"Illegal Selection %s\n",sel_chan);sel_chan[0]='\0';}
  }
  fprintf(stderr,">> Channel Selection %s\n\n",sel_chan);


  fprintf(fp,"{ Corrsel.def \n");
  fprintf(fp,"LTA     = %d \n",lta1);
  fprintf(fp,"CLK_SEL = %d ",clk_sel);
  fprintf(fp,"           /* bandwidth = %s MHz */\n",BandWidth[clk_sel]);
  fprintf(fp,"CHAN_NUM= %s \n",sel_chan);
  fprintf(fp,"MAC_MODE= %s ",Mode[sel_mode].mac);
  fprintf(fp,"        /* legal values: RRLL RRRL RR */\n");
  fprintf(fp,"DPC_MUX = %s \n",Mode[sel_mode].dpc);
  fprintf(fp,"MODE    = 0 \n");
  fprintf(fp,"FFT_MODE= 0 ");
  fprintf(fp,"           /* fft_size = 512/2^fft_mode*/\n");
  fprintf(fp,"} Corrsel\n");
  fprintf(fp,"*\nEND_OF_HEADER\n");

  fprintf(stderr,">> UPDATED HEADER FILE %s \n",corr_sel_file);

  return 0;
}
