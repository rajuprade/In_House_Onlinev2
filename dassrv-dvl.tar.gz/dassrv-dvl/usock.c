# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include <unistd.h>
# include <sys/types.h>
# include <sys/socket.h>
# include <netinet/in.h>
# include <arpa/inet.h>
# include <netdb.h>
# include <errno.h>
# include <fcntl.h>

enum { MaxProtBuf = 16384 };

int get_self_addr(int port, struct sockaddr_in *host_addr)
{
  host_addr->sin_addr.s_addr = INADDR_ANY;
  host_addr->sin_family = AF_INET;
  host_addr->sin_port   = htons(port);
  return 0;
}
int get_host_addr(char *hostname, int port, struct sockaddr_in *host_addr)
{ struct hostent *host;

  if ((host = gethostbyname(hostname)) == NULL) return -1;
  host_addr->sin_addr.s_addr = *(u_long *)host->h_addr;
  host_addr->sin_family = AF_INET;
  host_addr->sin_port   = htons(port);
  return 0;
}
int open_tcp_sock(int port)
{ int new_sofd, reuse=1, sofd;
  struct sockaddr_in host_addr, cli_addr;
  struct linger lval={0,0};
  socklen_t  addr_len = sizeof(struct sockaddr_in);

  if (get_self_addr(port, &host_addr) < 0) return -1;
  if ((sofd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0) return -2;
  setsockopt(sofd,SOL_SOCKET,SO_LINGER,(void*)&lval,sizeof(struct linger));
  if (setsockopt(sofd, SOL_SOCKET, SO_REUSEADDR,(void*)&reuse,sizeof(int)) < 0)
  { perror("setsockreuse");return -3; }
  if (bind(sofd, (struct sockaddr *)&host_addr, addr_len) < 0) return -3;
  if (listen(sofd, 1) < 0) return -4;
  fprintf(stderr,"@@@@@@@ Waiting for Corr Socket to connect\n");
  if ((new_sofd = accept(sofd, (struct sockaddr *)&cli_addr, &addr_len)) < 0)
    return -5;
  close(sofd);
  return new_sofd;
}
int open_udp_sock(int port)
{ int sofd, addr_len = sizeof(struct sockaddr_in);
  struct sockaddr_in host_addr;

  if (get_self_addr(port, &host_addr) < 0) return -1;
  if ((sofd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0) return -2;
  if (bind(sofd, (struct sockaddr *)&host_addr, addr_len) < 0) return -3;
  return sofd;
}
int conn_tcp_sock(char *serv_host, int port)
{ int sofd, reuse=1, addr_len = sizeof(struct sockaddr_in);
  struct sockaddr_in host_addr;
  struct linger lval={0,0};

  if (get_host_addr(serv_host, port, &host_addr) < 0) return -1;
  if ((sofd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0) return -2;
  setsockopt(sofd, SOL_SOCKET, SO_LINGER, (void*)&lval,sizeof(struct linger));
  if (setsockopt(sofd,SOL_SOCKET,SO_REUSEADDR,(void*)&reuse, sizeof(int)) < 0)
  { perror("setsockreuse"); return -4; }
  if (connect(sofd, (struct sockaddr *)&host_addr, addr_len) < 0)
  { close(sofd);return -3;}
  return sofd;
}
int conn_udp_sock(char *serv_host, int port, void *addr, socklen_t *addrlen)
{ int sofd, addr_len = sizeof(struct sockaddr_in);
  struct sockaddr_in host_addr;

  if (get_host_addr(serv_host, port, &host_addr) < 0) return -1;
  if ((sofd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0) return -2;
  if (connect(sofd, (struct sockaddr *)&host_addr, addr_len) < 0)
     return -3;
  if (*addrlen < addr_len) return -4;
  else { *addrlen = addr_len; memcpy(addr, &host_addr, addr_len); }
  return sofd;
}
int make_udp_conn(int sofd, char *serv_host, int port, void *addr,socklen_t *addrlen)
{ int addr_len = sizeof(struct sockaddr_in);
  struct sockaddr_in host_addr;

  if (get_host_addr(serv_host, port, &host_addr) < 0) return -1;
  if (connect(sofd, (struct sockaddr *)&host_addr, addr_len) < 0)
     return -3;
  if (*addrlen < addr_len) return -4;
  else { *addrlen = addr_len; memcpy(addr, &host_addr, addr_len); }
  return sofd;
}
int tcp_recv(int sockfd, void *inbuf, int nbytes, int flags)
{ int l, m, n=0;
  char *buf = inbuf ;
  while (n < nbytes)
  { if (nbytes - n > MaxProtBuf) l = MaxProtBuf; else l = nbytes - n;
    m = recv(sockfd, buf+n, l, flags);
    if (m < 0)
    { if (errno == EINTR) continue; else break; }
    n += m;
  }
  return n;
}
int tcp_send(int sockfd, void *outbuf, int nbytes, int flags)
{ int l, m, n=0;
  char *buf = outbuf ;
  while (n < nbytes)
  { if (nbytes - n > MaxProtBuf) l = MaxProtBuf; else l = nbytes - n;
    m = send(sockfd, buf+n, l, flags);
    if (m < 0)
    { if (errno == EINTR) continue; else break; }
    n += m;
  }
  return n;
}
int udp_recv(int sockfd, void *inbuf, int nbytes, int flags)
{
  return recv(sockfd, inbuf, nbytes, flags);
}
int udp_send(int sockfd, void *outbuf, int nbytes, int flags)
{
  return  send(sockfd, outbuf, nbytes, flags);
}
int udp_recvfrom(int sockfd,void *inbuf,int nbytes,int flags,void *addr,socklen_t *addrlen)
{
  return recvfrom(sockfd, inbuf, nbytes,flags,(struct sockaddr *)addr,addrlen);
}
int udp_sendto(int sockfd,void *outbuf,int nbytes,int flags,void *addr,socklen_t addrlen)
{
  return sendto(sockfd, outbuf, nbytes, flags,(struct sockaddr *)addr,addrlen);
}
void close_sock(int sockfd)
{
  close(sockfd);
}
int block_sock(int sockfd, int unblock)
{ int flg;
  flg = fcntl(sockfd, F_GETFL, &flg);
  if (flg < 0) return flg;
  /* printf("so_block: flg %d flg+ %d\n", flg, flg | O_NDELAY); */
  if (unblock) flg |= O_NDELAY; else flg &= ~O_NDELAY ;
  return fcntl(sockfd, F_SETFL, flg);
}

enum { MaxSock = 10 };
static char HostName[MaxSock][40], HostIP[MaxSock][32], SockName[MaxSock][16];
static int  Sockets, Sockfd[MaxSock], TCP_port[MaxSock], SockInit=0;

void init_sock(void)
{ char str[128];
  FILE *f;
  int i=0, n;
  char *p;
  char  HostsFile[512];

  for (i=0; i < MaxSock; i++) Sockfd[i] = -1; i = 0;
  if ( (p = getenv("HOSTS_FILE")) == NULL){ 
    fprintf(stderr, "Fatal: HOSTS_FILE env not defined\n"); 
    return;
  }
  strcpy(HostsFile, p) ;
  if ((f = fopen(HostsFile, "rt")) == NULL){
    fprintf(stderr,"Fatal: Cannot Open hosts.dat File\n");
    return;
  }
  while (fgets(str, 128, f) && i < MaxSock)
  { if (*str == '#') continue;
    n = sscanf(str,"%s %s %d %s", HostName[i], HostIP[i],
        &TCP_port[i], SockName[i]);
    if (n < 4) break;
    i++;
  }
  Sockets = i;
  fclose(f);
}
int conn_sock(char *name)
{ int i;
  if (!SockInit) { init_sock(); SockInit = 1; }
  for (i=0; i < Sockets; i++) if (strcmp(name, SockName[i]) == 0) break;
  if (i == Sockets) return -1;
  if (Sockfd[i] >= 0) return Sockfd[i];
  Sockfd[i] = conn_tcp_sock(HostIP[i], TCP_port[i]) ;
  return Sockfd[i];
}
int serv_sock(char *name)
{ int i;
  if (!SockInit) { init_sock(); SockInit = 1; }
  for (i=0; i < Sockets; i++) if (strcmp(name, SockName[i]) == 0) break;
  if (i == Sockets) return -1;
  if (Sockfd[i] >= 0) return Sockfd[i];
  Sockfd[i] = open_tcp_sock(TCP_port[i]) ;
  return Sockfd[i];
}

# ifdef _SOLARIS_
# include <signal.h>
# include <time.h>
void sig_t(int sig) { return; }
void usleep(int usec)
{ sigset_t mask={{0,0,0,0}};
  struct itimerval it={{0,0},{0,0}};
  it.it_value.tv_sec  = usec / 1000000;
  it.it_value.tv_usec = usec % 1000000;
  signal(SIGALRM, sig_t);
  setitimer(ITIMER_REAL, &it, NULL);
  sigsuspend(&mask);
}
#endif
void discard_sockmsg(int sock, int size)
{ enum { Size=4096 };
  char buf[Size];
  int n;
  while (size > 0)
  { if (size > Size) n = Size; else n = size;
    n = tcp_recv(sock, buf, n, 0);
    if (n > 0) size -= n;
    else if (n < 0) perror("sock");
    else usleep(10000);
  }
}
int get_tcp_sock(int sock, void *buf, int len, int wait_ms)
{ int l, m=len;
  char *bufp=buf;
  do
  { l = tcp_recv(sock, bufp, m, 0);
    if (l == -1)
    { if (errno == EWOULDBLOCK && wait_ms > 0)
      { l = 0; usleep(20000); wait_ms -= 20; }
      if (l < 0)
      { perror("tcp_recv") ;
        fprintf(stderr,"Error receiving data %d %d\n", len, m);
        return -errno ;
      }
    }
    else if (l != len) fprintf(stderr,"recvd partial packet %d of %d\n",l,len);
    bufp += l; m -= l ;
  } while (m > 0) ;
  return len;
}

