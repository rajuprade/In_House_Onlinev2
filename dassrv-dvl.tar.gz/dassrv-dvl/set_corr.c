#include <stdlib.h>
#include <stdio.h>
#include  <string.h>
#include "newcorr.h"

enum {DelayFull=0,Delay,FftMac,Mac,Pulsar,SubSystems};
static char *SubSystemName[SubSystems]={"delay_full","delay","fft_mac","mac","pulsar"};
static char *SubSystemCmd[SubSystems]={"newdly_config","dlyconfig","corr_config","corr_config",
				       "corr_configa"};
static char *SubSystemDescription[SubSystems]={"Complete Delay Config","Set DpcMode & ClkSel",
				       "Complete Corr Config","Config Mac Mode","Corr Config for Pular Mode"};


enum{New=0,Old,Tst,Dvl,DasVersions};
static char *DasVersionName[DasVersions]={"new","old","tst","dvl"};

enum{DasVersion=0,SubSystem,CorrSelFile,RemoteHost,LongOptions};
static char *LongOptionName[LongOptions]={"version","subsys","file","host"};

int main(int argc, char **argv)
{ CorrType corr;
  char    corr_sel_file[1024],remote_cmd[2048],remote_host[2048],cmd[1024],remote_user[128];
  char    version[24],ssh_cmd[1024],Usage[2048],dpc_mode[32],ack[2048];
  int     i,j,opt,sub_system,das_version,err;


#ifdef SSH_CMD
  strncpy(ssh_cmd,SSH_CMD,1023);
#else
  strcpy(ssh_cmd,"ssh");
#endif

#ifdef REMOTE_HOST
  strncpy(remote_host,REMOTE_HOST,1023);
#else
  strcpy(remote_host,"corrctl");
#endif

#ifdef REMOTE_USER
  strncpy(remote_user,REMOTE_USER,127);
#else
  strcpy(remote_user,"observer");
#endif

#ifdef CORR_SEL_FILE
  strncpy(corr_sel_file,CORR_SEL_FILE,1023); 
#else
  strcpy(corr_sel_file,"corrsel.hdr");
#endif

  das_version=Dvl;
#ifdef DEFAULT_VERSION
  for(i=0;i<DasVersions;i++)
    if(!strcasecmp(DEFAULT_VERSION,DasVersionName[i])) break;
  if(i==DasVersions)
  { fprintf(stderr,"Unrecognized version %s\n",DEFAULT_VERSION);
    fprintf(stderr,"Recognized versions are: ");
    for(i=0;i<DasVersions;i++)fprintf(stderr,"%s ",DasVersionName[i]);
    fprintf(stderr,"\n >> Setting Das Version to %s",DasVersionName[Dvl]);
  }
  else das_version=i;
#endif


  sprintf(Usage,"USAGE:  set_corr --subsys SubSystem [--host CorrHostName][--file ConfigFile]");
  sprintf(Usage+strlen(Usage),"\n        [--version Version]\n");
  sprintf(Usage+strlen(Usage),"         Where SubSystem is one of:\n");
  for(i=0;i<SubSystems;i++)sprintf(Usage+strlen(Usage),"            %-16s (%s)\n",SubSystemName[i],
				   SubSystemDescription[i]);
  sprintf(Usage+strlen(Usage),"         and Version is one of: ");
  for(i=0;i<DasVersions;i++)sprintf(Usage+strlen(Usage)," %s",DasVersionName[i]);
  sprintf(Usage+strlen(Usage),"\n");

  if(argc<=1){fprintf(stderr,"%s\n",Usage); return 1;}

  for(i=1;i<argc;i++)
  { char *p;
    if(strstr(argv[i],"--") !=argv[i])
    { fprintf(stderr,"%s\n",Usage); return 1;}
    for(j=0;j<LongOptions;j++)
      if(!strcmp(argv[i]+2,LongOptionName[j])){opt=j;break;}
    if(j==LongOptions)
    { fprintf(stderr,"Unrecognized option %s\n%s\n",argv[i]+2,Usage); return 1;}
    switch(opt)
    { case DasVersion: for(j=0;j<DasVersions;j++)
                       if(!strcmp(argv[i+1],DasVersionName[j]))break;
	               if(j==DasVersions)
		       { fprintf(stderr,"Unrecognized Version %s\n",argv[i+1]);
  			 fprintf(stderr,"Recognized versions are one of:");
			 for(j=0;j<DasVersions;j++)fprintf(stderr," %s", DasVersionName[j]);
			 fprintf(stderr,"\n");
			 return 1;
		       }
		       das_version=j;
		       i++;
		       break;
      case SubSystem:  for(j=0;j<SubSystems;j++)
                       if(!strcmp(argv[i+1],SubSystemName[j]))break;
	               if(j==SubSystems)
		       { fprintf(stderr,"Unrecognized SubSystem %s\n",argv[i+1]);
  			 fprintf(stderr,"Recognized SubSystems are one of:");
			 for(j=0;j<SubSystems;j++)fprintf(stderr," %s", SubSystemName[j]);
			 fprintf(stderr,"\n");
			 return 1;
		       }
		       i++;
		       sub_system=j;
		       break;
    case CorrSelFile:  strncpy(corr_sel_file,argv[i+1],2047);
                       corr_sel_file[2047]='\0';
		       break;
    }
  }

  if((err = corr_pre(corr_sel_file, &corr)))
  { fprintf(stderr,"error %d parsing configuration file %s\n",err,corr_sel_file); return 1;}
  fprintf(stderr,">> Reading configuration from %s\n", corr_sel_file) ;
    
  sprintf(remote_cmd,"%s %s@%s '(source /home/corrsoft/bin/set_corr_env %s; %s ",ssh_cmd,remote_user,
	  remote_host,DasVersionName[das_version],SubSystemCmd[sub_system]);
  switch(sub_system)
  {  case Delay: get_dpc_mode_name(corr.corrpar.dpcmux,dpc_mode);
                 sprintf(cmd,"-c %d -m %s",corr.corrpar.clksel,dpc_mode);
		 strcat(remote_cmd,cmd);
		 sprintf(ack," Setting CLK_SEL to %d  and DPC_MODE to %s",corr.corrpar.clksel,dpc_mode);
		 break;
    case Mac   : switch(corr.corrpar.macmode)
                 { case RRLL:sprintf(cmd,"$CFG_DIR/mac.cmd.RRLL ");
                             strcat(remote_cmd,cmd); 
                             sprintf(ack, "Setting MAC MODE to RRLL ");
			     break;
                   case RRRL:sprintf(cmd,"$CFG_DIR/mac.cmd.RRRL ");
                             strcat(remote_cmd,cmd);
			     sprintf(ack, "Setting MAC MODE to RRRL ");
			     break;
                   case RR__:sprintf(cmd,"$CFG_DIR/mac.cmd.RR__ ");
		             strcat(remote_cmd,cmd);
			     sprintf(ack, "Setting MAC MODE to RR__ ");
			     break;
	             default: break;
		 }
                 break;
    case Pulsar: sprintf(cmd,"$CFG_DIR/cmd.file "); 
                 strcat(remote_cmd,cmd);
		 sprintf(ack," Setting CORR to PULSAR MODE");
		 break;
   case FftMac: sprintf(cmd,"$CFG_DIR/cmd.file "); 
                strcat(remote_cmd,cmd);
		sprintf(ack," Setting CORR to STANDARD MODE");
		break;
case DelayFull: sprintf(ack," Setting the Delay/DPC to STANDARD MODE");
                break;
      default  : break;
  }
  strcat(remote_cmd,"; )'");

#ifdef DEBUG_SET_CORR
  if(!strcasecmp(DEBUG_SET_CORR,"yes"))
  fprintf(stderr,"executing %s\n",remote_cmd);
#endif
  
  fprintf(stderr,">> %s (in DAS version %s)\n",ack,DasVersionName[das_version]);

  system(remote_cmd);
  return 0;
}
